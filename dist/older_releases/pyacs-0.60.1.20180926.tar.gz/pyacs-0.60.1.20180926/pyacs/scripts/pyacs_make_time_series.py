#!/usr/local/geodesy/anaconda/bin/python

###################################################################
# SCRIPT    : pyacs_time_series.py
# AUTHOR    : JM NOCQUET
# DATE      : February 2011
# INPUT     : list of sinex files
#           : reference sinex
#           : experiment name
#           | options file
# OUTPUT    : 
# NOTE      :
#         
###################################################################
# TODO
# file Helmert_outliers and Helmert_summary
# ref_bias_pos & ref_bias_vel

# uncertainties for the time series

INTEST = True


###################################################################
# MODULES IMPORT
###################################################################


import sys,time,os
import numpy as np
import argparse
import shutil
import glob

import pyacs.sol.log
import pyacs.sol.sinex as SSinex
import pyacs.sol.helmert as Helmert
import pyacs.sol.discontinuity as Discontinuities
import pyacs.sol.read_conf as Read_Conf_Pyacs

from pyacs.sinex.sinex import sinex
from pyacs.sinex import snxutils

#from pyacs.gts.Gts import Gts
from pyacs.gts.Sgts import Sgts



###################################################################
# PARSE ARGUMENT LINE
###################################################################

parser = argparse.ArgumentParser()
parser.add_argument('-lsinex', action='store', type=str, dest='lsinex_name',required=True,help='file including the list of sinex/glx files to be processed')
parser.add_argument('-experiment', action='store', type=str, dest='expt',required=True,help='experiment name')
parser.add_argument('-ref_sinex', action='store', type=str, dest='ref_sinex_name',default=None,help='reference sinex used to define the reference frame')
parser.add_argument('--ref_apr', action='store', type=str, dest='ref_apr_name',default=None,help='reference apr file used to define the reference frame')
parser.add_argument('--eq_rename', action='store', type=str, dest='eq_rename',default=None,help='globk eq_rename file. Will be used with glred if glx are provided')
parser.add_argument('--discontinuity', action='store', type=str, dest='discontinuity',default=None,help='discontinuity file (IGS format ftp://igs-rf.ign.fr/pub/discontinuities/soln.snx)')
parser.add_argument('--codomes', action='store', type=str, dest='codomes',default=None,help='codomes file (IGS format ftp://igs-rf.ign.fr/pub/DOMES/codomes_gps_coord.snx)')
parser.add_argument('--psd', action='store', type=str, dest='psd',default=None,help='post-seismic deformation file (IGS format ftp://igs-rf.ign.fr/pub/psd/psd_IGS.snx)')
parser.add_argument('--conf_file', action='store', type=str, dest='options_file', default=None, help='configuration file for pyacs')
parser.add_argument('--dikin_outlier', action='store', type=float, dest='dikin_outlier', default=3, help='threshold value for outliers rejection after L1 estimation (1: very strict, 3: standard, 10: loose)')
parser.add_argument('--rep', action='store', type=float, dest='min_repeatability', default=None, help='relative weight given to the minimum repeatability condition; default 0.')
parser.add_argument('--method', action='store', type=str, dest='method', default='Dikin_LS', help='Estimation method Dikin_LS or LS')
parser.add_argument('--verbose', '-v', action='count',default=0,help='verbose mode')
parser.add_argument('--debug', action='count',default=0,help='debug mode')
parser.add_argument('--replace', action='count',default=0,help='replace mode')

start = time.time()   

args = parser.parse_args()

# verbose
if args.verbose>0:
    print("-- Verbose mode")
    verbose=True
else:
    verbose=False

# verbose
if args.debug>0:
    print("-- Debug mode")
    verbose=True
    debug=True
else:
    debug=False

# verbose
if args.replace>0:
    print("-- Replace mode")
    replace=True
else:
    replace=False


        
###################################################################
# READS OPTIONS FILE
###################################################################
if args.options_file:
    conf=Read_Conf_Pyacs.Conf(args.options_file,verbose=verbose)
    if debug:print("conf.rename ",conf.rename)
else:
    conf=Read_Conf_Pyacs.Conf()

if conf.min_repeat != []:
    previous_sinex=SSinex.SSinex()

###################################################################
# READS FILE INCLUDING THE SINEX FILES NAME TO BE PROCESSED
###################################################################

print('-- Reading list of files to be processed: ',args.lsinex_name)

lsinex=np.genfromtxt(args.lsinex_name,comments='#',dtype=str).tolist()
# ensure each file line is uniq
if np.size(lsinex)>1:
    lsinex=sorted(list(set(lsinex)))
else:
    lsinex=[lsinex]


# type glx or ssc

ll=lsinex[0].split('/')
sinex_basename=ll[-1]

suffix=sinex_basename.split('.')[-1]
if suffix in ['glx','GLX']:
    type_glx=True
else:
    type_glx=False


if type_glx:
    print('-- Number of solutions to be processed: ',len(lsinex),' type: GLX')
else:
    print('-- Number of solutions to be processed: ',len(lsinex),' type: SNX or SSC')
        

###################################################################
# OUTPUT DIRECTORY
###################################################################

if not replace:

    ###################################################################
    # CREATE OUTPUT DIRECTORY
    ###################################################################
    
    if verbose:print("-- Creating working directory ",args.expt)
    
    wdir=args.expt
    
    if os.path.isdir(wdir):
        print('!!! ',wdir,' directory already exists')
        sys.exit()
    elif os.path.isfile(wdir):
        print('!!! ',wdir,' file already exists')
        sys.exit()
    else:
        (path_stat,path_res_pos,path_maps,path_pos,path_txyz,path_tsg,path_prt,path_lgred_pos,path_log,path_sinex,path_ssc) = \
        pyacs.sol.log.output_directories(wdir)
    

else:

    if verbose:print("-- Reading working directory ",args.expt)
    
    wdir=args.expt
    (path_stat,path_res_pos,path_maps,path_pos,path_txyz,path_tsg,path_prt,path_lgred_pos,path_log,path_sinex,path_ssc) = \
        pyacs.sol.log.output_directories(wdir)
        
    if verbose:print("-- Cleaning pos and glred_pos directory of ",args.expt)
    try:
        shutil.rmtree(path_pos)
        shutil.rmtree(path_lgred_pos)
    except:
        pass
    
    os.mkdir(path_pos)
    os.mkdir(path_lgred_pos)

###################################################################
# TSG OUTPUT FILES
###################################################################
sum_helmert_file=path_stat+'/residuals_tsg.dat'
tsg_file = path_tsg+'tsg.dat'



###################################################################
# VARIABLES INITIALIZATION
###################################################################

TSG=np.zeros((len(lsinex),8))

# list of sites used to define the frame
l_ref_code=[]

# dictionary of Helmert estimation statistics
H_tsg_stat={}
        

###################################################################
# READS REFERENCE SINEX FILE
###################################################################

if args.ref_sinex_name is not None:

    # USING PYACS ROUTINE
    print('-- Reading reference SINEX file ',args.ref_sinex_name)
    ref_sinex=SSinex.SSinex(name=args.ref_sinex_name)
    ref_sinex.read_section_estimate(lexclude=conf.ref_exclude_all)
    print('-- Found ',len(list(ref_sinex.estimates.keys())),' code/soln in ',ref_sinex.name)
    
    # USING P. REBISCHUNG SINEX LIBRARY
#    print '-- Reading reference SINEX file using P. Rebischung sinex library: ',args.ref_sinex_name
#    ref_sinex = sinex.read(args.ref_sinex_name,dont_read =['matrices','comments','apriori','metadata'])

#    ref_sinex=Sinex.Sinex(args.ref_sinex_name)
#    ref_sinex.read_section_estimate(lexclude=conf.ref_exclude_all)
    
if args.ref_apr_name:

    print('-- Reading reference apr file ',args.ref_apr_name)
    ref_sinex=SSinex.SSinex(args.ref_apr_name)
    ref_sinex.read_section_estimate(lexclude=conf.ref_exclude_all,type='Apr')

##################################################################################
# READS IGS DISCONTINUITY FILE - SINEX & DISCONTINUITY MUST BE MUTUALLY CONSISTENT
##################################################################################

discontinuities=Discontinuities.Discontinuities()
if args.discontinuity is not None:
    # USING PYACS ROUTINE
    print('-- Reading IGS discontinuity file: ',args.discontinuity)
    discontinuities.read_igs_discontinuity(args.discontinuity)

    # USING P. REBISCHUNG SINEX LIBRARY
    #print '-- Reading IGS discontinuity file using P. Rebischung sinex library : ',args.discontinuity
    #solns = snxutils.read_solns('soln.snx')

##################################################################################
# CODOMES
##################################################################################

if args.codomes is not None:

    # USING P. REBISCHUNG SINEX LIBRARY
    print('-- Reading IGS codomes using P. Rebischung sinex library : ',args.codomes)
    domes = snxutils.read_domes(args.codomes)

##################################################################################
# POST-SEISMIC DEFORMATION FILE IGS FORMAT PSD_IGS.snx
##################################################################################

if args.psd is not None:

    # USING P. REBISCHUNG SINEX LIBRARY
    print('-- Reading IGS psd file using P. Rebischung sinex library: ',args.psd)
    psd = sinex.read(args.psd)
else:
    psd = None


###################################################################
# STARTS LOOP FOR EACH SINEX FILES
###################################################################


print('*********************************************************************************')
print('*********************************************************************************')
print('-- START OF PROCESSING - LOOP ON SINEX FILES')
print('*********************************************************************************')
print('*********************************************************************************')

index_sinex = 0

for sinex_name in lsinex:
    T=None
    print('*********************************************************************************')
    print('-- Processing: ',sinex_name)
    print('*********************************************************************************')

    ll=sinex_name.split('/')
    sinex_basename=ll[-1]
    
    # glx ?
    
    suffix=sinex_basename.split('.')[-1]
    if suffix in ['glx','GLX']:
        type_glx=True
    else:
        type_glx=False
    
    # if type_glx generates ssc and creates a daily apr file for running glred later
    
    H_COV = None 
    
    if type_glx:
        glx=sinex_name
        snx=sinex_basename.split('.')[-2]+'.snx'
        dir_snx=path_sinex
        dir_ssc=path_ssc
        ssc=sinex_basename.split('.')[-2]+'.ssc'
        SSinex.glx2snx(glx,snx,dir_snx=dir_snx)
        SSinex.snx2ssc(dir_snx+'/'+snx,ssc,dir_ssc)
        
        #os.remove(dir_snx+'/'+snx)

        if INTEST:
            from pyacs.sinex.sinex import sinex as pr_sinex
            print('-- reading ', dir_snx+'/'+snx)
            wsnx = pr_sinex.read(dir_snx+'/'+snx)
            lcode = []
            lpt   = []
            lsoln = []
            
            for sta in wsnx.sta:
                 lcode.append(sta.code)
                 lpt.append(sta.pt)
                 lsoln.append(sta.soln)

#            for i in range( len(lcode) ):
            print( wsnx.get_xyz( lcode ) )
            
            
            lCOV = wsnx.get_cov_sta(lcode)
            print(lCOV)
            
            wsnx.unconstrain()
            wsnx.neqinv(keep_const_on=['UT'], min_const_on='RST', min_const_sig=1e-5)
            
            H_COV= dict(zip(lcode , wsnx.get_cov_sta(lcode) ) )

        sinex_name=dir_ssc+'/'+ssc

        if verbose: print('-- Creating a daily apr file for glred')
        apr_4_glred=open(wdir + '/pyacs.apr','w+')


    ###########################################################################
    # reads free sinex
    ###########################################################################
    
    free_sinex=SSinex.SSinex(name=sinex_name,estimates={})
    free_sinex.read_section_estimate(discontinuity=discontinuities,rename=conf.rename)

    print('----------------------------------------------------------------------------')
    print(("-- n_site in free solution: %5d" % len(list(free_sinex.estimates.keys()))))

#     tref=pyacs.decyear2epoch(free_sinex.epoch)
#     
#     print('----------------------------------------------------------------------------')
#     print("-- Keeping relevant soln")
#     ref_sinex.keep_relevant_solns(tref, solns)
# 
#     print("-- Propagating ref coordinates")
#     ref_sinex.propagate(tref)
#     ref_sinex.add_psd(psd)
#     
#     print("-- Changing format")
#     ref_sinex = Sinex.Sinex.from_sinex(ref_sinex)
# 
#     print("-- Check")


#    for x in sorted(ref_sinex.estimates.keys()):print x
#    
#    for x in sorted(free_sinex.estimates.keys()):print x

    H_common_Gpoint_ref=ref_sinex.common(free_sinex.estimates, prefit=conf.ref_prefit_value)

#    for x in sorted(H_common_Gpoint_ref.keys()):print x
    
#    sys.exit()

    
    if verbose: 
        print('-- Found ',len(H_common_Gpoint_ref),' sites common with ',ref_sinex.name)

    # Check whether Helmert calculation is possible
        
    if len(H_common_Gpoint_ref) < 3:
        if verbose: print('!!! Number of sites shared with reference solution is less than 3    --> pass!')
        T = None
        continue
    
    ###########################################################################
    # Helmert Calculation
    ###########################################################################

    # test if there are excluded components

    if (free_sinex.basename in list(conf.ref_reject.keys())):
        if verbose: 
            print("-- There are rejected components for ",free_sinex.basename)
        lexclude=conf.ref_reject[free_sinex.basename]
    else:
        lexclude={}

    H_common_Gpoint_free=free_sinex.subset_from_keys(H_common_Gpoint_ref)

    # Helmert

    (T,Residuals,H_stat)=\
        Helmert.estimate_helmert(H_common_Gpoint_ref,H_common_Gpoint_free,vcv_xyz=[],psd=psd,
                        tran=True,rot=True,scale=True,lexclude=lexclude,
                        verbose=verbose,threshold=args.dikin_outlier,method=args.method)


    print(("-- Helmert: n_site_ref: %5d n_obs: %5d n_rejected: %5d   (%5.1lf %%) " % \
            (H_stat['n_site'],H_stat['n_obs_raw'],H_stat['n_obs_rejected'],H_stat['percent_rejected'])))

    print(("-- Postfit L1 norm median: %10.2lf %10.2lf %10.2lf " % tuple(H_stat['median_L1'])))
    print(("-- Postfit L2 norm wrms  : %10.2lf %10.2lf %10.2lf " % tuple(H_stat['wrms'])))
    print('----------------------------------------------------------------------------')


    ###########################################################################
    # Writing Helmert Summary and storing TSG Value
    ###########################################################################

    if verbose: 
        print('-- writing Helmert summary')

    if isinstance(T,np.ndarray):
        pyacs.sol.log.helmert_residuals(Residuals, H_stat,free_sinex.name,sum_helmert_file,verbose=verbose)

    TSG[index_sinex,1:]=T.flatten()
    TSG[index_sinex,0]=free_sinex.epoch
    
    l_ref_code += Residuals[:,0].tolist()
    
    ###########################################################################
    # WRITES TRANSFORMED COORDINATES
    ###########################################################################

    if verbose: 
        print('-- writing transformed coordinates')
        
    snx_transformed=free_sinex.apply_helmert(T, verbose=False)
    snx_transformed.write_tsxyz(path_txyz+'/'+free_sinex.name.split('/')[-1]+'_txyz.dat' , HCOV=H_COV)

    ###################################################################
    # GLRED SOLUTION IF GLX
    ###################################################################

    if type_glx:
        
        for M in list(snx_transformed.estimates.values()):
            apr_4_glred.write(' %s_GPS %16.4lf  %16.4lf  %16.4lf    0.0000 0.0000 0.0000 %8.4lf 0.0000 0.0000 0.0000 0.0000 0.0000 0.0000 from pyacs %s\n' % \
                              (M.code.upper(),M.X,M.Y,M.Z,M.epoch,wdir))

        apr_4_glred.close()

        print("-- Running Glred for ",glx)
        SSinex.glred_1_day(glx,path_prt,path_log,wdir + '/pyacs.apr',eq_rename=args.eq_rename)
        os.remove(wdir + '/pyacs.apr')

    index_sinex=index_sinex+1

    print(("-- Processing time since start: %.1lf seconds =  %.1lf minutes " % (time.time()-start,(time.time()-start)/60.)))

    


###################################################################
# END LOOP FOR EACH SINEX FILES
###################################################################
print('*********************************************************************************')
print('*********************************************************************************')
print('-- END OF PROCESSING - LOOP ON SINEX FILES')
print('*********************************************************************************')
print('*********************************************************************************')

###################################################################
# WRITE TIME SERIES
###################################################################

print('-- writing time series as pos files (uncertainties neglected)')

TS=Sgts(path_txyz,verbose=verbose)

i = 1
for code in sorted( TS.lcode() ):
    ts = TS.__dict__[code]
    print('-- writing time series for ',ts.code, i, ' / ',len( TS.lcode() ))
    ts.xyz2neu(corr=False)
    ts.write_pos(path_pos)
    i = i + 1

###################################################################
# WRITE TSG TIME SERIES
###################################################################

if verbose:
    print('-- writing Helmert parameters values in ',path_tsg+'/tsg.dat')

pyacs.sol.log.write_tsg(lsinex, TSG, path_tsg+'/tsg.dat')

###################################################################
# WRITE RESIDUAL TIME SERIES FOR REFERENCE SITES
###################################################################

l_ref_code = list(set(sorted(l_ref_code)))


if verbose:
    print('-- writing time series for reference sites')
    print('-- ',len(l_ref_code),' sites were used as reference sites to define the frame')
     
for code in sorted(l_ref_code):
    print('-- writing  time series for reference site:',code)
    l_index_no_data=[]
    
    ref_ts = TS.__dict__[code].copy()

#    ref_ts.correct_duplicated_dates(action='correct',tol= .1, in_place=True,verbose=True)

    for i in np.arange(ref_ts.data_xyz.shape[0]):
        epoch=ref_ts.data_xyz[i,0]
        XYZ = ref_sinex.get_STA(code, epoch, discontinuity=discontinuities, psd_file=args.psd , verbose=verbose)

        if XYZ is not None:
            ref_ts.data_xyz[i,1:4]=XYZ
        else:
            l_index_no_data.append(i)
    
    ref_ts.data_xyz[:,0] = TS.__dict__[code].data_xyz[:,0]
    
    # remove dates where ref is not available
    if len(l_index_no_data)>0:
        ref_ts.data_xyz=np.delete(ref_ts.data_xyz,tuple(l_index_no_data),axis=0)
        TS.__dict__[code].data_xyz=np.delete(TS.__dict__[code].data_xyz,tuple(l_index_no_data),axis=0)
    
    # re-generate neu from xyz with the same local frame origin to ensure the ENU are in the same frame
    ref_ts.xyz2neu(corr=False , ref_xyz = ref_ts.data_xyz[0,1:4])
    TS.__dict__[code].xyz2neu(corr=False , ref_xyz = ref_ts.data_xyz[0,1:4])
    

    # write ref_ts
    if verbose:
        print('-- writing predicted reference time series for ', ref_ts.code)
    ref_ts.write_pos(path_res_pos+'/ref',add_key='ref')

    # create residual Gts
    
    data_res = TS.__dict__[code].data - ref_ts.data 
    new_gts = TS.__dict__[code].copy()
    new_gts.data = data_res
    new_gts.data[:,0] = ref_ts.data[:,0]
    
    # write residual Gts
    if verbose:
        print('-- writing residual reference time series for ', ref_ts.code)

    new_gts.write_cats(path_res_pos,add_key='res',)
    
###################################################################
# WRITE RUNTIME
###################################################################
print(("-- Processing time since start: %.1lf seconds =  %.1lf minutes " % (time.time()-start,(time.time()-start)/60.)))

######################################################################################################
### CREATION OF RESULT FILES
######################################################################################################

print('-- writing additional files')

# APR
###################################################################

apr_file= path_stat + '/pyacs.apr'
print('-- writing apr file in ',apr_file)

i = 1
for code in sorted( TS.lcode() ):
    print('-- ',code,i,' / ',len( TS.lcode() ))
    ts = TS.__dict__[code]
    ts.save_apr(apr_file, epoch=None, verbose=False, excluded_periods=None)
    i = i + 1
    
# INFO FILES
print('-- writing information files in ',path_stat)

TS.stat_site(lsite=[],lsite_file=None,verbose=False, save_dir=path_stat)

print(("-- Processing time since start: %.1lf seconds =  %.1lf minutes " % (time.time()-start,(time.time()-start)/60.)))

###############################################################################
# CREATES GLRED POS FILE IF TYPE_GLX
###############################################################################

if type_glx:

    print("-- Creating GLRED pos files")
    import subprocess
    os.chdir(path_prt)
    cmd='sh_plot_pos -f prt.org -p '
    print("-- Running ",cmd)
    subprocess.getstatusoutput(cmd)
    lpos=glob.glob('*.pos')
    for pos in lpos:
        shutil.move(pos, '../glred_pos')

    print(("-- Processing time since start: %.1lf seconds =  %.1lf minutes " % (time.time()-start,(time.time()-start)/60.)))
