#!/usr/bin/env python

"""Redo a gamit solution calculating a priori coordinates for sites missing
   is the previous processing. Do the combination and produces sinex file
   Jean-Mathieu Nocquet - April 2012 - Updated from geca in perl
   Report bug to nocquet@geoazur.unice.fr
"""
###################################################################
# MODULES IMPORT
###################################################################


import sys, os, stat
import argparse
import subprocess
import gzip
import shutil
import random


from numpy import array,median

from pyacs.lib import astrotime as AstroTime
from pyacs.lib import gpstime as GpsTime
from pyacs.lib import pygamit_module
import glob
from pyacs.sol import sinex as Sinex

gamit_path=os.environ['GAMIT']
if not os.path.exists(gamit_path):
    print("=> ",gamit_path, " directory does not exist. Check your GAMIT configuration in .bashrc. Exiting...")
    sys.exit()
else:
    gamit_tables_path=gamit_path+'/tables'
    print("=> GAMIT tables to be found in ", gamit_tables_path)

grd_path=gamit_path+'/../grids'
print("=> GAMIT grids to be found in ", grd_path)

brdc_path=os.environ['BRDC']
print("=> Broadcats files to be found in ", brdc_path)

sp3_path=os.environ['ORBIT']
print("=> Sp3 files to be found in ", sp3_path)

min_rinex_size=10 # minimum size (Kb) for a rinex file to be processed

###################################################################
# PARSE ARGUMENT LINE
###################################################################

parser = argparse.ArgumentParser()
parser.add_argument('--dir_conf', action='store', type=str, dest='dir_conf',help='directory including configuration files')
parser.add_argument('--sd', action='store', type=int, dest='start_doy',help='starting doy')
parser.add_argument('--ed', action='store', type=int, dest='end_doy',help='end doy')
parser.add_argument('--ld', action='append', type=int, dest='list_doy',help='list of doy to be processed', default=[])
parser.add_argument('--year', action='store', type=int, dest='year',help='year')
parser.add_argument('--type', action='store', type=str, dest='type_analysis',help='best|precise|rapid', default='best')
parser.add_argument('--experiment', action='store', type=str, dest='expt',help='experiment name')
parser.add_argument('--clean', action='store', type=str, dest='clean',help='clean option [Y/N], default yes', default='Y')
parser.add_argument('--site', action='append', type=str, dest='lsite',help='force a given site to be reprocessed; can be repeated', default=[])
parser.add_argument('--sessinfo', action='store', type=str, dest='sessinfo',help='session info argument for time window to be processed', default='30 00 00 2880')

if (len(sys.argv)<2):parser.print_help()
    
args = parser.parse_args()

year=args.year

if not (args.year and args.expt and args.dir_conf):
    parser.print_help()
    sys.exit()
if not ((args.start_doy and args.end_doy) or args.list_doy):
    parser.print_help()
    sys.exit()
if args.start_doy and args.end_doy:
    smjd=AstroTime.dayno2mjd(args.start_doy, args.year, ut=0.0)
    emjd=AstroTime.dayno2mjd(args.end_doy, args.year, ut=0.0)
    for mjd in range(int(smjd),int(emjd)+1):
        (doy,year,ut)=AstroTime.mjd2dayno(mjd)
        args.list_doy.append(doy)

print("=> sites to be added ",args.lsite)

###################################################################
# CHECK CONFIGURATION DIRECTORY
###################################################################

if not os.path.exists(args.dir_conf):
    print("=> ",args.dir_conf, " directory does not exist. Exiting...")
    sys.exit()

if args.type_analysis == 'best':
    conf_file='sestbl.best'

if args.type_analysis == 'precise':
    conf_file='sestbl.precise'
    
if args.type_analysis == 'rapid':
    conf_file='sestbl.rapid'

path_sestbl=args.dir_conf+'/'+conf_file

if not os.path.exists(path_sestbl):
    print("=> ",path_sestbl, " missing. Exiting...")
    sys.exit()

# check station.info 
    
path_conf_file=args.dir_conf+'/station.info'
if not os.path.exists(path_conf_file):
    print("=> station.info ",path_conf_file, " missing. Exiting...")
    sys.exit()


###################################################################
# READS SITE.DEFAULTS
###################################################################

lsite=[]

print("=> Reading sites.defaults")
   
site_defaults=args.dir_conf+'/sites.defaults'
fs=open(site_defaults,'r',encoding="latin-1")
for line in fs:
    if line[0]=='#' or len(line) < 3:continue
    lline=line.split()
           
    if '_gps' in lline[0] and args.expt in lline[1]:lsite.append(lline[0][0:4])
fs.close()
    
    


###################################################################
# LOOP ON LDOY
###################################################################

for doy in args.list_doy:
    print("=> Processing doy ",doy) 
    l_to_be_processed=[]
    
    # adds the sites provided by the line command
    for site in args.lsite:l_to_be_processed.append(site.lower())
    
    syear=str(year)
    syr=syear[-2:]
    sdoy="%03d" % doy

    dec_year=year+doy/365.25

    log_suffix=args.expt+'_'+syear+'_'+sdoy

    print("=> Processing doy:",sdoy," year:",syear)

    ###################################################################
    # CREATES AND PREPARE TABLES DIRECTORY
    ###################################################################
    

    wdir=os.environ['USER']+'_'+args.expt+'_'+syear+'_'+sdoy
    os.chdir(wdir)

    ###################################################################
    # test whether netsel is present (it is not present if processing stopped with FATAL error)
    ###################################################################
    
    if not os.path.isfile('netsel.out'):
        # test whether netsel.out is present in tables
        if os.path.isfile('pre_proc/netsel.out'):
            shutil.copy('pre_proc/netsel.out','netsel.out')

    ###################################################################
    # if exists, removes tables directory to start on good basis
    ###################################################################

    if os.path.isdir('pre_proc'):
        cmd='rm -Rf pre_proc'
        print("=> Running ",cmd)
        subprocess.getstatusoutput(cmd)
        

    ###################################################################
    # GET SITES TO BE RE-PROCESSED
    ###################################################################

    lqfile=glob.glob('q????a.???')
    lmissing=[]
    for qfile in lqfile:
        (n_total_ambiguity,n_NL_fixed_ambiguity,n_WL_fixed_ambiguity,lsite_not_calculated,lfit,normal_stop)\
        =pygamit_module.read_qfile(qfile)
        
        
        for site in lsite_not_calculated:
            if site not in lmissing:lmissing.append(site)
    
    if len(lmissing)==0:
        print("=> All sites were correctly processed in the previous processing....")
        #sys.exit()
    else:
        str_missing=''
        for site in lmissing:
            str_missing=str_missing+' '+site

    
        print("=> sites to be reprocessed (initial coordinates re-determined):",str_missing)

    ###################################################################
    # MOVE TO TABLES
    ###################################################################

    if not os.path.isdir('pre_proc'):os.mkdir('pre_proc')
    os.chdir('pre_proc')

    process_defaults=args.dir_conf+'/process.defaults'
    ldir_rinex=[]
    fs=open(process_defaults,'r',encoding="latin-1")
    for line in fs:
        if line[0]=='#' or len(line) < 3:continue
        lline=line.split()
        if 'rnxfnd' in lline[1]:ldir_rinex.append(lline[-1].replace('"',''))
        if 'aprf' in lline[1]:
            aprf=lline[-1]
            path_aprf=args.dir_conf+'/'+aprf
    fs.close()
    
    
    #shutil.copy(args.dir_conf+'/'+aprf,lfile)    

    # get first approximate coordinates using teqc
    # for that get brd file
    
    nav_file = 'brdc'+ sdoy +'0.'+ syr +'n'
    if not os.path.isfile(nav_file):os.symlink(brdc_path +'/'+nav_file,nav_file)
    
    # gets the rinex files for each sites to be reprocessed
    
    lrinex=[]
    for rinex_dir in ldir_rinex:
        lrinex+=glob.glob(rinex_dir+'/'+syear+'/'+sdoy+'/*')
    
    # link the rinex files if site code is in site.default
    lavailable_site=[]
    #print 'lsite ',lsite
    for rinex in lrinex:
        rinex_basename=rinex.split('/')[-1]
        #print rinex_basename
        if rinex_basename[0:4].lower() in lsite:
            if not os.path.exists(rinex_basename) and os.path.getsize(rinex)/1024>min_rinex_size:
                print("=> Getting ",rinex)
                os.symlink(rinex,rinex_basename)
                lavailable_site.append(rinex_basename[0:4].lower())
 
    
    #print lavailable_site
    lfile = 'l'+args.expt+syr[-1]+'.'+sdoy
    path_aprf=args.dir_conf+'/'+aprf
    pygamit_module.make_apr_doy(path_aprf,lfile, lavailable_site, doy, year)
 
    #print "lavailable_site",lavailable_site
    # uncompressing rinex files

    lmissing_check=[]
    for site in lmissing:
        if site.lower() not in lavailable_site:
            print("=> Rinex missing for ",site.lower()," Removed from processing")
        else:
            lmissing_check.append(site)
            
    lmissing=lmissing_check

    str_missing=''
    for site in lmissing:
        str_missing=str_missing+' '+site
        if site.lower() not in l_to_be_processed:l_to_be_processed.append(site.lower())
    print("=> sites to be reprocessed:",str_missing)

    
    for site in lmissing:
        cmd="sh_crx2rnx -f "+site.lower()+"*.Z"
        print("=> Running ",cmd)
        subprocess.getstatusoutput(cmd)
    
    # looping on missing sites
    
    
    for site in lmissing:
        # rinex 
        
        print("=> Processing ",site)
        #print site.lower()+sdoy+'*'+'.'+syear[-2:]+'o'
        lrinex=glob.glob(site.lower()+sdoy+'*'+'.'+syear[-2:]+'o')
        rinex=lrinex[0]
        # runs teqc
        cmd='teqc +qc -nav '+nav_file+' '+rinex
        print("=> Running ",cmd)
        subprocess.getstatusoutput(cmd)
        # reads teqc result
        teqc_S=rinex[:-1]+'S'
        #print "reading1 XYZ in ",teqc_S
        fteqc=open(teqc_S,encoding="latin-1")
        for line in fteqc:
            #print line
            if ' antenna WGS 84 (xyz)' in line:
                #print "reading2 XYZ in ",teqc_S
                #print float(line.split()[5]),float(line.split()[6]),float(line.split()[7])
                (X,Y,Z)=float(line.split()[5]),float(line.split()[6]),float(line.split()[7])
                break
        fteqc.close()

        # now replace the header coordinates, so that rx2apr starts with good a priori
        cmd='cp -f '+rinex+' rinex'
        print("=> Running ",cmd)
        subprocess.getstatusoutput(cmd)
        
        cmd='teqc -O.px '+str(X)+' '+str(Y)+' '+str(Z)+' rinex > '+rinex
        print("=> Running ",cmd)
        subprocess.getstatusoutput(cmd)
        
        
        lexclude=[site.lower()]
        # now gets the apr lines corresponding three nearest neighbor from apr file
        lapr=pygamit_module.get_nearest_from_apr(path_aprf,3,lavailable_site,lexclude,X,Y,Z,dec_year)
        
        #print "lapr ",lapr
        # write a small temporary apr
        lref=[]
        fapr=open('tmp.apr','w')
        for line in lapr:
            wline=line+"\n"
            fapr.write(wline)
            lref.append(line[1:5].lower())
        fapr.close()
        # now runs make_rx2apr
        
        for ref in lref:
            # automatically adds closest sites in the re-processing
            if ref.lower() not in l_to_be_processed:l_to_be_processed.append(ref.lower())
            cmd='make_rx2apr  -d . -u '+site.lower()+' -r '+ref.lower()+ ' -t tmp.apr' 
            print("=> Running ",cmd)
            subprocess.getstatusoutput(cmd)
        
        # now gets the apr for site
        # take the median of the 3 differential pseudo-range result
        
        lnew_apr=glob.glob(site.lower()+'.apr.*')
        XX=[];YY=[];ZZ=[]   
        for new_apr in lnew_apr:
            fnew_apr=open(new_apr,encoding="latin-1")
            lline=fnew_apr.readline().split()
            XX.append(float(lline[1]))
            YY.append(float(lline[2]))
            ZZ.append(float(lline[3]))
        
        #print "XX ",XX
        #print "YY ",YY
        #print "ZZ ",ZZ
        NEW_APP_X=median(array(XX))
        NEW_APP_Y=median(array(YY))
        NEW_APP_Z=median(array(ZZ))
        
        #print "NEW ",NEW_APP_X,NEW_APP_Y,NEW_APP_Z
        print("=> Adding a new line in ",lfile," for site ",site)
        pygamit_module.substitute_site(lfile,site,NEW_APP_X,NEW_APP_Y,NEW_APP_Z,dec_year)
    
    ###################################################################
    # GET GAMIT TABLES
    ###################################################################
    
    
#    lgamit_tables=('autcln.cmd','sittbl.','rcvant.dat','leap.sec','antmod.dat','svnav.dat','hi.dat','svs_exclude.dat','gdetic.dat','eq_rename','dcb.dat','otlcmc.dat','sestbl.','station.info')
#    
#    for table in lgamit_tables:
#        path_table=args.dir_conf+'/'+table
#        if not os.path.exists(path_table):
#            print "=> ",path_table, " not present; Fetching it from ",gamit_tables_path
#            path_table=gamit_tables_path+'/'+table
#        os.symlink(path_table,table)

    import shutil

    if args.type_analysis == 'precise':
        table='sestbl.precise'
    if args.type_analysis == 'rapid':
        table='sestbl.rapid'

    if args.type_analysis == 'rapid' or args.type_analysis == 'precise':

        path_table=args.dir_conf+'/'+table
        if not os.path.exists(path_table):
            print("=> ",path_table, " not present; Linking from ",gamit_tables_path)
            sys.exit()
        os.symlink(path_table,'sestbl.')
        lgamit_tables=('autcln.cmd','sittbl.','rcvant.dat','leap.sec','antmod.dat','svnav.dat','hi.dat','svs_exclude.dat','gdetic.dat','eq_rename','dcb.dat','otlcmc.dat','station.info')
    else:
        lgamit_tables=('autcln.cmd','sittbl.','rcvant.dat','leap.sec','antmod.dat','svnav.dat','hi.dat','svs_exclude.dat','gdetic.dat','eq_rename','dcb.dat','otlcmc.dat','sestbl.','station.info')

    for table in lgamit_tables:
        path_table=args.dir_conf+'/'+table
        if not os.path.exists(path_table):
            print("=> ",path_table, " not present; Linking from ",gamit_tables_path)
            path_table=gamit_tables_path+'/'+table
        os.symlink(path_table,table)

    
    # nutbl.
    os.symlink(gamit_tables_path+'/nutabl.'+syear,'nutabl.')
    # soltab
    os.symlink(gamit_tables_path+'/soltab.'+syear+'.J2000','soltab.')
    # luntab
    os.symlink(gamit_tables_path+'/luntab.'+syear+'.J2000','luntab.')
    # ut1
    os.symlink(gamit_tables_path+'/ut1.usno','ut1.')
    # pole
    os.symlink(gamit_tables_path+'/pole.usno','pole.')


    ###################################################################
    # LOADING GRIDS
    ###################################################################

    atmlgrd='/atmfilt_cm.'+syear
    vmf1grd='/vmf1grd.'+syear

    os.symlink(grd_path+'/'+atmlgrd,'atml.grid')
    os.symlink(grd_path+'/'+vmf1grd,'map.grid')
    os.symlink(grd_path+'/'+vmf1grd,'met.grid')
    
    lgamit_grid=('atl.grid','otl.grid')
    for grid in lgamit_grid:
        if not os.path.exists(grd_path+'/'+grid):
            print("=> ",grd_path+'/'+grid, "missing; Exiting...")
            sys.exit()
        else:
            os.symlink(grd_path+'/'+grid,grid)
            
    ################################################################################
    # ORBITS
    ################################################################################
    
    (day,month)=AstroTime.dayno2cal(doy,year)
    
    (gpsWeek, gpsSOW, gpsDay, gpsSOD)=GpsTime.gpsFromUTC(year, month, day, 0, 0, 0, leapSecs=30)

    gweek="%04d" % gpsWeek + str(gpsDay)
    
    nav_file = 'brdc'+ sdoy +'0.'+ syr +'n'
    if (args.type_analysis == 'rapid'): 
        sp3_file = 'igr'+gweek+'.sp3'
    else:
        sp3_file = 'igs'+gweek+'.sp3'

    print(("=> Getting orbit %s and brdc %s" %(sp3_file,nav_file)))


    if not os.path.isfile(nav_file):os.symlink(brdc_path +'/'+nav_file,nav_file)
    if not os.path.isfile(sp3_file):os.symlink(sp3_path +'/'+sp3_file,sp3_file)


#Modified by P. Jarrin for running in Macbook
    cmd="sh_sp3fit -f "+sp3_file+" -gnss G  -o igsg -u -d "+syear+" "+sdoy+" -m 0.100"
#    cmd="sh_sp3fit -f "+sp3_file+" -u -o igsf -u -m 0.200"
    print("=> Running ",cmd)
    subprocess.getstatusoutput(cmd)
    out_tfile='tigs'+gweek+'.sp3'
    tfile='tigsf'+syr[-1]+'.'+sdoy
#Modified by P. Jarrin for running in Macbook
    gfile = 'gigsg'+syr[-1]+'.'+sdoy    
#   gfile = 'gigsf'+syr[-1]+'.'+sdoy    
    #print "=> Renaming ",out_tfile," -> ",tfile
    #shutil.move(out_tfile,tfile)
    print("=> sh_sp3fit OK.")
    
    ################################################################################
    # RINEX
    ################################################################################
    
    # General comments
    # we want a minimum of 10 sites and two sites per subnetworks
    # we therefore start by inspecting each subnetwork

    
    # reads netsel output
    # modified to read all glx availables

    H_subnetwork={}

    cmd='uncompress -v ../*.glx.Z'
    print("=> Running ",cmd)
    subprocess.getstatusoutput(cmd)

    cmd='gunzip -v ../*.glx.gz'
    print("=> Running ",cmd)
    subprocess.getstatusoutput(cmd)


    lglx=glob.glob('../*.glx')

    # convert to sinex
    for glx in lglx:
        sinex=glx.split('/')[-1].split('.')[0]+'.snx'
        cmd='glbtosnx . \'\' '+glx+' '+sinex
        print("=> Running ",cmd)
        subprocess.getstatusoutput(cmd)
    # reads sinex
    lsnx=glob.glob('./*.snx')
    for snx in lsnx:
        print(snx)
        print(snx.split('.'))
        print(snx.split('.')[-2])
        subnetwork=snx.split('.')[-2][-4:]
        print(subnetwork)
        sinex=Sinex.SSinex(snx)
        sinex.read_section_estimate()
        print('sinex.lcode() ',sinex.lcode())
        H_subnetwork[subnetwork]=sinex.lcode()
 
        
#    dnetsel_out=open('../netsel.out','r')
#    for line in dnetsel_out:
#        if not '_gps' in line:continue
#        lline=line.split()
#        gps_site=lline[0][0:4]
#        subnetwork=lline[1]
#        #print "gps_site subnetwork ",gps_site,subnetwork
#        if not H_subnetwork.has_key(subnetwork):H_subnetwork[subnetwork]=[]
#        if not gps_site in H_subnetwork[subnetwork]:H_subnetwork[subnetwork].append(gps_site)
        
    
#    tie_subnetwork=sorted(H_subnetwork.keys())[-1]

#    ltie_gps=H_subnetwork[tie_subnetwork]
    #print 'ltie_gps ',ltie_gps 
#    del H_subnetwork[tie_subnetwork]
    print("=> Subnetworks read.")
    print("=> ",len(list(H_subnetwork.keys()))," subnetworks found")
    for key in sorted(H_subnetwork.keys()):
        print('network #',key, 'nb sites: ',len(H_subnetwork[key]))
        print(" ".join(map(str, H_subnetwork[key])))        #print H_subnetwork[key]
#        for gps_site in ltie_gps:
#            if not gps_site in H_subnetwork[key]:H_subnetwork[key].append(gps_site)
        #print 'network #',key
        #print H_subnetwork[key]
#    print 'tie sites: ',len(ltie_gps)
#    print " ".join(map(str, ltie_gps))        
        #print H_subnetwork[key]
    
    # now adds some more sites in each subnetworks if needed
    
    for subnetwork in sorted(H_subnetwork.keys()):
        print("=> Now checking subnetwork #",subnetwork)
        n_site_in_this_subnetwork=0
        for site in l_to_be_processed:
            if site in H_subnetwork[subnetwork]:n_site_in_this_subnetwork=n_site_in_this_subnetwork+1
        
        print("=> Found ",n_site_in_this_subnetwork, " in subnetwork #",subnetwork)
        
        # if less than two sites, choose randomly a site until getting two sites

        rnd_indx=random.randint(0,len(H_subnetwork[subnetwork])-1)
        site=H_subnetwork[subnetwork][rnd_indx]
        
        while n_site_in_this_subnetwork<2:
            while site.lower() in l_to_be_processed:
                rnd_indx=random.randint(0,len(H_subnetwork[subnetwork])-1)
                site=H_subnetwork[subnetwork][rnd_indx]
            print("=> Adding ",site.lower()," from subnetwork #",subnetwork," to reprocessing list")
            l_to_be_processed.append(site.lower())
            n_site_in_this_subnetwork=n_site_in_this_subnetwork+1

    # check that a least 10 sites will be reprocessed
    
    if (len(l_to_be_processed))<10:
        print("=> Still missing ",10-len(l_to_be_processed)," sites")
        rnd_subnetwork=random.randint(0,len(list(H_subnetwork.keys()))-1)
        subnetwork=list(H_subnetwork.keys())[rnd_subnetwork]
        rnd_indx=random.randint(0,len(H_subnetwork[subnetwork])-1)
        site=H_subnetwork[subnetwork][rnd_indx]
        
        while len(l_to_be_processed)<10:
            while site.lower() in l_to_be_processed:
                rnd_subnetwork=random.randint(0,len(list(H_subnetwork.keys()))-1)
                subnetwork=list(H_subnetwork.keys())[rnd_subnetwork]
                rnd_indx=random.randint(0,len(H_subnetwork[subnetwork])-1)
                site=H_subnetwork[subnetwork][rnd_indx]
            l_to_be_processed.append(site.lower())
    
    # now, we have the final list of sites for re-processing
    
    str_to_be_processed=''
    for site in l_to_be_processed:
        str_to_be_processed=str_to_be_processed+' '+site
    print(("=> Final list of sites to be (re)processed: #%3d" % (len(l_to_be_processed))))    
    print(str_to_be_processed)
    
    # we can remove unused rinex files
    
    llrinex=glob.glob('????'+sdoy+'*.*d.Z')
    for rinex in llrinex:
        if rinex[0:4] not in l_to_be_processed:
            print("=> Removing ",rinex)
            os.remove(rinex)
 
    
    # uncompressing rinex files
    
    cmd="sh_crx2rnx -f *.Z"
    print("=> Running ",cmd)
    subprocess.getstatusoutput(cmd)

    # reprocessing is a new subnetwork
    subnetwork="%02d" % (len(list(H_subnetwork.keys()))+1)
    log_suffix=args.expt+'_'+syear+'_'+sdoy+'_'+subnetwork


    ################################################################################
    # RUNNING SH_MAKEXP
    ################################################################################
    [sampling_rate,sh,sm,epochs]=list(map(int,args.sessinfo.split()))
    str_session_info="# Session.info : free format, non-blank first column is comment"
    str_session_info+="\n#Year Day  Sess#  Interval  #Epochs  Start hr/min  Satellites"
    str_session_info+="\n %4d %03d    1        %02d     %04d     %02d  %02d      1  2  3  4  5  6  7  8  9 10 11 12 13 14 15 16 17 18 19 20 21 22 23 25 26 27 28 29 30 31 32" % (year,doy,sampling_rate,epochs,sh,sm)

    fs=open('session.info','w')
    fs.write("%s" % str_session_info)
    fs.close()

    #Modified by P. Jarrin for running in Macbook
    cmd="sh_makexp -expt "+args.expt+" -orbt igsg -sp3file "+sp3_file+" -yr "+syear+" -doy "+sdoy+" -sess 99 -srin -nav "+nav_file+"      -jclock brdc -sinfo "+args.sessinfo+" -gnss G" 
#    cmd="sh_makexp -expt "+args.expt+" -orbt IGSF -yr "+syear+" -doy "+sdoy+" -nav "+nav_file+" -sinfo "+args.sessinfo
    
    ################################################################################
    # RUNNING SH_MAKEXP
    ################################################################################
    #cmd="sh_makexp -expt "+args.expt+" -orbt IGSF -yr "+syear+" -doy "+sdoy+" -nav "+nav_file+" -sinfo "+args.sessinfo
   
#    cmd="sh_makexp -expt "+args.expt+" -orbt IGSF -yr "+syear+" -doy "+sdoy+" -nav "+nav_file+" -sinfo 30 00 00 2880"
    print("=> Running ",cmd)
    subprocess.getstatusoutput(cmd)
   
# needs to check again SVS list to be included in the session.info

    print("=> Checking satellite list from gfile to update session.info")

    cmd="sh_check_sess -sess "+sdoy+" -type gfile -file "+gfile+" >> log."+log_suffix
    print("=> Running ",cmd)
    subprocess.getstatusoutput(cmd)


    ################################################################################
    # Creating j-file
    ################################################################################

    jfile = 'jbrdc'+syr[-1]+'.'+sdoy
    cmd="makej "+nav_file+" "+jfile+" >> log."+log_suffix
    print("=> Running ",cmd)
    subprocess.getstatusoutput(cmd)

    cmd="sh_check_sess -sess "+sdoy+" -type jfile -file "+jfile+" >> log."+log_suffix
    print("=> Running ",cmd)
    subprocess.getstatusoutput(cmd)
        
    ################################################################################
    # Running makex 
    ################################################################################
    makex_batch = args.expt + '.makex.batch'
    cmd='makex '+makex_batch+' >> log.'+log_suffix
    print("=> Running ",cmd)
    subprocess.getstatusoutput(cmd)

    # Additional test in case something went wrong by creating the xfiles
    ltmp_xfile=glob.glob('x*'+sdoy)
    lxfile_ok=[]
    for xfile in ltmp_xfile:
        lxfile_ok.append(xfile[1:5])

    ################################################################################
    # Running fixdrv 
    ################################################################################

    fixdrv = 'd'+args.expt + syr[-1]+'.'+sdoy
    cmd='fixdrv '+fixdrv+' >> log.'+log_suffix 
    print("=> Running ",cmd)
    subprocess.getstatusoutput(cmd)



    ################################################################################
    # Running solution 
    ################################################################################

    batch = 'b'+args.expt+syr[-1]+'.bat'
    #print "batch : ",batch
    os.chmod(batch, stat.S_IRWXU)
    cmd='./'+batch+' >> log.'+log_suffix
    print("=> Running ",cmd)
    subprocess.getstatusoutput(cmd)

    ################################################################################
    # Changing names 
    ################################################################################

    hfile='h'+args.expt+'a'+'.'+syr+sdoy
    hfilesubnetwork='hsu'+subnetwork+'a'+'.'+syr+sdoy
    print("=> Renaming ",hfile,'into ',hfilesubnetwork)
    os.rename(hfile,hfilesubnetwork)

    qfile='q'+args.expt+'a'+'.'+sdoy
    qfilesubnetwork='qsu'+subnetwork+'a'+'.'+sdoy
    print("=> Renaming ",qfile,'into ',qfilesubnetwork)
    os.rename(qfile,qfilesubnetwork)
    

    ################################################################################
    # CLEANING DOY PROCESSING DIRECTORY 
    ################################################################################

    l2copy=glob.glob("log*")
    for ffile in l2copy:
        target='../'+ffile
        shutil.copy(ffile,target) 
    l2copy=glob.glob("hsu*")
    for ffile in l2copy:
        target='../'+ffile
        shutil.copy(ffile,target) 
    l2copy=glob.glob("qsu*")
    for ffile in l2copy:
        target='../'+ffile
        shutil.copy(ffile,target) 
    l2copy=glob.glob("GAMIT*")
    for ffile in l2copy:
        target='../'+ffile+'.'+subnetwork
        shutil.copy(ffile,target) 
        
    os.chdir('..')

    ################################################################################
    # END DOY PROCESSING 
    ################################################################################
        
    
    ################################################################################
    # NOW DOING COMBINATION 
    ################################################################################
    
    # uncompress files
    
    cmd='uncompress -v *.Z'
    print("=> Running ",cmd)
    subprocess.getstatusoutput(cmd)

    cmd='gunzip -v *.gz'
    print("=> Running ",cmd)
    subprocess.getstatusoutput(cmd)

    cmd='htoglb . \'\' hsu*'
    print("=> Running ",cmd)
    subprocess.getstatusoutput(cmd)
    
    # first convert the hfiles -> glx

    cmd='htoglb . \'\' hsu*'
    print("=> Running ",cmd)
    subprocess.getstatusoutput(cmd)
    
    lglr=glob.glob('*glr')
    for ffile in lglr:os.remove(ffile)
    
    # creates the gdl file
    lglx=glob.glob('*.glx')
    f_lgdl=open('lgdl','w')
    f_lgdl.write("%s\n" % lglx.pop())
    for ffile in lglx:f_lgdl.write("%s +\n" % ffile)
    
    f_lgdl.close()
    
    # creates the globk cmd file
    
    fglobk=open('globk_comb.cmd','w')
    
    fglobk.write(" apr_file tables/%s\n" % lfile)    
    fglobk.write(' apr_neu all 10 10 10 0 0 0\n')    
    fglobk.write(' apr_wob 10 10 0 0\n')    
    fglobk.write(' apr_ut1 10  0\n')
    GLX='H'+args.expt+'_'+syear+sdoy+'.GLX'    
    fglobk.write(" out_glb %s\n" % GLX)    
    fglobk.close()    
    
    # now runs GLOBK  

    suffix=args.expt+'_'+syear+'_'+sdoy
    cmd='globk 6 PRT.'+suffix+' LOG.'+suffix+' lgdl globk_comb.cmd'
    print("=> Running ",cmd)
    subprocess.getstatusoutput(cmd)

    # now converts to sinex  
    sinex='H'+args.expt+'_'+syear+sdoy+'.snx'
    cmd='glbtosnx . \'\' '+GLX+' '+sinex
    print("=> Running ",cmd)
    subprocess.getstatusoutput(cmd)
    

    llog=glob.glob('pre_proc/log/*')
    for log in llog:
        basename_log=log.split('/')[-1]
        shutil.copy(log,basename_log)
    
    lhfiles=glob.glob('h*.*')
    for hfile in lhfiles:
        f_in = open(hfile, 'r',encoding="latin-1")
        f_out = gzip.open(hfile+'.gz', 'wb')
        f_out.writelines(f_in)
        f_out.close()
        f_in.close()
        os.remove(hfile)

    # we reduce sinex to save space

    cmd='ls *.snx > lsinex'
    print("=> Running ",cmd)
    subprocess.getstatusoutput(cmd)

    cmd='pyacs_reduce_sinex.py -l lsinex -o . -e ss'
    print("=> Running ",cmd)
    subprocess.getstatusoutput(cmd)

    cmd='rm -f *.snx'
    print("=> Running ",cmd)
    subprocess.getstatusoutput(cmd)
    
    # now we run a simple helmert transformation

    cmd='ls *.ss > lsinex'
    print("=> Running ",cmd)
    subprocess.getstatusoutput(cmd)
    
    cmd='touch pyacs_conf.dat'
    print("=> Running ",cmd)
    subprocess.getstatusoutput(cmd)

    cmd='pyacs_make_time_series.py  --lsinex lsinex --ref_sinex /projet/gps/geodesy/igs/IGS11P18.snx.ss          --discontinuity /projet/gps/geodesy/igs/soln.snx --conf_file pyacs_conf.dat --experiment helmert'
    print("=> Running ",cmd)
    subprocess.getstatusoutput(cmd)

    # we update the apr
    
    cmd='pygamit_update_apr.py -t '+path_aprf+ ' -d helmert/stat/pyacs.apr -s 0.3'    
    print("=> Running ",cmd)
    subprocess.getstatusoutput(cmd)
    
    # removing tables directory to save space

    if args.clean == 'Y':
        cmd='rm -Rf pre_proc'
        print("=> Running ",cmd)
        subprocess.getstatusoutput(cmd)
    
 
    os.chdir('..')
    #os.rename(proc_dir, proc_dir[0:3])
