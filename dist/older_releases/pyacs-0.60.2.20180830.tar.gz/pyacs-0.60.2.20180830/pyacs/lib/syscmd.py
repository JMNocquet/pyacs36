"""
Runs a system commands
"""

class Error(Exception):
    """Base class for exceptions in module syscmd."""
    pass

class ReturnedCodeError(Exception):
    """Exception raised for returned code not 0."""
    pass


def getstatusoutput(cmd):

    import subprocess

    if isinstance(cmd,str):
        cmd = cmd.split()

    print("-- Running system command:|%s|" % " ".join( cmd ) )

    try:
        completed = subprocess.run(
            cmd,
            check=True,
            shell=True,
            stdout=subprocess.PIPE,
        )
    except subprocess.CalledProcessError as err:
        print('!!! ERROR in subprocess.run:', err)

    else:
        
        if completed.returncode != 0:

            raise ReturnedCodeError( "!!! ERROR returned code is not 0 %d:" , completed.returncode )
            print('!!! ERROR:', err)
            print('!!! stdout: {!r}'.format(
                len(completed.stdout),
                completed.stdout.decode('utf-8')))
            
        else:
            print('stdout: {!r}'.format(
                len(completed.stdout),
                completed.stdout.decode('utf-8')))

