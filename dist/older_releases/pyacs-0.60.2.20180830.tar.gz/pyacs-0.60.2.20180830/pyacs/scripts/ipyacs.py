#!/usr/local/geodesy/anaconda/bin/python
version='0.02'
print("-- Welcome to pyacs interactive environment -- version ",version)
import sys, os
print("- Importing pyacs core module")
import pyacs
print("- Importing pyacs.gts module")
from pyacs.gts.Sgts import Sgts
from pyacs.gts.Gts import Gts
print("- Importing numpy as np")
import numpy as np
print("- Importing matplotlib.pyplot as plt")
import matplotlib.pyplot as plt

print('- Trying to read time series files')
ts=Sgts()

