#!/usr/bin/env python

"""Automated GAMIT processing using the cluster at Geoazur
   Uses GAMIT/GLOBK netsel program to define subnetworks
   
   Change 09/02/2016
   The best strategy now uses atm_disp file instead of atm_disp_filt
   It also looks for the latest atm_dis file
   
   the directory tables from pygeca is changed to pre_proc for compatibility with sh_sp3fit
   
   Jean-Mathieu Nocquet - April 2012 - Updated from geca in perl
   Report bug to nocquet@geoazur.unice.fr
"""
###################################################################
# MODULES IMPORT
###################################################################

import sys, os, stat
#sys.path.append(os.environ['PYACS_DIR'])
import argparse
import subprocess
import gzip
import shutil
from time import gmtime, strftime, localtime
import math

from glob import glob

from pyacs.lib import astrotime as AstroTime
from pyacs.lib import gpstime as GpsTime
from pyacs.lib import coordinates as Coordinates
from pyacs.lib import pygamit_module


gamit_path=os.environ['GAMIT']
if not os.path.exists(gamit_path):
    print("=> ",gamit_path, " directory does not exist. Check your GAMIT configuration in .bashrc or .bash_profile. Exiting...")
    sys.exit()
else:
    gamit_tables_path=gamit_path+'/tables'
    print("=> GAMIT tables to be found in ", gamit_tables_path)

#grd_path=gamit_path+'/../grids'
grd_path='/projet/gps/geodesy/grids'
print("=> GAMIT grids to be found in ", grd_path)

brdc_path=os.environ['BRDC']
print("=> Broadcats files to be found in ", brdc_path)

sp3_path=os.environ['ORBIT']
print("=> Sp3 files to be found in ", sp3_path)

###################################################################
# PARAMETERS
###################################################################

min_rinex_size=100 # minimum size (Kb) for a rinex file to be processed
nsites_subnetwork='25'
nties='4'

###################################################################
# PARSE ARGUMENT LINE
###################################################################

prog_info="Runs gamit with automatic subnetworking"
prog_epilog="J.-M. Nocquet (Geoazur-CNRS/IRD) - May 2012"

parser = argparse.ArgumentParser()
parser.add_argument('--dir_conf', required=True, action='store', type=str, dest='dir_conf',help='directory including configuration files')
parser.add_argument('--sd', action='store', type=int, dest='start_doy',help='starting doy')
parser.add_argument('--ed', action='store', type=int, dest='end_doy',help='end doy')
parser.add_argument('--ld', action='append', type=int, dest='list_doy',help='list of doy to be processed', default=[])
parser.add_argument('--year', required=True, action='store', type=int, dest='year',help='year')
parser.add_argument('--type', action='store', type=str, dest='type_analysis',help='best|precise|rapid', default='best')
parser.add_argument('--experiment', required=True, action='store', type=str, dest='expt',help='experiment name')
parser.add_argument('--clean', action='store', type=str, dest='clean',help='clean option [Y/N], default yes', default='Y')
parser.add_argument('--sessinfo', action='store', type=str, dest='sessinfo',help='session info argument for time window to be processed', default='30 00 00 2880')
#parser.add_argument('--until', action='store', type=str, dest='until',help='[INIT/SETUP/TABLES/ORBIT/RINEX/PREPROC/PROC/CLEAN]', default=None)
#parser.add_argument('--step', action='store', type=str, dest='step',help='[INIT/SETUP/TABLES/ORBIT/RINEX/PREPROC/PROC/CLEAN]', default=None)

if (len(sys.argv)<2):parser.print_help()
    
args = parser.parse_args()

if not (args.year and args.expt and args.dir_conf):
    parser.print_help()
    sys.exit()
if not ((args.start_doy and args.end_doy) or args.list_doy):
    parser.print_help()
    sys.exit()
if args.start_doy and args.end_doy:
    smjd=AstroTime.dayno2mjd(args.start_doy, args.year, ut=0.0)
    emjd=AstroTime.dayno2mjd(args.end_doy, args.year, ut=0.0)
    for mjd in range(int(smjd),int(emjd)+1):
        (doy,year,ut)=AstroTime.mjd2dayno(mjd)
        args.list_doy.append(doy)

###################################################################
# CHECK CONFIGURATION DIRECTORY
###################################################################

if not os.path.exists(args.dir_conf):
    print("=> ",args.dir_conf, " directory does not exist. Exiting...")
    sys.exit()

if args.type_analysis == 'best':
    conf_file='sestbl.best'

if args.type_analysis == 'precise':
    conf_file='sestbl.precise'
    
if args.type_analysis == 'rapid':
    conf_file='sestbl.rapid'

path_sestbl=args.dir_conf+'/'+conf_file

if not os.path.exists(path_sestbl):
    print("=> ",path_sestbl, " missing. Exiting...")
    sys.exit()


print("=> Processing strategy: ",args.type_analysis)


# check station.info 
    
path_conf_file=args.dir_conf+'/station.info'
if not os.path.exists(path_conf_file):
    print("=> station.info ",path_conf_file, " missing. Exiting...")
    sys.exit()



###################################################################
# READS SITE.DEFAULTS
###################################################################

lsite=[]

   
site_defaults=args.dir_conf+'/sites.defaults'
fs=open(site_defaults,'r')
for line in fs:
    if line[0]=='#' or len(line) < 3 or line[1]==' ':continue
    lline=line.split()
           
    if '_gps' in lline[0] and args.expt in lline[1]:lsite.append(lline[0][0:4])
fs.close()
    
    


###################################################################
# LOOP ON LDOY
###################################################################

for doy in args.list_doy:
    year = args.year
    syear=str(args.year)
    syr=syear[-2:]
    sdoy="%03d" % doy

    log_suffix=args.expt+'_'+syear+'_'+sdoy

    log_pygeca='log_pygeca_'+log_suffix

    flog=open(log_pygeca,'w')


    print("=> Processing doy:",sdoy," year:",syear)
    

    ###################################################################
    # CREATES PROCESSING DIRECTORY
    ###################################################################
    
    
    time_suffix=strftime("%a_%d_%b_%Y_%H_%M_%S", gmtime())
    proc_dir= "%s_%s_%s_%s" % (os.environ['USER'],args.expt,syear,sdoy)
    if not os.path.exists(proc_dir):
        flog.write("=> Creating proc_dir: %s \n" % proc_dir)
        os.makedirs(proc_dir)
    else:
        flog.write("=> Removing %s directory\n" % (proc_dir))
        shutil.rmtree(proc_dir)
        flog.write("=> Creating proc_dir: %s \n" % proc_dir)
        os.makedirs(proc_dir)


    os.chdir(proc_dir)
    flog.write("=> Processing doy: %s year %s: strategy %s\n" %(sdoy,syear,args.type_analysis))
    flog.write("=> Created proc_dir %s \n" %proc_dir)

    flog.write("=> Processing Start time: %s\n" % (strftime("%Y/%m/%d %H:%M:%S", localtime())))
     
    flog.write("=> Creating pre_proc directory\n")
    os.makedirs('pre_proc')

    flog.write("=> cd to preproc\n")
    os.chdir('pre_proc')

    
    ###################################################################
    # LINK GAMIT SETUP FILES
    ###################################################################

    flog.write("=> Linking GAMIT setup files\n")
 
    ###################################################################
    # sestbl
    ###################################################################
    
    os.symlink(path_sestbl, 'sestbl.')
    print("=> Linking ",path_sestbl," to sestbl.")
    flog.write("=> Linking %s to sestbl." % path_sestbl)

    ###################################################################
    # station.info
    ###################################################################

    path_stn_info=args.dir_conf+'/station.info'
    os.symlink(path_stn_info, 'station.info')
    print("=> Linking ",path_stn_info," to station.info")
    flog.write("=> Linking %s to station.info" % path_stn_info)
    

    ###################################################################
    # gamit tables from dir tables in current tables directory
    ###################################################################
    
    lgamit_tables=('autcln.cmd','sittbl.','rcvant.dat','leap.sec','antmod.dat','svnav.dat','hi.dat',\
                   'svs_exclude.dat','gdetic.dat','eq_rename','dcb.dat','otlcmc.dat')
    
    for table in lgamit_tables:
        path_table=args.dir_conf+'/'+table
        if not os.path.exists(path_table):
            flog.write("=> %s not present; Linking from %s \n" % (path_table,gamit_tables_path))
            path_table=gamit_tables_path+'/'+table
        flog.write("=> Linking %s to %s\n" % (path_table,table))
        os.symlink(path_table,table)

    ###################################################################
    # LINK GAMIT TABLES FILES
    ###################################################################
    
    flog.write("=> Linking astronomical tables\n")
    # nutbl.
    os.symlink(gamit_tables_path+'/nutabl.'+syear,'nutabl.')
    # soltab
    os.symlink(gamit_tables_path+'/soltab.'+syear+'.J2000','soltab.')
    # luntab
    os.symlink(gamit_tables_path+'/luntab.'+syear+'.J2000','luntab.')
    # ut1
    os.symlink(gamit_tables_path+'/ut1.usno','ut1.')
    # pole
    os.symlink(gamit_tables_path+'/pole.usno','pole.')


    ###################################################################
    # LINKING GRIDS
    ###################################################################


    flog.write("=> Linking grids\n")

    # get the latest atmdisp and vmf1 grids
    
    atmlgrd=glob(grd_path+'/atmdisp_cm.'+syear+'*').pop()
    vmf1grd=glob(grd_path+'/vmf1grd.'+syear+'*').pop()

    os.symlink(atmlgrd,'atml.grid')
    os.symlink(vmf1grd,'map.grid')
    os.symlink(vmf1grd,'met.grid')
    
    lgamit_grid=('atl.grid','otl.grid')
    for grid in lgamit_grid:
        if not os.path.exists(grd_path+'/'+grid):
            print("=> ",grd_path+'/'+grid, "missing; Exiting...")
            flog.write("=> %s/%s missing; Exiting...\n" % (grd_path,grid))
            sys.exit()
        else:
            os.symlink(grd_path+'/'+grid,grid)
            
    ################################################################################
    # ORBITS
    ################################################################################
    
    flog.write("=> Dealing with orbits\n")

    (day,month)=AstroTime.dayno2cal(doy,args.year)
    
    (gpsWeek, gpsSOW, gpsDay, gpsSOD)=GpsTime.gpsFromUTC(args.year, month, day, 0, 0, 0, leapSecs=30)

    gweek="%04d" % gpsWeek + str(gpsDay)
    
    nav_file = 'brdc'+ sdoy +'0.'+ syr +'n'
    if (args.type_analysis == 'rapid'): 
        sp3_file = 'igr'+gweek+'.sp3'
    else:
        sp3_file = 'igs'+gweek+'.sp3'

    print(("=> Linking orbit %s and brdc %s" %(sp3_file,nav_file)))
    flog.write("=> Linking orbit %s and brdc %s\n" %(sp3_file,nav_file))


    os.symlink(brdc_path +'/'+nav_file,nav_file)
    os.symlink(sp3_path +'/'+sp3_file,sp3_file)

#Modified by P. Jarrin for running in Macbook
    cmd="sh_sp3fit -f "+sp3_file+" -gnss G  -o igsg -u -d "+syear+" "+sdoy+" -m 0.100"
#    cmd="sh_sp3fit -f "+sp3_file+" -u -o igsf -u -m 0"
#    cmd="sh_sp3fit -f "+sp3_file+" -u -o igsf -u -m 0.20"
    print("=> Running ",cmd)
    flog.write("=> Running %s\n" % cmd)
    subprocess.getstatusoutput(cmd)
    out_tfile='tigs'+gweek+'.sp3'
    tfile='tigsf'+syr[-1]+'.'+sdoy
    #gfile = 'gigsf'+syr[-1]+'.'+sdoy
#Modified by P. Jarrin for running in Macbook
    gfile = 'gigsg'+syr[-1]+'.'+sdoy    
    #print "=> Renaming ",out_tfile," -> ",tfile
    #shutil.move(out_tfile,tfile)
    
    if os.path.isfile(gfile): 
        print("=> sh_sp3fit OK.")
        flog.write("=> sh_sp3fit OK.\n")
    else:
        print("=> Problem running sh_sp3fit")
        flog.write("=> Problem running sh_sp3fit")
        sys.exit()
        
    
    ################################################################################
    # RINEX
    ################################################################################
    
    # Get the directories from process.defaults
    
    process_defaults=args.dir_conf+'/process.defaults'
    flog.write("=> Reading %s \n" % process_defaults)
    ldir_rinex=[]
    fs=open(process_defaults,'r')
    for line in fs:
        if line[0]=='#' or len(line) < 3:continue
        lline=line.split()
        if 'rnxfnd' in lline[1]:ldir_rinex.append(lline[-1].replace('"',''))
        if 'aprf' in lline[1]:aprf=lline[-1]
    fs.close()
    
    # list the rinex files

    flog.write("=> Reading rinex directories\n")
    
    lrinex=[]
    for rinex_dir in ldir_rinex:
        lrinex_dir=glob(rinex_dir+'/'+syear+'/'+sdoy+'/*')
        print(("=> Found %d rinex in directory %s" % (len(lrinex_dir),rinex_dir)))
        flog.write("=> Found %d rinex in directory %s\n" % (len(lrinex_dir),rinex_dir))
        lrinex+=lrinex_dir
    
    # link the rinex files if site code is in sites.defaults
    
    nrinex=0
    lavailable_site=[]

    
    for rinex in sorted(lrinex):
        rinex_basename=rinex.split('/')[-1]
        #print rinex_basename
        if (rinex_basename[0:4].lower() in lsite):
            lavailable_site.append(rinex_basename[0:4].lower())
            if not os.path.exists(rinex_basename) and os.path.getsize(rinex)/1024>min_rinex_size:
                os.symlink(rinex,rinex_basename)
                nrinex+=1
                
    print("=> Found ",nrinex," rinex files in directories")
    flog.write("=> Found %d rinex files in directories\n" % (nrinex))
 

    lfile = 'l'+args.expt+syr[-1]+'.'+sdoy
    path_aprf=args.dir_conf+'/'+aprf
    flog.write("=> Using pygamit_module.make_apr_doy to build apr from %s\n" % path_aprf)
    pygamit_module.make_apr_doy(path_aprf,lfile, lavailable_site, doy, year)
 
    # uncompressing rinex files
    
    cmd="sh_crx2rnx -f *.Z"
    print("=> Running ",cmd)
    flog.write("=> Running %s\n" % cmd)
    subprocess.getstatusoutput(cmd)

################################################################################
# LOOP ON RINEX ONE BY ONE TO AVOID GAMIT LIMITATION TO 99 SITES
################################################################################
    
    ################################################################################
    # Creating j-file
    ################################################################################

    jfile = 'jbrdc'+syr[-1]+'.'+sdoy
    cmd="makej "+nav_file+" "+jfile+" >> log."+log_suffix
    print("=> Running for rinex ",rinex,cmd)
    flog.write("=> Running %s for rinex %s\n" % (cmd,rinex))
    subprocess.getstatusoutput(cmd)
    
    
    # rename the rinex files
    llrinex=glob('????[0-3][0-9][0-9]?.'+syr+'o')
    for rinex in sorted(llrinex):
        rinex_moved=rinex+'.pygeca'
        os.rename(rinex,rinex_moved)
    
    # start the loop
    llrinex_moved=glob('????[0-3][0-9][0-9]?.'+syr+'o'+'.pygeca')
    
    for rinex_moved in sorted(llrinex_moved):
        rinex=rinex_moved[:12]
        os.rename(rinex_moved,rinex)
    
    
        ################################################################################
        # RUNNING SH_MAKEXP
        ################################################################################
       
        #Modified by P. Jarrin for running in Macbook
        #cmd="sh_makexp -expt "+args.expt+" -orbt IGSF -yr "+syear+" -doy "+sdoy+" -nav "+nav_file+" -sinfo "+args.sessinfo
        cmd="sh_makexp -expt "+args.expt+" -orbt igsg -sp3file "+sp3_file+" -yr "+syear+" -doy "+sdoy+" -sess 99 -srin -nav "+nav_file+" -jclock brdc -sinfo "+args.sessinfo+" -xver 7 -gnss G"        

        print("=> Running for rinex ",rinex,cmd)
        flog.write("=> Running %s for rinex %s\n" % (cmd,rinex))
        subprocess.getstatusoutput(cmd)

        cmd="sh_check_sess -sess "+sdoy+" -type gfile -file "+gfile+" >> log."+log_suffix
        print("=> Running ",cmd)
        flog.write("=> Running %s\n" % cmd)
        subprocess.getstatusoutput(cmd)
 
        cmd="sh_check_sess -sess "+sdoy+" -type jfile -file "+jfile+" >> log."+log_suffix
        print("=> Running ",cmd)
        flog.write("=> Running %s\n" % cmd)
        subprocess.getstatusoutput(cmd)

    
        ################################################################################
        # Running makex 
        ################################################################################
        makex_batch = args.expt + '.makex.batch'
        cmd='makex '+makex_batch+' >> log.'+log_suffix
        print("=> Running for rinex ",rinex,cmd)
        flog.write("=> Running %s\n for rinex %s" % (cmd,rinex))
        subprocess.getstatusoutput(cmd)

        os.rename(rinex,rinex_moved)


    # rename rinex files again
    llrinex_moved=glob('????[0-3][0-9][0-9]?.'+syr+'o'+'.pygeca')
    
    for rinex_moved in sorted(llrinex_moved):
        rinex=rinex_moved[:12]
        os.rename(rinex_moved,rinex)



    # needs to check again SVS list to be included in the session.info


    
    print("=> Checking satellite list from gfile & jfile to update session.info")

    ################################################################################
    # RUNNING SH_MAKEXP
    ################################################################################
    [sampling_rate,sh,sm,epochs]=list(map(int,args.sessinfo.split()))
    str_session_info="# Session.info : free format, non-blank first column is comment"
    str_session_info+="\n#Year Day  Sess#  Interval  #Epochs  Start hr/min  Satellites"
    str_session_info+="\n %4d %03d    1        %02d     %04d     %02d  %02d      1  2  3  4  5  6  7  8  9 10 11 12 13 14 15 16 17 18 19 20 21 22 23 25 26 27 28 29 30 31 32" % (year,doy,sampling_rate,epochs,sh,sm)

    fs=open('session.info','w')
    fs.write("%s" % str_session_info)
    fs.close()
   
#    cmd="sh_makexp -expt "+args.expt+" -orbt IGSF -yr "+syear+" -doy "+sdoy+" -nav "+nav_file+" -sinfo "+args.sessinfo
#    print "=> Running again sh_makexp to recreate session.info ",cmd
#    flog.write("=> Running again sh_makexp to recreate session.info %s\n" % (cmd))
#    commands.getstatusoutput(cmd)

#    cmd="sh_check_sess -sess "+sdoy+" -type gfile -file "+gfile+" >> log."+log_suffix
#    print "=> Running ",cmd
#    flog.write("=> Running %s\n" % cmd)
#    commands.getstatusoutput(cmd)
# 
#     cmd="sh_check_sess -sess "+sdoy+" -type jfile -file "+jfile+" >> log."+log_suffix
#     print "=> Running ",cmd
#     flog.write("=> Running %s\n" % cmd)
#     commands.getstatusoutput(cmd)


    # Additional test in case something went wrong by creating the xfiles
    flog.write("=> Keeping only good xfiles\n")
    ltmp_xfile=glob('x*'+sdoy)
    lxfile_ok=[]
    for xfile in ltmp_xfile:
        lxfile_ok.append(xfile[1:5])


    ################################################################################
    # Defines subnetworks 
    ################################################################################

    flog.write("=> Defining subnetwork using netsel\n")
    cmd='ls -s *'+syr+'o > lrinex' 
    print("=> Running ",cmd)
    flog.write("=> Running %s\n" % cmd)
    subprocess.getstatusoutput(cmd)
    
    # Creates a GLOBK velocity file
    
    flog.write("=> Creating globk.vel\n")
    fglobk=open('globk.vel','w')
    fapr=open(lfile,'r')
    for line in fapr:
        if (len(line)<5 or line[0]!=' '):continue
        lline=line.split()
        (site,X,Y,Z)=lline[0:4]
        (longitude,latitude,h)=Coordinates.xyz2geo(float(X),float(Y),float(Z))
        longitude=math.degrees(longitude)
        if longitude<0.:longitude+=360.
        latitude=math.degrees(latitude)
        fglobk.write(" %10.5lf %10.5lf    00.00   00.00   00.00   00.00   00.00   00.00 00.000     00.00   00.00   00.00 %s\n" %(longitude,latitude,site))
    fglobk.close()
    fapr.close()

    # runs netsel
    
    cmd='netsel -f lrinex -v globk.vel -n '+nsites_subnetwork+' -t '+nties+' -s station.info -c su > netsel.out'
    print("=> Running ",cmd)
    flog.write("=> Running %s\n" % cmd)
    subprocess.getstatusoutput(cmd)

    # reads netsel output
    
    H_subnetwork={}
    
    dnetsel_out=open('netsel.out','r')
    for line in dnetsel_out:
        if not '_gps' in line:continue
        lline=line.split()
        gps_site=lline[0][0:4]
        subnetwork=lline[1]
        if subnetwork not in H_subnetwork:H_subnetwork[subnetwork]=[]
        if gps_site in lxfile_ok and (not gps_site in H_subnetwork[subnetwork]):H_subnetwork[subnetwork].append(gps_site)
    
    tie_subnetwork=sorted(H_subnetwork.keys())[-1]

    ltie_gps=H_subnetwork[tie_subnetwork]
    #print 'ltie_gps ',ltie_gps 
    del H_subnetwork[tie_subnetwork]
    print("=> Division into subnetworks finished.")
    flog.write("=> Division into subnetworks finished.\n")
    print("=> ",len(list(H_subnetwork.keys()))," subnetworks")
    flog.write("=> %d subnetworks\n" % len(list(H_subnetwork.keys())))

    for key in sorted(H_subnetwork.keys()):
        print('=> network #',key, 'nb sites: ',len(H_subnetwork[key]))
        flog.write("=> network #%s nb sites: %d\n" % (key,len(H_subnetwork[key])))
        print(" ".join(map(str, H_subnetwork[key])))        #print H_subnetwork[key]
        sstr= " ".join(map(str, H_subnetwork[key]))
        flog.write("=> %s\n " % sstr)
        
        for gps_site in ltie_gps:
            if gps_site in lxfile_ok and (not gps_site in H_subnetwork[key]):H_subnetwork[key].append(gps_site)
        #print 'network #',key
        #print H_subnetwork[key]
    print('=> Number of tie sites: ',len(ltie_gps),': '," ".join(map(str, ltie_gps)))
    #print " ".join(map(str, ltie_gps))
    sstr=" ".join(map(str, H_subnetwork[key]))        
    flog.write("=> Tie sites %d %s\n" % (len(ltie_gps),sstr))

        #print H_subnetwork[key]

    ################################################################################
    # runs solution for each sub-network 
    ################################################################################

    os.chdir('..')
    for subnetwork in sorted(H_subnetwork.keys()):
        print("=> Now processing subnetwork #",subnetwork)
        flog.write("=> Now processing subnetwork #%s\n" % subnetwork)
        os.mkdir(subnetwork)
        os.chdir(subnetwork)
        nsite_subnetwork=len(H_subnetwork[subnetwork])
        #print '=> (H_subnetwork[subnetwork])',(H_subnetwork[subnetwork])
        #flog.write("=> (H_subnetwork[subnetwork]): %s\n" % (H_subnetwork[subnetwork]))
        #print '=> nsite_subnetwork ',nsite_subnetwork
        flog.write("=> nsite_subnetwork %d\n" % nsite_subnetwork)
        
        log_suffix=args.expt+'_'+syear+'_'+sdoy+'_'+subnetwork

        ################################################################################
        # link tables
        ################################################################################

        flog.write("=> Linking pre_proc\n")
        ltables=glob('../pre_proc/*')
        for ffile in ltables:
            basename_file=ffile.split('/')[-1]
            os.symlink(ffile,basename_file)

        flog.write("=> Removing unnecessary xfiles for this subnetwork\n")
        lxfiles=glob('x*'+sdoy)
        for xfile in lxfiles:
            if not xfile[1:5] in H_subnetwork[subnetwork]:
                #print "removing ",xfile;
                os.remove(xfile)
                #flog.write("=> Removing %s\n" % xfile)

        flog.write("=> Removing unnecessary rinex files for this subnetwork\n")
        lrxfiles=glob('*'+sdoy+'*.'+syr+'o')
        for rxfile in lrxfiles:
            if not rxfile[1:5] in H_subnetwork[subnetwork]:
                #print "removing ",xfile;
                os.remove(rxfile)
                #flog.write("=> Removing %s\n" % xfile)
        
        #Modified by P. Jarrin for running in Macbook
        cmd="sh_makexp -expt "+subnetwork+" -orbt igsg -sp3file "+sp3_file+" -yr "+syear+" -doy "+sdoy+" -sess 99 -srin -nav "+nav_file+" -jclock brdc -sinfo "+args.sessinfo+" -xver 7 -gnss G"
        #cmd="sh_makexp -expt "+subnetwork+" -orbt IGSF -yr "+syear+" -doy "+sdoy+" -nav "+nav_file+" -sinfo "+args.sessinfo
        print("=> Running again sh_makexp to recreate session.info ",cmd)
        flog.write("=> Running again sh_makexp to recreate session.info %s\n" % (cmd))
        subprocess.getstatusoutput(cmd)

        cmd="sh_check_sess -sess "+sdoy+" -type gfile -file "+gfile+" >> log."+log_suffix
        print("=> Running ",cmd)
        flog.write("=> Running %s\n" % cmd)
        subprocess.getstatusoutput(cmd)
 
        cmd="sh_check_sess -sess "+sdoy+" -type jfile -file "+jfile+" >> log."+log_suffix
        print("=> Running ",cmd)
        flog.write("=> Running %s\n" % cmd)
        subprocess.getstatusoutput(cmd)


        
        ################################################################################
        # Creates new dfile
        ################################################################################

        lxfiles=glob('x*'+sdoy)
        

        dfile='d'+args.expt+syr[-1]+'.'+sdoy
        os.remove(dfile)
        tables_dfile='../pre_proc/'+dfile
        f_tables_dfile=open(tables_dfile,'r')
        dfile='d'+subnetwork+syr[-1]+'.'+sdoy
        flog.write("=> Creating new dfile %s\n" % dfile)
        f_dfile=open(dfile,'w')
        nline=0
        nb_line_max=5
        for line in f_tables_dfile:
                f_dfile.write("%s" % line)
                nline+=1
                if nline > nb_line_max:break
        
        f_tables_dfile.close()
        f_dfile.write("%02d\n" % nsite_subnetwork)
        for xfile in lxfiles:
            f_dfile.write("%s\n" % xfile)
        f_dfile.close()
        
        ################################################################################
        # Runs fixdrv again 
        ################################################################################
        fixdrv = 'd'+subnetwork + syr[-1]+'.'+sdoy
        cmd='fixdrv '+fixdrv+' >> log.'+log_suffix 
        print("=> Running ",cmd)
        flog.write("=> Running %s\n" % cmd)
        subprocess.getstatusoutput(cmd)

        ################################################################################
        # Running solution 
        ################################################################################

    
        batch = 'b'+subnetwork+syr[-1]+'.bat'
        #print "batch : ",batch
        os.chmod(batch, stat.S_IRWXU)
        cmd='./'+batch+' >> log.'+log_suffix
        print("=> Running ",cmd)

        flog.write("=> Running %s\n" % cmd)
        flog.write("=> Processing Start time: %s\n" % (strftime("%Y/%m/%d %H:%M:%S", localtime())))
        subprocess.getstatusoutput(cmd)
        flog.write("=> Processing End   time: %s\n" % (strftime("%Y/%m/%d %H:%M:%S", localtime())))
    
        ################################################################################
        # CLEANING DOY PROCESSING DIRECTORY 
        ################################################################################

        flog.write("=> Cleaning subnetwork processing directory\n")
        print("=> Cleaning subnetwork processing directory\n")
        l2copy=glob("log*")
        for ffile in l2copy:
            target='../'+ffile
            shutil.copy(ffile,target) 
        l2copy=glob("hsu*")
        for ffile in l2copy:
            target='../'+ffile
            shutil.copy(ffile,target) 
        l2copy=glob("q????a.???")
        for ffile in l2copy:
            target='../'+ffile
            shutil.copy(ffile,target) 
        l2copy=glob("GAMIT*")
        for ffile in l2copy:
            target='../'+ffile+'.'+subnetwork
            shutil.copy(ffile,target) 
            
        os.chdir('..')
        if args.clean == 'Y':shutil.rmtree(subnetwork)
        ################################################################################
        # END DOY PROCESSING 
        ################################################################################
            

    ################################################################################
    # CHECK WHETHER ALL SITES HAVE PROCESSED 
    ################################################################################

    flog.write("=> End of subnetworks processing\n")
    print("=> End of subnetworks processing\n")
    flog.write("=> Checking whether all sites have been processed correctly\n")
    print("=> Checking whether all sites have been processed correctly\n")
    
    dec_year=year+doy/365.25
    lqfile=glob('q????a.???')
    lmissing=[]
    for qfile in lqfile:
        (n_total_ambiguity,n_NL_fixed_ambiguity,n_WL_fixed_ambiguity,lsite_not_calculated,lfit,normal_stop)\
        =pygamit_module.read_qfile(qfile)
        for site in lsite_not_calculated:
            if site not in lmissing:lmissing.append(site)
    
    ################################################################################
    # REDO A PROCESSING IF NOT 
    ################################################################################
    l_to_be_processed=[]
    if len(lmissing)!=0:
        print("=> There are missing sites; Try to process them")
        flog.write("=> There are missing sites; Try to process them in a small subnetwork\n")
        from numpy import array,median

        str_missing=''
        for site in lmissing:
            str_missing=str_missing+' '+site
            l_to_be_processed.append(site.lower())
        print("=> sites to be reprocessed (initial coordinates re-determined):",str_missing)
        flog.write("=> sites to be reprocessed (initial coordinates re-determined): %s\n" % str_missing)
        os.chdir('pre_proc')
        
    # looping on missing sites
    
    for site in lmissing:
        # rinex 
        
        print("=> Processing ",site)
        flog.write("=> Processing %s\n" % site)
        #print site.lower()+sdoy+'*'+'.'+syear[-2:]+'o'
        lrinex=glob(site.lower()+sdoy+'*'+'.'+syear[-2:]+'o')
        rinex=lrinex[0]
        # runs teqc
        cmd='teqc +qc -nav '+nav_file+' '+rinex
        print("=> Running ",cmd)
        flog.write("=> Running %s\n" % cmd)
        subprocess.getstatusoutput(cmd)
        # reads teqc result
        teqc_S=rinex[:-1]+'S'
        #print "reading1 XYZ in ",teqc_S
        fteqc=open(teqc_S)
        for line in fteqc:
            #print line
            if ' antenna WGS 84 (xyz)' in line:
                #print "reading2 XYZ in ",teqc_S
                #print float(line.split()[5]),float(line.split()[6]),float(line.split()[7])
                (X,Y,Z)=float(line.split()[5]),float(line.split()[6]),float(line.split()[7])
                break
        fteqc.close()

        # now replace the header coordinates, so that rx2apr starts with good a priori
        cmd='cp -f '+rinex+' rinex'
        print("=> Running ",cmd)
        flog.write("=> Running %s\n" % cmd)
        subprocess.getstatusoutput(cmd)
        
        cmd='teqc -O.px '+str(X)+' '+str(Y)+' '+str(Z)+' rinex > '+rinex
        print("=> Running ",cmd)
        flog.write("=> Running %s\n" % cmd)
        subprocess.getstatusoutput(cmd)
        
        
        lexclude=[site.lower()]
        # now gets the apr lines corresponding three nearest neighbor from apr file
        flog.write("=> Getting nearest sites for %s fron %s\n" % (site, lfile))

        lapr=pygamit_module.get_nearest_from_apr(lfile,3,lavailable_site,lexclude,X,Y,Z,dec_year)
        
        #print "lapr ",lapr
        # write a small temporary apr
        lref=[]
        fapr=open('tmp.apr','w')
        for line in lapr:
            wline=line+"\n"
            fapr.write(wline)
            lref.append(line[1:5].lower())
        fapr.close()
        # now runs make_rx2apr
        
        for ref in lref:
            # automatically adds closest sites in the re-processing
            if ref.lower() not in l_to_be_processed:l_to_be_processed.append(ref.lower())
            cmd='make_rx2apr  -d . -u '+site.lower()+' -r '+ref.lower()+ ' -t tmp.apr' 
            print("=> Running ",cmd)
            flog.write("=> Running %s\n" % cmd)
            subprocess.getstatusoutput(cmd)
        
        # now gets the apr for site
        # take the median of the 3 differential pseudo-range result
        flog.write("=> Taking median position as new a priori coordinates\n")
        
        lnew_apr=glob(site.lower()+'.apr.*')
        XX=[];YY=[];ZZ=[]   
        for new_apr in lnew_apr:
            fnew_apr=open(new_apr)
            lline=fnew_apr.readline().split()
            XX.append(float(lline[1]))
            YY.append(float(lline[2]))
            ZZ.append(float(lline[3]))
        
        NEW_APP_X=median(array(XX))
        NEW_APP_Y=median(array(YY))
        NEW_APP_Z=median(array(ZZ))
        
        #print "NEW ",NEW_APP_X,NEW_APP_Y,NEW_APP_Z
        print("=> Adding a new line in ",lfile," for site ",site)
        flog.write("=> Adding a new line in %s for site %s\n" % (lfile,site))
        pygamit_module.substitute_site(lfile,site,NEW_APP_X,NEW_APP_Y,NEW_APP_Z,dec_year)

 
        # General comments
        # we want a minimum of 10 sites and two sites per subnetworks
        # we therefore start by inspecting each subnetwork

        flog.write("=> Now building a small subnetwork, sharing at leat 2 sites with previous subnetworks\n")
        # reads netsel output
        
        H_subnetwork={}
        import random 
        flog.write("=> Reading previous netsel.out\n")
        dnetsel_out=open('netsel.out','r')
        for line in dnetsel_out:
            if not '_gps' in line:continue
            lline=line.split()
            gps_site=lline[0][0:4]
            subnetwork=lline[1]
            #print "gps_site subnetwork ",gps_site,subnetwork
            if subnetwork not in H_subnetwork:H_subnetwork[subnetwork]=[]
            if not gps_site in H_subnetwork[subnetwork]:H_subnetwork[subnetwork].append(gps_site)
            
        
        tie_subnetwork=sorted(H_subnetwork.keys())[-1]
    
        ltie_gps=H_subnetwork[tie_subnetwork]
        #print 'ltie_gps ',ltie_gps 
        del H_subnetwork[tie_subnetwork]
        print("=> Subnetworks read.")
        flog.write("=> Subnetworks read.\n")
        print("=> ",len(list(H_subnetwork.keys()))," subnetworks found")
        for key in sorted(H_subnetwork.keys()):
            print('=> network #',key, 'nb sites: ',len(H_subnetwork[key]))
            print(" ".join(map(str, H_subnetwork[key])))        #print H_subnetwork[key]
            for gps_site in ltie_gps:
                if not gps_site in H_subnetwork[key]:H_subnetwork[key].append(gps_site)
            #print 'network #',key
            #print H_subnetwork[key]
        print('=> tie sites: ',len(ltie_gps))
        print(" ".join(map(str, ltie_gps)))        
            #print H_subnetwork[key]
        
        # now adds some more sites in each subnetworks if needed
        
        for subnetwork in sorted(H_subnetwork.keys()):
            print("=> Now checking subnetwork #",subnetwork)
            flog.write("=> Now checking subnetwork #%s\n" % subnetwork)
            n_site_in_this_subnetwork=0
            for site in l_to_be_processed:
                if site in H_subnetwork[subnetwork]:n_site_in_this_subnetwork=n_site_in_this_subnetwork+1
            print("=> Found ",n_site_in_this_subnetwork, " in subnetwork #",subnetwork)
            flog.write("=> Found %d in subnetwork #%s\n" % (n_site_in_this_subnetwork,subnetwork))
            
            # if less than two sites, choose randomly a site until getting two sites
    
            rnd_indx=random.randint(0,len(H_subnetwork[subnetwork])-1)
            site=H_subnetwork[subnetwork][rnd_indx]
            
            while n_site_in_this_subnetwork<2:
                while site.lower() in l_to_be_processed:
                    rnd_indx=random.randint(0,len(H_subnetwork[subnetwork])-1)
                    site=H_subnetwork[subnetwork][rnd_indx]
                print("=> Adding ",site.lower()," from subnetwork #",subnetwork," to reprocessing list")
                flog.write("=> Adding %s from subnetwork #%s  to reprocessing list\n" % (site.lower(),subnetwork))
                l_to_be_processed.append(site.lower())
                n_site_in_this_subnetwork=n_site_in_this_subnetwork+1
    
        # check that a least 10 sites will be reprocessed
        
        if (len(l_to_be_processed))<10:
            nmissing=10-len(l_to_be_processed)
            print("=> Still missing ",nmissing," sites")
            flog.write("=> Still missing %d sites\n" % nmissing)
            rnd_subnetwork=random.randint(0,len(list(H_subnetwork.keys()))-1)
            subnetwork=list(H_subnetwork.keys())[rnd_subnetwork]
            rnd_indx=random.randint(0,len(H_subnetwork[subnetwork])-1)
            site=H_subnetwork[subnetwork][rnd_indx]
            
            while len(l_to_be_processed)<10:
                while site.lower() in l_to_be_processed:
                    rnd_subnetwork=random.randint(0,len(list(H_subnetwork.keys()))-1)
                    subnetwork=list(H_subnetwork.keys())[rnd_subnetwork]
                    rnd_indx=random.randint(0,len(H_subnetwork[subnetwork])-1)
                    site=H_subnetwork[subnetwork][rnd_indx]
                l_to_be_processed.append(site.lower())
                flog.write("=> Adding %s\n" % site)
        
        # now, we have the final list of sites for re-processing
        
        str_to_be_processed=''
        for site in l_to_be_processed:
            str_to_be_processed=str_to_be_processed+' '+site
        print(("=> Final list of sites to be (re)processed: #%3d\n" % (len(l_to_be_processed))))    
        print(str_to_be_processed)
        flog.write("=> Final list of sites to be (re)processed: #%3d\n" % (len(l_to_be_processed)))
        flog.write("=> %s\n" % str_to_be_processed)
        
        # we can remove unused xfiles
        
        flog.write("=> Removing unnecessary rinex and xfiles\n")
        llrinex=glob('????'+sdoy+'*.*o')
        lx=glob('x????'+sdoy+'*')

        for rinex in llrinex:
            if rinex[0:4] not in l_to_be_processed:
                print("=> Removing ",rinex)
                flog.write("Removing %s\n" % rinex)
                os.remove(rinex)
    
        for x in lx:
            if x[1:5] not in l_to_be_processed:
                print("=> Removing ",x)
                flog.write("Removing %s\n" % x)
                os.remove(x)

        # reprocessing is a new subnetwork
        subnetwork="%02d" % (len(list(H_subnetwork.keys()))+1)
        log_suffix=args.expt+'_'+syear+'_'+sdoy+'_'+subnetwork
    
    
        ################################################################################
        # RUNNING SH_MAKEXP
        ################################################################################
      
        #Modified by P. Jarrin for running in Macbook
        cmd="sh_makexp -expt "+args.expt+" -orbt igsg -sp3file "+sp3_file+" -yr "+syear+" -doy "+sdoy+" -sess 99 -srin -nav "+nav_file+"      -jclock brdc -sinfo "+args.sessinfo+" -xver 7 -gnss G" 
        #cmd="sh_makexp -expt "+args.expt+" -orbt IGSF -yr "+syear+" -doy "+sdoy+" -nav "+nav_file+" -sinfo 30 00 00 2880"
        print("=> Running ",cmd)
        flog.write("=> Running %s\n" % cmd)
        subprocess.getstatusoutput(cmd)
       
    # needs to check again SVS list to be included in the session.info
    
        print("=> Checking satellite list from gfile to update session.info")
        flog.write("=> Checking satellite list from gfile to update session.info\n")
    
        cmd="sh_check_sess -sess "+sdoy+" -type gfile -file "+gfile+" >> log."+log_suffix
        print("=> Running ",cmd)
        flog.write("=> Running %s\n" % cmd)
        subprocess.getstatusoutput(cmd)
    
        ################################################################################
        # Creating j-file
        ################################################################################
    
        jfile = 'jbrdc'+syr[-1]+'.'+sdoy
        cmd="makej "+nav_file+" "+jfile+" >> log."+log_suffix
        print("=> Running ",cmd)
        flog.write("=> Running %s\n" % cmd)
        subprocess.getstatusoutput(cmd)
    
        cmd="sh_check_sess -sess "+sdoy+" -type jfile -file "+jfile+" >> log."+log_suffix
        print("=> Running ",cmd)
        flog.write("=> Running %s\n" % cmd)
        subprocess.getstatusoutput(cmd)
            
        # Additional test in case something went wrong by creating the xfiles
        flog.write("=> Double check on xfiles\n")
        ltmp_xfile=glob('x*'+sdoy)
        lxfile_ok=[]
        for xfile in ltmp_xfile:
            lxfile_ok.append(xfile[1:5])
    
        ################################################################################
        # Running fixdrv 
        ################################################################################
    
        fixdrv = 'd'+args.expt + syr[-1]+'.'+sdoy
        cmd='fixdrv '+fixdrv+' >> log.'+log_suffix 
        print("=> Running ",cmd)
        flog.write("=> Running %s\n" % cmd)
        subprocess.getstatusoutput(cmd)
    
    
        ################################################################################
        # Running solution 
        ################################################################################
    
        batch = 'b'+args.expt+syr[-1]+'.bat'
        #print "batch : ",batch
        os.chmod(batch, stat.S_IRWXU)
        cmd='./'+batch+' >> log.'+log_suffix
        print("=> Running ",cmd)
        flog.write("=> Running %s\n" % cmd)
        flog.write("=> Processing Start time: %s\n" % (strftime("%Y/%m/%d %H:%M:%S", localtime())))
        subprocess.getstatusoutput(cmd)
        flog.write("=> Processing End   time: %s\n" % (strftime("%Y/%m/%d %H:%M:%S", localtime())))
    
        ################################################################################
        # Changing names 
        ################################################################################
    
        hfile='h'+args.expt+'a'+'.'+syr+sdoy
        hfilesubnetwork='hsu'+subnetwork+'a'+'.'+syr+sdoy
        print("=> Renaming ",hfile,'into ',hfilesubnetwork)
        flog.write("=> Renaming %s into %s\n" % (hfile,hfilesubnetwork))
        os.rename(hfile,hfilesubnetwork)
    
        qfile='q'+args.expt+'a'+'.'+sdoy
        qfilesubnetwork='qsu'+subnetwork+'a'+'.'+sdoy
        print("=> Renaming ",qfile,'into ',qfilesubnetwork)
        flog.write("=> Renaming %s into %s\n" % (qfile,qfilesubnetwork))
        os.rename(qfile,qfilesubnetwork)
        
    
        ################################################################################
        # CLEANING DOY PROCESSING DIRECTORY 
        ################################################################################

        flog.write("=> Cleaning directory\n")
    
        l2copy=glob("log*")
        for ffile in l2copy:
            target='../'+ffile
            shutil.copy(ffile,target) 
        l2copy=glob("hsu*")
        for ffile in l2copy:
            target='../'+ffile
            shutil.copy(ffile,target) 
        l2copy=glob("qsu*")
        for ffile in l2copy:
            target='../'+ffile
            shutil.copy(ffile,target) 
        l2copy=glob("GAMIT*")
        for ffile in l2copy:
            target='../'+ffile+'.'+subnetwork
            shutil.copy(ffile,target) 
            
        os.chdir('..')
     

    ################################################################################
    # NOW DOING COMBINATION 
    ################################################################################
        
    # first convert the hfiles -> glx

    cmd='htoglb . \'\' hsu*'
    print("=> Running ",cmd)
    flog.write("=> Running %s\n" % cmd)
    subprocess.getstatusoutput(cmd)
    
    lglr=glob('*glr')
    for ffile in lglr:os.remove(ffile)
    
    # creates the gdl file
    flog.write("=> Creating lgdl file\n")
    lglx=glob('*.glx')
    f_lgdl=open('lgdl','w')
    f_lgdl.write("%s\n" % lglx.pop())
    for ffile in lglx:f_lgdl.write("%s +\n" % ffile)
    
    f_lgdl.close()
    
    # creates the globk cmd file
    flog.write("=> Creating globk_comb.cmd\n")
    
    fglobk=open('globk_comb.cmd','w')
    
    fglobk.write(" apr_file pre_proc/%s\n" % lfile)    
    fglobk.write(' apr_neu all 10 10 10 0 0 0\n')    
    fglobk.write(' apr_wob 10 10 0 0\n')    
    fglobk.write(' apr_ut1 10  0\n')
    GLX='H'+args.expt+'_'+syear+sdoy+'.GLX'    
    fglobk.write(" out_glb %s\n" % GLX)    
    fglobk.close()    
    
    # now runs GLOBK  

    suffix=args.expt+'_'+syear+'_'+sdoy
    cmd='globk 6 PRT.'+suffix+' LOG.'+suffix+' lgdl globk_comb.cmd'
    print("=> Running ",cmd)
    flog.write("=> Running %s\n" % cmd)
    subprocess.getstatusoutput(cmd)

    # now converts to sinex  
    sinex='H'+args.expt+'_'+syear+sdoy+'.snx'
    cmd='glbtosnx . \'\' '+GLX+' '+sinex
    print("=> Running ",cmd)
    flog.write("=> Running %s\n" % cmd)
    subprocess.getstatusoutput(cmd)
    

    flog.write("=> Saving netsel.out file\n")
    shutil.copy('pre_proc/netsel.out','netsel.out')
    llog=glob('pre_proc/log/*')
    for log in llog:
        basename_log=log.split('/')[-1]
        shutil.copy(log,basename_log)
    
    if args.clean == 'Y':
        cmd='rm -Rf pre_proc'
        print("=> Running ",cmd)
        flog.write("=> Running %s\n" % cmd)
        subprocess.getstatusoutput(cmd)

    flog.write("=> Compressing hfiles\n")
    
    lhfiles=glob('h*')
    for hfile in lhfiles:
        f_in = open(hfile, 'rb')
        f_out = gzip.open(hfile+'.gz', 'wb')
        f_out.writelines(f_in)
        f_out.close()
        f_in.close()
        os.remove(hfile)

    # we reduce sinex to save space

    cmd='ls *.snx > lsinex'
    print("=> Running ",cmd)
    flog.write("=> Running %s\n" % cmd)
    subprocess.getstatusoutput(cmd)

    cmd='pyacs_reduce_sinex.py -l lsinex -o . -e ss'
    print("=> Running ",cmd)
    flog.write("=> Running %s\n" % cmd)
    subprocess.getstatusoutput(cmd)

    cmd='rm -f *.snx'
    print("=> Running ",cmd)
    flog.write("=> Running %s\n" % cmd)
    subprocess.getstatusoutput(cmd)
    
    # now we run a simple helmert transformation

    cmd='ls *.ss > lsinex'
    print("=> Running ",cmd)
    flog.write("=> Running %s\n" % cmd)
    subprocess.getstatusoutput(cmd)
    
    cmd='touch pyacs_conf.dat'
    print("=> Running ",cmd)
    flog.write("=> Running %s\n" % cmd)
    subprocess.getstatusoutput(cmd)

    cmd='pyacs_make_time_series.py  --lsinex lsinex --ref_sinex /projet/gps/geodesy/igs/IGS.ssc          --discontinuity /projet/gps/geodesy/igs/soln.snx --conf_file pyacs_conf.dat --experiment helmert'
    print("=> Running ",cmd)
    flog.write("=> Running %s\n" % cmd)
    subprocess.getstatusoutput(cmd)

    # we update the apr
    
    cmd='pygamit_update_apr.py -t '+path_aprf+ ' -d helmert/stat/pyacs.apr -s 0.05'    
    print("=> Running ",cmd)
    flog.write("=> Running %s\n" % cmd)
    subprocess.getstatusoutput(cmd)

    flog.write("=> Processing End   time: %s\n" % (strftime("%Y/%m/%d %H:%M:%S", localtime())))
    
    flog.close()
    
    os.chdir('..')
