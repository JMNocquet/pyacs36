#!/usr/bin/python

"""Finds the rinex files available for a given experiment giving the name of sites and period 
   
   Jean-Mathieu Nocquet - April 2012 - Updated from geca in perl
   Report bug to nocquet@geoazur.unice.fr
"""
###################################################################
# MODULES IMPORT
###################################################################


import sys, os
sys.path.append(os.environ['PYACS_DIR'])
import argparse
from glob import glob

from pyacs.lib import astrotime as AstroTime
from pyacs.lib import gpstime as GpsTime

###################################################################
# PARSE ARGUMENT LINE
###################################################################

parser = argparse.ArgumentParser()
parser.add_argument('-dir_conf', required=True,action='store', type=str, dest='dir_conf',help='directory including configuration files')
parser.add_argument('--sd', action='store', type=int, dest='start_doy',help='starting doy')
parser.add_argument('--ed', action='store', type=int, dest='end_doy',help='end doy')
parser.add_argument('--ld', action='append', type=int, dest='list_doy',help='list of doy to be processed', default=[])
parser.add_argument('-year', required=True, action='store', type=int, dest='year',help='year')
parser.add_argument('--site', action='store', type=str, dest='site',help='4-letters site name')
parser.add_argument('--experiment', action='store', type=str, dest='expt',help='experiment name')
parser.add_argument('--check', action='store', type=str, dest='check',help='full check [YES/NO]', default='NO')

if (len(sys.argv)<2):parser.print_help()
    
args = parser.parse_args()

lsite=[args.site.lower()]

if not (args.year and args.expt and args.dir_conf):
    parser.print_help()
    sys.exit()
if not ((args.start_doy and args.end_doy) or args.list_doy):
    parser.print_help()
    sys.exit()
if args.start_doy and args.end_doy:
    smjd=AstroTime.dayno2mjd(args.start_doy, args.year, ut=0.0)
    emjd=AstroTime.dayno2mjd(args.end_doy, args.year, ut=0.0)
    for mjd in range(int(smjd),int(emjd)+1):
        (doy,year,ut)=AstroTime.mjd2dayno(mjd)
        args.list_doy.append(doy)

syear=str(args.year)

min_rinex_size=100 # minimum size (Kb) for a rinex file to be processed


smjd_site=AstroTime.dayno2mjd(args.start_doy, args.year, ut=0.0)
emjd_site=AstroTime.dayno2mjd(args.end_doy, args.year, ut=0.0)


###################################################################
# CHECK EXPERIMENT CONFIGURATION DIRECTORY
###################################################################

print(("=> Checking experiment %s directory %s" % (args.expt, args.dir_conf)))

if not os.path.exists(args.dir_conf):
    print(("=> ERROR: directory %s does not exist. Exiting..." % args.dir_conf))
    
lconf_files=['process.defaults']
for conf_file in (lconf_files):
    path_conf_file=args.dir_conf+'/'+conf_file
    if not os.path.exists(path_conf_file):
        print("=> ERROR: ",path_conf_file, " missing.")
print ("=> Experiment configuration files OK.")


###################################################################
# READS process.defaults
###################################################################

    # Get the directories from process.defaults
    
process_defaults=args.dir_conf+'/process.defaults'


ldir_rinex=[]
fs=open(process_defaults,'r')
for line in fs:
    if line[0]=='#' or len(line) < 3:continue
    lline=line.split()
    if 'rnxfnd' in lline[1]:ldir_rinex.append(lline[-1].replace('"',''))
    if 'aprf' in lline[1]:aprf=args.dir_conf+'/'+lline[-1]
fs.close()

###################################################################
# READS APR files
###################################################################

print("=> Reading apr file", aprf)

lapr=[]

fapr=open(aprf,'r')
for line in fapr:
    if (len(line)<5 or line[0]!=' '):continue
    lline=line.split()
    (site,X,Y,Z)=lline[0:4]
    lapr.append(site.lower()[0:4])
fapr.close()

print("=> apr file OK.")

###################################################################
# READS AVAILABLE RINEX
###################################################################

H_rinex={}

for doy in args.list_doy:
    syear=str(year)
    syr=syear[-2:]
    sdoy="%03d" % doy

    log_suffix=args.expt+'_'+syear+'_'+sdoy

    #print "=> Reading rinex files for doy:",sdoy," year:",syear
    

    if not os.path.exists(aprf):print("ERROR: apr file read in process.defaults not found :",aprf)
    
    # list the rinex files
    lrinex=[]
    for rinex_dir in ldir_rinex:
        lrinex+=glob(rinex_dir+'/'+syear+'/'+sdoy+'/*')
    
    # link the rinex files if site code is in sites.defaults
    
    nrinex=0
    
    for rinex in lrinex:
        rinex_basename=rinex.split('/')[-1]
        site_rinex=rinex_basename[0:4].lower()
        doy_rinex=rinex_basename[4:7]
        if site_rinex == args.site:
            mjd=AstroTime.dayno2mjd(int(doy_rinex), year, ut=0.0)
            if (mjd> smjd_site and mjd < emjd_site):
                print("=> Found %s" % rinex)
            if site_rinex in H_rinex:
                H_rinex[site_rinex].append(doy_rinex)
            else:
                H_rinex[site_rinex]=[doy_rinex]
        #print os.path.getsize(rinex),min_rinex_size
#        if os.path.getsize(rinex)/1024. <min_rinex_size:print "=> WARNING: small rinex file ",rinex


print("=> End of rinex listing.")

if args.check != 'NO':

    ###################################################################
    # WARNS ABOUT MISSING DATA
    ###################################################################
    
    
    
    print("=> Checking for missing data")
    
    for site in sorted(H_rinex.keys()):
        str_missing_doy=''
        for doy in args.list_doy:
            sdoy="%03d" % doy
            if sdoy not in H_rinex[site]:str_missing_doy+=sdoy+' '
        if len(str_missing_doy)>2: print(("=> WARNING missing doys for %s: %s" % (site,str_missing_doy)))
    
    ###################################################################
    # CHECKING SITES.DEFAULTS CONTENT
    ###################################################################
    
    print("=> Checking sites.defaults file vs rinex")
    
    for site in sorted(H_rinex.keys()):
        if site not in lsite: print(("=> WARNING site %s not in sites.defaults" % (site)))
        
    ###################################################################
    # ERROR ABOUT MISSING SITES in apr file
    ###################################################################
    
    print("=> Checking rinex list vs apr file ",aprf)
    
    #print lapr
    
    for site in sorted(H_rinex.keys()):
        if site not in lapr:
            if site in lsite:
                print(("=> ERROR: site %s not in aprf file %s" % (site, aprf)))
            else:
                print(("=> WARNING: if to be processed, site %s not in aprf file %s" % (site, aprf)))
                
    ###################################################################
    # CHECK STATION INFO FILE
    ###################################################################
    
    station_info=args.dir_conf+'/station.info'
    print("=> Checking station.info ",station_info)
    
    H_station_info={}
    
    
    
    # Reads station info file
    
    site_previous=''
    smjd_site=AstroTime.dayno2mjd(1,2100, ut=0.0)
    emjd_site=AstroTime.dayno2mjd(1, 1980, ut=0.0)
    
    #print smjd_site,emjd_site
    
    buffer=False
    
    fstnfo=open(station_info,'r')
    for line in fstnfo:
        #print line
        if (len(line)<5 or line[0]!=' '):continue
        lline=line.split()
        site=lline[0].lower()
        reste=line[25:].split()
        if site != site_previous and buffer:
            #print 'writting info for ',site_previous
            H_station_info[site_previous]=(smjd_site,emjd_site)
            #print H_station_info
            site_previous=site
            smjd_site=AstroTime.dayno2mjd(1,2100, ut=0.0)
            emjd_site=AstroTime.dayno2mjd(1, 1980, ut=0.0)
            buffer=False
    
        if site not in list(H_rinex.keys()):continue
        
        
        buffer=True
        #print 'site ',site    
        #print line
        (syear,sdoy)=list(map(int,(reste[0],reste[1])))
        (eyear,edoy)=list(map(int,(reste[5],reste[6])))
    
        if syear==0:syear=1980
        if syear==9999:syear=2100
        if sdoy==0:sdoy=1
        if sdoy==999:sdoy=365
        
        if eyear==0:eyear=1980
        if eyear==9999:eyear=2100
        if edoy==0:edoy=1
        if edoy==999:edoy=365
    
        #print (syear,sdoy)
        #print (eyear,edoy)
        ssmjd_site=AstroTime.dayno2mjd(sdoy, syear, ut=0.0)
        if ssmjd_site<smjd_site:smjd_site=ssmjd_site
        
        esmjd_site=AstroTime.dayno2mjd(edoy, eyear, ut=0.0)
        if esmjd_site>emjd_site:emjd_site=esmjd_site
        site_previous=site
        
    fstnfo.close()
    if site in list(H_rinex.keys()):H_station_info[site]=(smjd_site,emjd_site)
    
    # Now check station.info is OK
    
    #print H_station_info
    
    for site in sorted(H_rinex.keys()):
        for str_doy in H_rinex[site]:
            if site not in H_station_info:
                if site in lsite:
                    print(("=> ERROR: missing info for site : %s in %s/station.info" % (site,args.dir_conf)))
                    break
                else:
                    print(("=> WARNING: missing info for site : %s in %s/station.info (but %s is not in sites.defaults and will not be processed)" % (site,args.dir_conf,site)))
                    break
            doy=int(str_doy)
            mjd=AstroTime.dayno2mjd(doy,year)
            #print doy,year,mjd
            #print H_station_info[site]
            if site in lsite:
                if mjd < H_station_info[site][0] or mjd > H_station_info[site][-1]: print(("=> ERROR: check station.info for site %s doy: %s " % (site,str_doy)))

 