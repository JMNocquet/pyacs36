#!/usr/bin/env python

"""Resubmit missing jobs
"""
###################################################################
# MODULES IMPORT
###################################################################


import sys, os
import argparse

from glob import glob

from pyacs.lib import astrotime as AstroTime

###################################################################
# PARSE ARGUMENT LINE
###################################################################

prog_info="List the missing jobs in a given directory"
prog_epilog="J.-M. Nocquet (Geoazur-CNRS/IRD) - August 2012"

parser = argparse.ArgumentParser()
parser.add_argument('--sd', action='store', type=int, dest='start_doy',help='starting doy')
parser.add_argument('--ed', action='store', type=int, dest='end_doy',help='end doy')
parser.add_argument('--ld', action='append', type=int, dest='list_doy',help='list of doy to be processed', default=[])
parser.add_argument('--year', required=True, action='store', type=int, dest='year',help='year')
parser.add_argument('--experiment', required=True, action='store', type=str, dest='expt',help='experiment name')

if (len(sys.argv)<2):parser.print_help()
    
args = parser.parse_args()

if not ((args.start_doy and args.end_doy) or args.list_doy):
    print("=> Either ld or (sd and ed) should be provided")
    parser.print_help()
    sys.exit()
if args.start_doy and args.end_doy:
    smjd=AstroTime.dayno2mjd(args.start_doy, args.year, ut=0.0)
    emjd=AstroTime.dayno2mjd(args.end_doy, args.year, ut=0.0)
    for mjd in range(int(smjd),int(emjd)+1):
        (doy,year,ut)=AstroTime.mjd2dayno(mjd)
        args.list_doy.append(doy)


###################################################################
# LOOP ON LDOY
###################################################################

for doy in args.list_doy:
    syear=str(year)
    syr=syear[-2:]
    sdoy="%03d" % doy

    proc_dir= "%s_%s_%s_%s" % (os.environ['USER'],args.expt,syear,sdoy)
    job=args.expt+'_'+sdoy+'_'+syear
    
    if not os.path.isdir(proc_dir):
        print(("oarsub -S ./%s -t besteffort" % job))
        continue

    lss=glob(proc_dir+"/*.ss")+glob(proc_dir+"/*.snx")
    if len(lss)!=0:continue

    print(("rm -Rf %s ; oarsub -S ./%s -t besteffort" % (proc_dir,job)))
    
    