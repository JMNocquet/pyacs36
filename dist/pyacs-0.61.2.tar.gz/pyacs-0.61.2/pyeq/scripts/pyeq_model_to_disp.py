#!/usr/bin/env python

###################################################################
# SCRIPT    : pyeq_model_to_disp.py
# AUTHOR    : 
# DATE      : July 2018
# OUTPUT    : 
# NOTE      :
#         
###################################################################


###################################################################
# PYTHON MODULES IMPORT
###################################################################

import argparse, sys
import numpy as np
import math
#import subprocess

###################################################################
# PYACS ADDITIONAL MODULES IMPORT
###################################################################

from pyacs.lib import coordinates
#from pyacs.lib import gmtpoint as GMT_Point
from pyeq.lib import dislocation as Dislocation

###################################################################
# PARSE ARGUMENT LINE
###################################################################

prog_info="pyeq_model_to_disp.py : computes displacements from slip model\n"
prog_epilog="J.-M. Nocquet (Geoazur-CNRS) - May 2012"

parser = argparse.ArgumentParser(description=prog_info,epilog=prog_epilog)
parser.add_argument('-i', action='store', dest='input',required=True,help='file  with lon lat (dec.deg) where displacement will be calculated')
parser.add_argument('-model', action='store', dest='model',required=True,help='slip model')
parser.add_argument('--tde', action='count',default=0,help='triangular dislocations computed using Meade (2007)')
parser.add_argument('--verbose', '-v', action='count', default=0, help='verbose mode')
parser.add_argument('-o', action='store',type=str,required=True, dest='output',help='output file name')

args = parser.parse_args()


if (len(sys.argv)<2):parser.print_help();sys.exit()
#if not (args.pole or args.rake):
#    print "=> ERROR : either --pole or --rake should be provided"
#    sys.exit()
    

# verbose
if args.verbose>0:
    print("-- Verbose mode")
    verbose=True
else:
    verbose=False

# TDE
if args.tde>0:
    from pyeq.lib.meade_tde import tde
    Poisson_Ratio=0.25
    TDE=True
else:
    TDE=False

###############################################################################
# H_FAULTS INITALIZATION
###############################################################################

H_fault_lp={}
H_fault_xy={}

###############################################################################
# READS MODEL
###############################################################################

print("-- reading model ",args.model)
try:
    SGEOMETRY =  np.array(np.asmatrix(np.genfromtxt(args.model)))
    
except:
    print("!!! Could not read ",args.model)
    sys.exit()

# print some informations about the geometry
print(("  -- geometry includes %04d subfaults" % SGEOMETRY.shape[0]))

min_lon=np.min(SGEOMETRY[:,9])
max_lon=np.max(SGEOMETRY[:,9])

min_lat=np.min(SGEOMETRY[:,10])
max_lat=np.max(SGEOMETRY[:,10])

min_depth=np.min(SGEOMETRY[:,11])
max_depth=np.max(SGEOMETRY[:,11])

print(("  -- geometry bounds read from centroids %.5lf/%.5lf/%.5lf/%.5lf and depth %.5lf/%.5lf " % (min_lon,max_lon,min_lat,max_lat,min_depth,max_depth)))

M = np.array( [ [ SGEOMETRY[:,-4].reshape(-1,1) ] , [SGEOMETRY[:,-2].reshape(-1,1) ] ] )
RAKE_MAIN = SGEOMETRY[:,-5]
RAKE_PERP = SGEOMETRY[:,-3]
SGEOMETRY = SGEOMETRY[:,:22]

print("-- Building dislocations from ",args.model)

lindex = np.where( (M[0][0][:,0]==0.) & (M[1][0][:,0]==0.) )
print("--" , lindex[0].size, " subfaults with zero slip. Removing them.")

M = np.delete( M, lindex, axis=2 )
SGEOMETRY = np.delete(SGEOMETRY, lindex, axis=0)
RAKE_MAIN = np.delete(RAKE_MAIN, lindex)
RAKE_PERP = np.delete(RAKE_PERP, lindex)



# TRIANGULAR DISLOCATONS
if TDE:
    X=np.zeros(3)
    Y=np.zeros(3)
    Z=np.zeros(3)
    
    XYZ=np.zeros((3,3))
    
    H_TDE={}
    print("-- Triangular dislocations will be used")

for i in range(SGEOMETRY.shape[0]):

    if verbose:
        print('  -- ',i,' / ',SGEOMETRY.shape[0])
        

    [rdis_long,rdis_lat,rdis_depth,rdis_length,rdis_width,rdis_area,ratio_rdis_tdis,strike,dip,\
     centroid_long,centroid_lat,centroid_depth,\
     tdis_long1,tdis_lat1,tdis_depth1,tdis_long2,tdis_lat2,tdis_depth2,tdis_long3,tdis_lat3,tdis_depth3,\
     tdis_area]=np.array(list(SGEOMETRY[i]))

    # triangular dislocation
    if TDE:
        (X[0],Y[0])=coordinates.geo2flat_earth(tdis_long1,tdis_lat1);Z[0]=tdis_depth1
        (X[1],Y[1])=coordinates.geo2flat_earth(tdis_long2,tdis_lat2);Z[1]=tdis_depth2
        (X[2],Y[2])=coordinates.geo2flat_earth(tdis_long3,tdis_lat3);Z[2]=tdis_depth3
    
    
        XYZ[:,0]=X
        XYZ[:,1]=Y
        XYZ[:,2]=Z
    
        H_TDE[i]=np.copy(XYZ)
        
    # rectangular dislocations
    else:

        depth=math.sqrt(rdis_depth**2)
        index_fault=i
        if (rdis_long > 180.):rdis_long=rdis_long-360.
        
        lon=rdis_long
        lat=rdis_lat
        length=rdis_length
        width=rdis_width
        area=rdis_area
        
        # fake values
        
        rake=0.0
        max_slip=0.0
        
        (x,y)=coordinates.geo2flat_earth(lon,lat)
        dislocation_lp=Dislocation.Dislocation(index_fault, lon, lat, depth, strike, dip, length, width,area, rake, max_slip)
        dislocation_xy=Dislocation.Dislocation(index_fault, x, y, depth, strike, dip, length, width,area, rake, max_slip)
        H_fault_xy[index_fault]=dislocation_xy
        H_fault_lp[index_fault]=dislocation_lp
         
###############################################################################
# READS INPUT LOCATION FILE
###############################################################################


print("-- Reading ",args.input)

try:
    OBS = np.array(np.asmatrix(np.genfromtxt(args.input))[:,:2])
except:
    print('!!! Could not read ',args.input)

array_gps=np.zeros((OBS.shape[0],2))

if TDE:
    SX=np.zeros(OBS.shape[0])
    SY=np.zeros(OBS.shape[0])
    SZ=np.zeros(OBS.shape[0])

print("-- Number of points :", OBS.shape[0])

lon = OBS[:,0]
lat = OBS[:,1]
(x,y)=coordinates.geo2flat_earth(lon,lat)
array_gps = np.array( np.asmatrix(np.array( [x,y] ).T) )


if TDE:
    SX=x
    SY=y

###############################################################################
# CREATES GREEN'S FUNCTIONS MATRIX
###############################################################################

n_dislocations=SGEOMETRY.shape[0]
n_gps=OBS.shape[0]
slip=1.0

print("-- Creating the Green's matrix")

# GREEN IS A TENSOR OF DIM 4
# GREEN(i,j,k,l) is the prediction for dislocation i at site j component k for rake l
# k=0,1,2 = east, north, up
# l=0,1 : rake_00 & rake_90

GREEN=np.zeros((n_dislocations, n_gps, 3,2))

if TDE:
    # observation points
    SX=array_gps[:,0]*1.E3
    SY=array_gps[:,1]*1.E3
    SZ=array_gps[:,0]*0.0

    for index in range(SGEOMETRY.shape[0]):
        
        if verbose:
            print('  -- ',index,' / ',SGEOMETRY.shape[0])
        
        X=H_TDE[index][:,0]*1.E3
        Y=H_TDE[index][:,1]*1.E3
        Z=H_TDE[index][:,2]*1.E3
        Z=np.sqrt(Z**2)
        
        
        U_rake_00=tde.calc_tri_displacements(SX,SY,SZ, X, Y, Z, Poisson_Ratio, -1.0, 0.0,  0.0)
        U_rake_90=tde.calc_tri_displacements(SX,SY,SZ, X, Y, Z, Poisson_Ratio,  0.0, 0.0, -1.0)
        
        green_rake_00=np.zeros((array_gps.shape[0],5))
        green_rake_90=np.zeros((array_gps.shape[0],5))
        
        green_rake_00[:,0:2]=array_gps
        green_rake_90[:,0:2]=array_gps

        green_rake_00[:,2]=U_rake_00['x']
        green_rake_00[:,3]=U_rake_00['y']
        green_rake_00[:,4]=-U_rake_00['z']

        green_rake_90[:,2]=U_rake_90['x']
        green_rake_90[:,3]=U_rake_90['y']
        green_rake_90[:,4]=-U_rake_90['z']

        GREEN[index,:,:,0]=green_rake_00[:,2:5]
        GREEN[index,:,:,1]=green_rake_90[:,2:5]


else:

    for index in H_fault_xy.keys():
        fault_xy=H_fault_xy[index]
        fault_lp=H_fault_lp[index]
            
        green_rake_00=fault_xy.disp_slip_rake(slip,0.0,array_gps)
        green_rake_90=fault_xy.disp_slip_rake(slip,90.0,array_gps)

#        green_rake_00=fault_xy.disp_slip_rake_no_edcmp(slip,0.0,array_gps)
#        green_rake_90=fault_xy.disp_slip_rake_no_edcmp(slip,90.0,array_gps)

        green_en=green_rake_00[:,2:4]
        
        GREEN[index,:,:,0]=green_rake_00[:,2:5]
        GREEN[index,:,:,1]=green_rake_90[:,2:5]

###############################################################################
# RE-ORDERING THE GREEN'S FUNCTIONS MATRIX WITH MAIN & SECONDARY RAKE
###############################################################################

GREEN_4GPS_EAST_RAKE_00=GREEN[:,:,0,0].T
GREEN_4GPS_EAST_RAKE_90=GREEN[:,:,0,1].T

GREEN_4GPS_NORTH_RAKE_00=GREEN[:,:,1,0].T
GREEN_4GPS_NORTH_RAKE_90=GREEN[:,:,1,1].T

GREEN_4GPS_UP_RAKE_00=GREEN[:,:,2,0].T
GREEN_4GPS_UP_RAKE_90=GREEN[:,:,2,1].T

   
RAKE_RADIANS=np.radians(RAKE_MAIN)
CONJUGATE_RAKE_RADIANS=np.radians(RAKE_PERP)

# Now calculating the Green's functions in the principal rake direction

GREEN_4GPS_EAST_RAKE_PRINCIPAL =np.cos(RAKE_RADIANS)*GREEN_4GPS_EAST_RAKE_00+np.sin(RAKE_RADIANS)*GREEN_4GPS_EAST_RAKE_90
GREEN_4GPS_NORTH_RAKE_PRINCIPAL=np.cos(RAKE_RADIANS)*GREEN_4GPS_NORTH_RAKE_00+np.sin(RAKE_RADIANS)*GREEN_4GPS_NORTH_RAKE_90

GREEN_4GPS_EAST_RAKE_CONJUGATE=np.cos(CONJUGATE_RAKE_RADIANS)*GREEN_4GPS_EAST_RAKE_00+np.sin(CONJUGATE_RAKE_RADIANS)*GREEN_4GPS_EAST_RAKE_90
GREEN_4GPS_NORTH_RAKE_CONJUGATE=np.cos(CONJUGATE_RAKE_RADIANS)*GREEN_4GPS_NORTH_RAKE_00+np.sin(CONJUGATE_RAKE_RADIANS)*GREEN_4GPS_NORTH_RAKE_90

GREEN_4GPS_UP_RAKE_PRINCIPAL=np.cos(RAKE_RADIANS)*GREEN_4GPS_UP_RAKE_00+np.sin(RAKE_RADIANS)*GREEN_4GPS_UP_RAKE_90
GREEN_4GPS_UP_RAKE_CONJUGATE=np.cos(CONJUGATE_RAKE_RADIANS)*GREEN_4GPS_UP_RAKE_00+np.sin(CONJUGATE_RAKE_RADIANS)*GREEN_4GPS_UP_RAKE_90

# setting G

G = np.array( [ [ GREEN_4GPS_EAST_RAKE_PRINCIPAL,GREEN_4GPS_NORTH_RAKE_PRINCIPAL,GREEN_4GPS_UP_RAKE_PRINCIPAL] , \
                [ GREEN_4GPS_EAST_RAKE_CONJUGATE,GREEN_4GPS_NORTH_RAKE_CONJUGATE,GREEN_4GPS_UP_RAKE_CONJUGATE] ] )

print("-- size of the MODEL_MATRIX G ",G.shape)

###############################################################################
# COMPUTING MODEL PREDICTIONS
###############################################################################

D_OBS = np.squeeze( np.sum( np.matmul(G,M) , axis=0 ).T )

D_OBS = np.array( np.asmatrix(D_OBS) )

###############################################################################
# SAVING RESULTS
###############################################################################

RESULTS = np.vstack( ( OBS.T , D_OBS.T ) ).T

np.savetxt(args.output, RESULTS, fmt="%10.6lf %10.6lf %10.3lf %10.3lf %10.3lf ", header=("predictions from %s" % args.model) )


