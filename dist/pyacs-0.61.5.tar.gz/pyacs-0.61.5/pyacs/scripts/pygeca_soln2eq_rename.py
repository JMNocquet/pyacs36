#!/usr/bin/env python


###################################################################
# SCRIPT    : pygeca_soln_2_eq_rename.py
# AUTHOR    : JM NOCQUET
# DATE      : April 2012
# INPUT     : soln IGS discontinuity file
# OUTPUT    : eq_rename 
# NOTE      :
#         
###################################################################

###################################################################
# MODULES IMPORT
###################################################################

import sys
import argparse

from pyacs.lib import astrotime as AstroTime


###################################################################
# PARSE ARGUMENT LINE
###################################################################

parser = argparse.ArgumentParser()
parser.add_argument('--soln', action='store', type=str, dest='soln',help='soln IGS discontinuity file downloaded from ftp://igs-rf.ign.fr/pub/discontinuities/soln.snx')
parser.add_argument('--eq_rename', action='store', type=str, dest='eq_rename',help='output eq_rename globk style file')

#if (len(sys.argv)<2):parser.print_help()
    
args = parser.parse_args()

if not (args.soln and args.eq_rename):
    parser.print_help()
    sys.exit()


###################################################################
# READS SOLN
###################################################################

feq_rename=open(args.eq_rename,'w')
fsoln=open(args.soln,'r')

for line in fsoln:
    #print line
    if line[0]!=' ':continue
    lline=line.split()
    code=lline[0]
    soln=int(lline[2])
    str_sdate=lline[4]
    str_edate=lline[5]
    if soln < 2:continue
    
    (syr,sdoy,shour)=list(map(int,str_sdate.split(':')))
    if syr>80:eyear=1900+syr
    else: 
        if syr==0 and sdoy==0:
            syear=1980
            sdoy=1
        else:
            syear=2000+syr
    (smday,smonth)=AstroTime.dayno2cal(sdoy, syear)
    
    (eyr,edoy,ehour)=list(map(int,str_edate.split(':')))
    
    
    
    print((eyr,edoy,ehour))
    if eyr>80:eyear=1900+eyr
    else: 
        if eyr==0 and edoy==0:
            eyear=2100
            edoy=1
        else:
            eyear=2000+eyr
    print(edoy, eyear)
    (emday,emonth)=AstroTime.dayno2cal(edoy, eyear)
    
    feq_rename.write(" rename  %s     %s_%02dS  %s %02d %02d %02d %02d %s %02d %02d %02d %02d\n" % (code.upper(),code.upper(),soln,syear,smonth,smday,0,0,eyear,emonth,emday,0,0))
    
feq_rename.close()
fsoln.close()