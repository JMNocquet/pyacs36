from setuptools import setup

###############################################################################
# VERSION HISTORY
# 0.60: - for version > 0.60, PYACS is being progressively migrated to python3.6 
# 0.51: - working code with pygeca
# 0.50: - added observation reweighting options. InSAR capability tested. 
# 0.49: - added insar capability in pyeq_static_inversion.py (quick made from Amazonia, after World Cup final, requires more carefully result printing) 
# 0.48: - add pyeq_model_to_disp.py
# 0.47: - adding obs-model displacement psvelo gmt files in pyeq_kinematics.py
#     : - occasional bug in apply_offset corrected (> dev3)
#     : - bug in coordintaes.xyz_spherical_distance (arcos missing) 
# 0.46: - adding pyeq_scaling_laws.py
#     : - adding pyacs/lib/GMT.py for backwards compatibility (> dev2)
# 0.45: - corrected sign error for up Green function using tde in 
#     : - detrend_median added to Gts.model
#     : - bug gts.file -> gts.ifile (for > dev2) 
#     : - automatic shapefiles for cumulative slip and plots of time series in pyeq_kinematic.py/print_log (dev >3)
# 0.44: - datetime_from_calarray added to pyacs.lib.astrotime
#     : - bug corrected in uts2hmsmicros for seconds calculation
#     : - read_tdp added to gts.lib.format
#     : - added itermax=10 option in Gts.lazy
#     : - added force_day to gts to force daily solution at 12:00
#     : - change to gts.format.write_pos to force round at the second
# 0.43: - prototype of new detect_steps methods
# 0.42: - new lazy command with offset detection using a median filter implemented
#        - bug correction in plot when use of date and date_unit='days'
# 0.41: - lazy_pyacs seems to be operational again. Patch in pyeq_parametrize_curve_surface_triangles.py and coordinates for GMT5 compatibility
# 0.40: - geometry and green generation scripts included, as well as the static inversion -not fully operational yet.
# 0.39: - new gts method in Sgts
# 0.38: - this version has been distributed to Vergnolle/DeChabalier/Tissandier/
# 0.35: - slip time dependent modeling operational again
#       - pyacs_qgis_model2polygon.py script added to distribution
###############################################################################

setup(name='pyacs',
      version='0.60.2.20180902',
      description='PYACS: Geodetic analysis and modeling tools for Tectonics',
      long_description='Geodetic analysis and modeling tools for Tectonics.',
 
      classifiers=[
        'Development Status :: 3 - Alpha',
        'License :: OSI Approved :: MIT License',
        'Programming Language :: Python :: 3.6',
        'Topic :: Geodesy :: Geophysics',
      ],
      keywords='geodesy GPS earthquake elastic dislocation tectonics time series',
      url='',
      author='Jean-Mathieu Nocquet (Geoazur, IRD, CNRS, OCA, Cote d Azur University, France)',
      author_email='nocquet@geoazur.unice.fr',
      license='NA',
      packages=['pyacs','pyacs.lib',\
                'pyacs.gts','pyacs.gts.lib',\
                'pyacs.sol','pyacs.sinex'],
#      packages=['pyacs','pyacs.lib','pyacs.lib.Meade_tde','pyacs.gts','pyacs.gts.lib',
#                'pyacs.sinex','pyacs.sol',\
#                'pyeq','pyeq.lib','pyeq.lib.nnls'],
       scripts=[\
                # IPYACS
                'pyacs/scripts/ipyacs.py',\
                # PYACS MAKE TIME SERIES
                'pyacs/scripts/pyacs_make_time_series.py',\
                'pyacs/scripts/pygeca_subnetworks.py'],
#                # QGIS TRANSLATERS
#                'pyacs/scripts/pyacs_qgis_psvelo2shapefile.py',\
#                'pyacs/scripts/pyacs_qgis_model2polygon.py',\
#                'pyacs/scripts/pyacs_qgis_geometry2polygon.py',\
#                # PYACS GAMIT
#                'pyacs/scripts/pyacs_gamit_snx2apr.py',\
#                'pyacs/scripts/pyacs_gamit_soln2eq_rename.py',\
#                # PYACS GVEL POLE & STRAIN
#                'pyacs/scripts/pyacs_gvel_estimate_pole.py',\
#                'pyacs/scripts/pyacs_gvel_estimate_strain.py',\
#                # PYEQ INVERSION
#                'pyeq/scripts/pyeq_kinematic_inversion.py',\
#                'pyeq/scripts/pyeq_static_inversion.py',\
#                # PYEQ GEOMETRY AND GREEN'S FUNCTIONS
#                'pyeq/scripts/pyeq_parametrize_curve_surface_triangles.py',\
#                'pyeq/scripts/pyeq_make_green.py',\
#                'pyeq/scripts/pyeq_model_to_disp.py',\
#                # PYEQ MISC
#                'pyeq/scripts/pyeq_magnitude.py',\
#                'pyeq/scripts/pyeq_scaling_laws.py',\
#                # PYGECA
#                'pygeca/scripts/pygeca_subnetworks.py',\
#                
#                ],
      install_requires=['numpy','scipy','matplotlib','argparse','pyshp','pyaml'],
      zip_safe=False,

      test_suite='nose.collector',
      tests_require=['nose'],
)
