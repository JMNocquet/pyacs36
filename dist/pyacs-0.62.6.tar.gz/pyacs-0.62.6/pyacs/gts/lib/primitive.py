###############################################################################
# TODO
# Check that data_xyz is properly handled for each method
###############################################################################

import inspect

###############################################################################
# PRIVATE FUNCTIONS
###############################################################################

###############################################################################
def __ensure_list_of_list(ll):
###############################################################################
    """
    Ensures ll is a list of lists
    
    [a,b] returns [[a,b]], and [[a,b]] returns [[a,b]]
    """

    # check this is a list
    
    if not isinstance(ll,list):
        raise TypeError('!!! __ensure_list_of_list requires a list or a list of list as argument: ',ll)
    
    # case simple list
    if not isinstance(ll[0],list):
        return([ll])
    # case list of list
    else:
        return(ll)

###############################################################################
# CHECK DATA INTEGRITY
###############################################################################

###############################################################################
def cdata(self,data=False,data_xyz=False, tol= 0.001 ,verbose=False):
###############################################################################
    """
    Check data/data_xyz attributes

    :param data: boolean, if True, data attribute will be checked
    :param data_xyz: boolean, if True, data_xyz attribute will be checked
    :param tol: tolerance in days for two dates to be considered as the same (default 0.001 of day)
    :param verbose: boolean, verbose mode
    
    :return : boolean, True if everything is OK, False otherwise
    """
    
    # import 
    import numpy as np
    from pyacs.gts.lib.errors import GtsInputDataNone , GtsInputData_xyzNone , GtsInputData_allNone
    from pyacs.gts.lib.errors import GtsInputDataTypeError , GtsInputDataBadDim , GtsInputDataBadNcolumns, GtsInputDataBadNrows
    from pyacs.gts.lib.errors import GtsInputData_xyzTypeError , GtsInputData_xyzBadDim , GtsInputData_xyzBadNcolumns, GtsInputData_xyzBadNrows
    from pyacs.gts.lib.errors import GtsInputDataDiffShape , GtsInputDataDiffDate 

    # CASE EITHER data OR data_xyz where asked to be checked
    
    # is there the required data
    try:
        if ( self.data is None ) and ( data ):
            # raise exception
            raise GtsInputDataNone(inspect.stack()[0][3],__name__,self)
    except GtsInputDataNone as error:
        # print PYACS WARNING
        print( error )
        return( False )


    # is there the required data_xyz
    try:
        if ( self.data_xyz is None ) and ( data_xyz ):
            # raise exception
            raise GtsInputData_xyzNone(inspect.stack()[0][3],__name__,self)
    except GtsInputData_xyzNone as error:
        # print PYACS WARNING
        print( error )
        return( False )


    # GENERAL CASE

    # is there some data?
    try:
        if ( self.data is None ) and ( self.data_xyz is None ):
            # raise exception
            raise GtsInputData_allNone(inspect.stack()[0][3],__name__,self)
    except GtsInputData_allNone as error:
        # print PYACS WARNING
        print( error )
        return( False )

    # .data case
    if self.data is not None:
        
        # .data numpy array?
        try:
            if not isinstance(self.data,np.ndarray):
                # raise exception
                raise GtsInputDataTypeError(inspect.stack()[0][3],__name__,self)
        except GtsInputDataTypeError as error:
            # print PYACS WARNING
            print( error )
            return( False )

        # .data with right dimensions?
        try:
            if self.data.ndim != 2:
                # raise exception
                raise GtsInputDataBadDim(inspect.stack()[0][3],__name__,self)
        except GtsInputDataBadDim as error:
            # print PYACS WARNING
            print( error )
            return( False )
        try:
            if self.data.shape[1] not in [7,10]:
                # raise exception
                raise GtsInputDataBadNcolumns(inspect.stack()[0][3],__name__,self)
        except GtsInputDataBadNcolumns as error:
            # print PYACS WARNING
            print( error )
            return( False )

        try:
            if self.data.shape[0] < 1:
                # raise exception
                raise GtsInputDataBadNrows(inspect.stack()[0][3],__name__,self)
        except GtsInputDataBadNrows as error:
            # print PYACS WARNING
            print( error )
            return( False )

    # .data_xyz case
    if self.data_xyz is not None:

        # .data numpy array?
        try:
            if not isinstance(self.data_xyz,np.ndarray):
                # raise exception
                raise GtsInputData_xyzTypeError(inspect.stack()[0][3],__name__,self)
        except GtsInputData_xyzTypeError as error:
            # print PYACS WARNING
            print( error )
            return( False )

        # .data with right dimensions?
        try:
            if self.data_xyz.ndim != 2:
                # raise exception
                raise GtsInputData_xyzBadDim(inspect.stack()[0][3],__name__,self)
        except GtsInputData_xyzBadDim as error:
            # print PYACS WARNING
            print( error )
            return( False )
        try:
            if self.data_xyz.shape[1] not in [7,10]:
                # raise exception
                raise GtsInputData_xyzBadNcolumns(inspect.stack()[0][3],__name__,self)
        except GtsInputData_xyzBadNcolumns as error:
            # print PYACS WARNING
            print( error )
            return( False )

        try:
            if self.data_xyz.shape[0] < 1:
                # raise exception
                raise GtsInputData_xyzBadNrows(inspect.stack()[0][3],__name__,self)
        except GtsInputData_xyzBadNrows as error:
            # print PYACS WARNING
            print( error )
            return( False )

    # check .data and .data_xyz consistency
    
    if ( self.data is not None ) and ( self.data_xyz is not None ):
        # check both have the same length
        try:
            if self.data.shape[0] != self.data_xyz.shape[0]:
                raise GtsInputDataDiffShape(inspect.stack()[0][3],__name__,self)
        except GtsInputDataDiffShape as error:
            # print PYACS WARNING
            print( error )
            return( False )
            
        # check both have the same dates

        try:
            if np.max((self.data[:,0]- self.data_xyz[:,0])**2) > tol / 365.25:
                raise GtsInputDataDiffDate(inspect.stack()[0][3],__name__,self)
        except GtsInputDataDiffDate as error:
            # print PYACS WARNING
            print( error )
            return( False )
            

    return(True)


###################################################################
def reorder(self,verbose=False):
###################################################################
    """
    reorder data and/or data_xyz by increasing dates
    always in place
    
    :param verbose: verbose mode
    """
    
    # import
    import numpy as np
    import pyacs.gts.Gts
    from pyacs.gts.lib.errors import GtsCDataError
    
    # check data
    try:
        if not self.cdata(verbose=verbose):
            raise GtsCDataError(inspect.stack()[0][3],__name__,self)
    except GtsCDataError as error:
        print( error )
        return( self )

        
    # test whether reorder is required
    
    if self.data is not None:
        if self.data.shape[0]>1:
            diff = np.diff(self.data[:,0])
            
            if np.min(diff) < 0:
                if verbose:
                    print('-- data needs to be re-ordered')

            else:
                if verbose:
                    print('-- data does not need to be re-ordered')
                return(self)

        else:
            if verbose:
                print('-- data does not need to be re-ordered')
            
            return(self)
            

    
    else:
        if self.data_xyz.shape[0]>1:
            diff = np.diff(self.data_xyz[:,0])
            
            if np.min(diff) < 0:
                if verbose:
                    print('-- data needs to be re-ordered')

            else:
                if verbose:
                    print('-- data does not need to be re-ordered')
                return(self)

        else:
            if verbose:
                print('-- data does not need to be re-ordered')
            return(self)
        
        
    # save outliers dates before re-ordering - outliers are assumed for .data
    if ( self.outliers != [] ) and ( self.data is not None ):
        ldate_outliers=self.data[:,0][self.outliers]
    else:
        ldate_outliers = []
    
    # reorder
    if isinstance(self.data,np.ndarray):
        lindex=np.argsort(self.data[:,0])
        self.data=self.data[lindex,:]
        
    if isinstance(self.data_xyz,np.ndarray):
        lindex=np.argsort(self.data_xyz[:,0])
        self.data_xyz=self.data_xyz[lindex,:]
    
    # check data
    if not self.cdata(verbose=verbose):
        print('!!! ERROR: .data found to be incorrect by .cdata after reordering. Check time series and results.')
        return(self)

    if verbose:
        print('-- data order OK')
    
    # deal with outliers

    if verbose:
        print('-- updating outliers list for ',self.code)
    
    lupdated_outliers=pyacs.gts.Gts.get_index_from_dates(ldate_outliers, self.data, tol=0.1)
    self.outliers=lupdated_outliers
    
    return(self)

###################################################################
def correct_duplicated_dates(self,action='correct',tol= .1, in_place=False,verbose=False):
###################################################################
    """
    Check or remove duplicated dates in a time series
    
    :param action: 'correct' (default) or 'check'
    :param tol: tolerance for two dates to be considered as the same (default = 0.1 day)
    :param in_place: boolean, if True, 
    :param verbose: verbose mode
    """

    # import
    import numpy as np
    import pyacs.gts.Gts
    from pyacs.gts.lib.errors import GtsCDataError

    # check data
    try:
        if not self.cdata(verbose=verbose):
            raise GtsCDataError(inspect.stack()[0][3],__name__,self)
    except GtsCDataError as error:
        print( error )
        return( self )

    # new_gts
    
    new_gts=self.copy(self)

    # reorder first
    
    self.reorder(verbose=verbose)
    
    # check duplicate
    
    if self.data is not None:
        diff=np.diff(self.data[:,0])
        lindex = np.where(diff < tol / 365.25 )
        if lindex[0].shape[0] > 0:
            if verbose:
                print('-- There are ',len(lindex),' duplicated dates for .data at:')
                
            # some dates are duplicated
            if action == 'check':
                if not verbose:
                    print('-- There are duplicated dates for .data at:')
                for index in lindex:
                    print('-- ',self.data[index,0],' --- ',self.data[index+1,0])
                
                new_data=np.copy(self.data)
                
            if action == 'correct':
                if verbose:
                    print('-- deleting ',lindex[0].shape[0],' entries in Gts')
                # keep the second date
                new_data=np.delete(self.data, lindex, axis=0)
        else:
            new_data=np.copy(self.data)
            if verbose:
                print('-- no duplicated dates in .data for ',self.code)
            
    if self.data_xyz is not None:
        diff=np.diff(self.data_xyz[:,0])
        lindex = np.where(diff <  tol / 365.25 )
        if lindex[0].shape[0] > 0:
            if verbose:
                print('-- there are duplicated dates for ',self.code)
            # some dates are duplicated
            if action == 'check':
                print('! There are duplicated dates for .data_xyz at:')
                for index in lindex:
                    print('-- ',self.data_xyz[index,0],' --- ',self.data_xyz[index+1,0])
                
            if action == 'correct':
                # keep the second date
                new_data_xyz=np.delete(self.data_xyz, lindex, axis=0)
        else:
            new_data_xyz=np.copy(self.data_xyz)
            if verbose:
                print('-- no duplicated dates in .data_xyz for ',self.code)

    
    # deal with outliers. assume that they are defined for .data

    if ( lindex[0].shape[0] > 0 ) and ( action == 'correct' ):
        
        if verbose:
            print('-- updating outliers list for ',self.code)
        
        ldate_outliers=self.data[:,0][self.outliers]
        ldate_removed=self.data[:,0][lindex]
    
        ldate_tmp=list( set(ldate_outliers).intersection(set(ldate_removed)) )
        
        if verbose:
            print('-- removing ',len(ldate_tmp),' outliers from Gts.outliers')
        
        lupdated_outliers=pyacs.gts.Gts.get_index_from_dates(ldate_tmp, new_data, tol=0.1)
    
    else:
        lupdated_outliers=self.outliers
        
    # in_place ?
    
    if in_place:
        if self.data is not None:
            self.data=new_data
            # update outliers
            self.outliers=lupdated_outliers
            
        if self.data_xyz is not None:self.data_xyz=new_data_xyz
        return(self)

    else:
        if new_gts.data is not None:new_gts.data=new_data
        if new_gts.data_xyz is not None:new_gts.data_xyz=new_data_xyz
        new_gts.outliers=lupdated_outliers
        return(new_gts)



###################################################################
def add_obs(self,date,NEUSNSESUCNECNUCEU,in_place=False,check=True,verbose=False):
###################################################################
    """
    Adds observation(s) as DN,DN,DU to a time series
    
    :param date: date in decimal year. float, a list or 1D numpy array
    :param NEUSNSESUCNECNUCEU: value to be added in the Gts, provided as a list, a 1D numpy array or a 2D numpy array.
                               requires at least NEU: North, East, UP values
                               optional: SN, SE, SU, CNE, CNU, CEU: standard deviations and correlation coefficient between North, East and Up components.
                               If not provided, SN=SE=SU=0.001 (1 mm) and CNE=CNU=CEU=0
    :param in_place: boolean, if True add_obs to the current Gts, if False, returns a new Gts
    :param check: check time order and duplicate dates
    :param verbose: verbose mode 
    
    
    :return : new Gts or the modified Gts if in_place
    """
    
    # import 
    import numpy as np

    # check argument
    
    if isinstance(date,list) :
        if  (len(list)>1) :
            date=np.array(date)
        else:
            date=date[0]
            
        
    if isinstance(date,np.ndarray):
        
        if not ( isinstance(NEUSNSESUCNECNUCEU,np.ndarray) and (np.ndim(NEUSNSESUCNECNUCEU) != 2 ) ):
            raise TypeError('!!! ERROR: various dates require the second argument to be a 2D numpy array')
            return(self)
    
    if isinstance(NEUSNSESUCNECNUCEU,list):
        NEUSNSESUCNECNUCEU=np.array(NEUSNSESUCNECNUCEU)
    
    if np.ndim(NEUSNSESUCNECNUCEU) == 1:
        if NEUSNSESUCNECNUCEU.shape[0] not in [3,6,9]:
                raise TypeError('!!! ERROR: second argument must be of length 3, 6 or 9')
    
    if np.ndim(NEUSNSESUCNECNUCEU) == 2:
        if NEUSNSESUCNECNUCEU.shape[1] not in [3,6,9]:
                raise TypeError('!!! ERROR: second argument must be a 2D array with 3, 6 or 9 columns')
    
    # creates array to be stacked to current .data array
    
    if isinstance(date,float):
        # single obs provided
        
        new_data=np.zeros((1,10))
        new_data[0,4] = .001
        new_data[0,5] = .001
        new_data[0,6] = .001
        
        new_data[0,0] = date


        new_data[0,1] = NEUSNSESUCNECNUCEU[0] 
        new_data[0,2] = NEUSNSESUCNECNUCEU[1] 
        new_data[0,3] = NEUSNSESUCNECNUCEU[2]
        
        if NEUSNSESUCNECNUCEU.shape[0] > 3:

            new_data[0,4] = NEUSNSESUCNECNUCEU[3] 
            new_data[0,5] = NEUSNSESUCNECNUCEU[4] 
            new_data[0,6] = NEUSNSESUCNECNUCEU[5]
             
        if NEUSNSESUCNECNUCEU.shape[0] > 6:

            new_data[0,7] = NEUSNSESUCNECNUCEU[6] 
            new_data[0,8] = NEUSNSESUCNECNUCEU[7] 
            new_data[0,9] = NEUSNSESUCNECNUCEU[8]
         
    if isinstance(date,np.ndarray):
        # various obs provided
        
        new_data=np.zeros((date.shape[0],10))
        new_data[:,4] = new_data[:,4] + .001
        new_data[:,5] = new_data[:,5] + .001
        new_data[:,6] = new_data[:,6] + .001

        if NEUSNSESUCNECNUCEU.shape[1] > 3:

            new_data[:,4] = NEUSNSESUCNECNUCEU[:,3] 
            new_data[:,5] = NEUSNSESUCNECNUCEU[:,4] 
            new_data[:,6] = NEUSNSESUCNECNUCEU[:,5]
             
        if NEUSNSESUCNECNUCEU.shape[1] > 6:

            new_data[:,7] = NEUSNSESUCNECNUCEU[:,6] 
            new_data[:,8] = NEUSNSESUCNECNUCEU[:,7] 
            new_data[:,9] = NEUSNSESUCNECNUCEU[:,8]

    # update .data
    
    if in_place:
        new_gts = self
    else:
        new_gts = self.copy()
    

    if verbose:
        print('-- updating Gts for code ',new_gts.code,' with ',new_data.shape[0], ' new entries.')

    if new_gts.data is None:
        new_gts.data = new_data
    else:
        if new_gts.data.shape[1] == 7:
            new_gts.data = np.vstack ( ( new_gts.data , new_data[:,:7] ) )
        else:
            new_gts.data = np.vstack ( ( new_gts.data , new_data ) )
        
    # check order and duplicate
    if check:
        # reorder
        new_gts.reorder(verbose=verbose)
    
        # check for duplicates
        new_gts.correct_duplicated_dates(action='correct',tol= .00000001, in_place=True,verbose=verbose)
    
    return(new_gts)

###################################################################
def add_obs_xyz(self,date,XYZSXSYSZCXYCXZCYZ,in_place=False,check=True,verbose=False):
###################################################################
    """
    Adds observation(s) as XYZ to a time series
    
    :param date: date in decimal year. float, a list or 1D numpy array
    :param XYZSXSYSZCXYCXZCYZ: value to be added in the Gts, provided as a list, a 1D numpy array or a 2D numpy array.\
    requires at least X,Y,Z
    optional: SX, SY, SZ, CXY, CXZ, CYZ: standard deviations and correlation coefficients.\
    If not provided, SX=SY=SZ=0.001 (1 mm) and CXY=CXZ=CYZ=0
    :param in_place: boolean, if True add_obs to the current Gts, if False, returns a new Gts
    :param check: check time order , duplicate dates and re-generate NEU time series (.data)
    :param verbose: verbose mode 
  
    :return : new Gts or the modified Gts if in_place
    """
    
    # import 
    import numpy as np

    # check argument
    
    if isinstance(date,list) :
        if  (len(list)>1) :
            date=np.array(date)
        else:
            date=date[0]
            
        
    if isinstance(date,np.ndarray):
        
        if not ( isinstance(XYZSXSYSZCXYCXZCYZ,np.ndarray) and (np.ndim(XYZSXSYSZCXYCXZCYZ) != 2 ) ):
            raise TypeError('!!! ERROR: various dates require the second argument to be a 2D numpy array')
            return(self)
    
    if isinstance(XYZSXSYSZCXYCXZCYZ,list):
        XYZSXSYSZCXYCXZCYZ=np.array(XYZSXSYSZCXYCXZCYZ)
    
    if np.ndim(XYZSXSYSZCXYCXZCYZ) == 1:
        if XYZSXSYSZCXYCXZCYZ.shape[0] not in [3,6,9]:
                raise TypeError('!!! ERROR: second argument must be of length 3, 6 or 9')
    
    if np.ndim(XYZSXSYSZCXYCXZCYZ) == 2:
        if XYZSXSYSZCXYCXZCYZ.shape[1] not in [3,6,9]:
                raise TypeError('!!! ERROR: second argument must be a 2D array with 3, 6 or 9 columns')
    
    # creates array to be stacked to current .data array
    
    if isinstance(date,float):
        # single obs provided
        
        new_data=np.zeros((1,10))
        new_data[0,4] = .001
        new_data[0,5] = .001
        new_data[0,6] = .001
        
        new_data[0,0] = date


        new_data[0,1] = XYZSXSYSZCXYCXZCYZ[0] 
        new_data[0,2] = XYZSXSYSZCXYCXZCYZ[1] 
        new_data[0,3] = XYZSXSYSZCXYCXZCYZ[2]
        
        if XYZSXSYSZCXYCXZCYZ.shape[0] > 3:

            new_data[0,4] = XYZSXSYSZCXYCXZCYZ[3] 
            new_data[0,5] = XYZSXSYSZCXYCXZCYZ[4] 
            new_data[0,6] = XYZSXSYSZCXYCXZCYZ[5]
             
        if XYZSXSYSZCXYCXZCYZ.shape[0] > 6:

            new_data[0,7] = XYZSXSYSZCXYCXZCYZ[6] 
            new_data[0,8] = XYZSXSYSZCXYCXZCYZ[7] 
            new_data[0,9] = XYZSXSYSZCXYCXZCYZ[8]
         
    if isinstance(date,np.ndarray):
        # various obs provided
        
        new_data=np.zeros((date.shape[0],10))
        new_data[:,4] = new_data[:,4] + .001
        new_data[:,5] = new_data[:,5] + .001
        new_data[:,6] = new_data[:,6] + .001

        if XYZSXSYSZCXYCXZCYZ.shape[1] > 3:

            new_data[:,4] = XYZSXSYSZCXYCXZCYZ[:,3] 
            new_data[:,5] = XYZSXSYSZCXYCXZCYZ[:,4] 
            new_data[:,6] = XYZSXSYSZCXYCXZCYZ[:,5]
             
        if XYZSXSYSZCXYCXZCYZ.shape[1] > 6:

            new_data[:,7] = XYZSXSYSZCXYCXZCYZ[:,6] 
            new_data[:,8] = XYZSXSYSZCXYCXZCYZ[:,7] 
            new_data[:,9] = XYZSXSYSZCXYCXZCYZ[:,8]

    # update .data_xyz
    
    if in_place:
        new_gts = self
    else:
        new_gts = self.copy()
    
    if verbose:
        print('-- updating Gts for code ',new_gts.code,' with ',new_data.shape[0], ' new entries.')

    if new_gts.data_xyz is None:
        new_gts.data_xyz = new_data
    else:
        if new_gts.data_xyz.shape[1] == 7:
            new_gts.data_xyz = np.vstack ( ( new_gts.data_xyz , new_data[:,:7] ) )
        else:
            new_gts.data_xyz = np.vstack ( ( new_gts.data_xyz , new_data ) )
        
    if check:
        # reorder
        new_gts.reorder(verbose=False)
        # check for duplicates
        new_gts.correct_duplicated_dates(action='correct',tol= .00000001, in_place=True,verbose=verbose)
        # re-generate .data
        new_gts.xyz2neu(corr=True)
    
    return(new_gts)

###################################################################
def xyz2neu(self,corr=False,ref_xyz=None, verbose=False):
###################################################################
    """
    populates neu (data) using xyz (data_xyz)
    lon, lat and h will also be set.
    
    :param corr: if True, then standard deviation and correlations will also be calculated  
    :param ref_xyz: [X,Y,Z] corresponding to the 0 of the local NEU frame. If not provided, the first position is used as a reference
    :param verbose: verbose mode
    
    """

    import pyacs.lib.coordinates
    import numpy as np

    # Reference point for the local NEU frame
    
    if ref_xyz is not None:
        [xref,yref,zref] = ref_xyz
    else:
        
        [xref,yref,zref]=self.data_xyz[0,1:4]
        self.X0=xref
        self.Y0=yref
        self.Z0=zref

    (lam,phi,h) = pyacs.lib.coordinates.xyz2geo(xref,yref,zref)
    R = pyacs.lib.coordinates.mat_rot_general_to_local(lam,phi)

    X0=np.array([xref,yref,zref])
    
    DX=self.data_xyz[:,1:4]-X0
    
    ENU=np.dot(R,DX.T).T
    
    self.data=np.copy(self.data_xyz)
    
    self.data[:,1]=ENU[:,1]
    self.data[:,2]=ENU[:,0]
    self.data[:,3]=ENU[:,2]
    
    self.lon=np.degrees(lam)
    self.lat=np.degrees(phi)
    self.h=h
    
    if corr:
        import pyacs.lib.glinalg
        for i in np.arange(self.data.shape[0]):
            [ _X,_Y,_Z,Sx,Sy,Sz,Rxy,Rxz,Ryz ]=self.data_xyz[i,1:10].tolist()
            CORR_XYZ=np.array([\
                              [1,Rxy,Rxz],\
                              [Rxy,1,Ryz],\
                              [Rxz,Ryz,1]\
                              ])
            STD_XYZ=np.array([Sx,Sy,Sz])
            VCV_XYZ=pyacs.lib.glinalg.corr_to_cov(CORR_XYZ, STD_XYZ)
    
            VCV_ENU=np.dot(np.dot(R,VCV_XYZ),R.T)
            CORR_ENU,STD_ENU=pyacs.lib.glinalg.cov_to_corr(VCV_ENU)
            
            
            self.data[i,4]=STD_ENU[1]
            self.data[i,5]=STD_ENU[0]
            self.data[i,6]=STD_ENU[2]

            self.data[i,7]=CORR_ENU[0,1]
            self.data[i,8]=CORR_ENU[1,2]
            self.data[i,9]=CORR_ENU[0,2]
    
    # reorder and check duplicate dates

    self.reorder(verbose=False)
    # check for duplicates
    #self.correct_duplicated_dates(action='correct',tol= .00000001, in_place=True,verbose=verbose)
 
    return(self)

###################################################################
def neu2xyz(self,corr=False,verbose=False):
###################################################################
    """
    populates .data_xyz from .data
    requires X0,Y0,Z0 attributes to be set
    
    :param corr: if True, then standard deviation and correlations will also be calculated  
    :param verbose: verbose mode
    
    """

    # check X0,Y0,Z0
    if self.X0 is None:
        print("!!! ERROR: X0,Y0,Z0 attributes required for neu2xyz method.")
        self.data_xyz = None
        return(self)
    
    # import

    import pyacs.lib.coordinates
    import numpy as np

    # reference pos
    
    xref = self.X0
    yref = self.Y0
    zref = self.Z0
    #X0=np.array([xref,yref,zref])

    # local frame to geocentric frame rotation matrix - assumes ENU convention
     
    (lam,phi,_h) = pyacs.lib.coordinates.xyz2geo(xref,yref,zref)
    R = pyacs.lib.coordinates.mat_rot_local_to_general(lam, phi)

    DNEU =  np.copy(self.data[:,1:4])
    # swap for ENU convention - pyacs.gts is NEU
    DENU =  DNEU
    DENU[:,[0, 1]] = DENU[:,[1, 0]]
    
    # DXYZ
    
    DXYZ = np.dot(R,DENU.T).T
    
    self.data_xyz = np.zeros( ( self.data.shape[0] , 10 ) )
    self.data_xyz[:,0] = self.data[:,0].copy()
    
    self.data_xyz[:,1]=DXYZ[:,0] + self.X0
    self.data_xyz[:,2]=DXYZ[:,1] + self.Y0
    self.data_xyz[:,3]=DXYZ[:,2] + self.Z0
    
    
    if corr:
        import pyacs.lib.glinalg
        for i in np.arange(self.data.shape[0]):
            [  _dN , _dE , _dU , Sn , Se , Su , Rne , Rnu , Reu ]=self.data[i,1:10].tolist()
            CORR_ENU=np.array([\
                              [1,Rne,Reu],\
                              [Rne,1,Rnu],\
                              [Reu,Rnu,1]\
                              ])
            STD_ENU=np.array([Se,Sn,Su])
            VCV_ENU=pyacs.lib.glinalg.corr_to_cov(CORR_ENU, STD_ENU)
    
            VCV_XYZ=np.dot(np.dot(R,VCV_ENU),R.T)
            CORR_XYZ,STD_XYZ=pyacs.lib.glinalg.cov_to_corr(VCV_XYZ)
            
            self.data_xyz[i,4]=STD_XYZ[0]
            self.data_xyz[i,5]=STD_XYZ[1]
            self.data_xyz[i,6]=STD_XYZ[2]

            self.data_xyz[i,7]=CORR_XYZ[0,1]
            self.data_xyz[i,8]=CORR_XYZ[0,2]
            self.data_xyz[i,9]=CORR_XYZ[1,2]
    
    # reorder and check duplicate dates

    self.reorder(verbose=False)
    # check for duplicates
    self.correct_duplicated_dates(action='correct',tol= .00000001, in_place=True,verbose=verbose)
 
    return(self)


###################################################################
def copy(self,data=False, copy_outliers=True):
###################################################################
    """
    makes a (deep) copy of the time series
    if data is provided, fills data with the provided array.
    """

    # import 
    import numpy as np
    import copy
    import pyacs.gts
    
    # deep copy
    new_Gts=copy.deepcopy(self)
    
    if isinstance(data,np.ndarray):
        new_Gts.data=np.copy(data)
    
    # handles outliers

    if isinstance(new_Gts.data,np.ndarray):

        ldate_outliers = self.data[:,0][self.outliers]
        lupdated_outliers = pyacs.gts.Gts.get_index_from_dates(ldate_outliers, new_Gts.data, tol=0.01)

        new_Gts.outliers = lupdated_outliers 

    else:
        new_Gts.outliers = []

    return(new_Gts)

###################################################################
def differentiate(self):
###################################################################
    """
    differentiate the current time series
    
    :return: the differentiated time series as a new Gts object
    """
    # import 
    import numpy as np
    import pyacs.lib.astrotime

    # check data is not None
    from pyacs.gts.lib.errors import GtsInputDataNone
    
    try:
        if self.data is None:
            # raise exception
            raise GtsInputDataNone(inspect.stack()[0][3],__name__,self)
    except GtsInputDataNone as error:
        # print PYACS WARNING
        print( error )
        return( self )

    new_Gts=self.copy()
    data=self.data
    data_diff=np.diff(data,axis=0)
    
    # for dates
    data_mjd = pyacs.lib.astrotime.decyear2mjd( data[:,0] )
    new_data_mjd = ( data_mjd[0:-1] + data_mjd[1:] ) / 2. 
    
#    data_diff[:,0]=data[0:len(data[:,0])-1,0]+data_diff[:,0]

    data_diff[:,0] = pyacs.lib.astrotime.mjd2decyear( new_data_mjd )

    new_Gts.data=data_diff.copy()
    return(new_Gts)

    
###################################################################
def extract_periods(self,lperiod,in_place=False,verbose=False):
###################################################################
    """
    extract periods of a Gts
    
    :param lperiod: a list [start_date,end_date] or a list of periods e.g. periods=[[2000.1,2003.5],[2009.3,2010.8]]
    :param in_place: if True, will make change in place, if False, return s a new time series
    
    """

    # import 
    import numpy as np
    import pyacs.gts.Gts

    # check data is not None
    from pyacs.gts.lib.errors import GtsInputDataNone
    
    try:
        if self.data is None:
            # raise exception
            raise GtsInputDataNone(inspect.stack()[0][3],__name__,self)
    except GtsInputDataNone as error:
        # print PYACS WARNING
        print( error )
        return( self )


    # ensure lperiod is a list of lists
    lperiod=__ensure_list_of_list(lperiod)
  
    
    # check lperiod is not [[]]
    if lperiod==[[]]:
        if in_place:
            return(self)
        else:
            return(self.copy())
    
    # initialize
    
    lperiod.sort()
    #offsets=[]
    new_data=None

    # loop on periods

    for period in lperiod:
        
        # make actual extraction - case data_xyz now handled
        start_date_period=period[0]
        end_date_period  =period[1]

        sel_data=np.copy(self.data[np.where((self.data[:,0]>=start_date_period) & (self.data[:,0] <=end_date_period ))])
        
        if self.data_xyz is not None:
            sel_data_xyz=np.copy(self.data_xyz[np.where((self.data_xyz[:,0]>=start_date_period) & (self.data_xyz[:,0] <=end_date_period ))])

        if not isinstance(new_data, np.ndarray):
            new_data=sel_data
            if self.data_xyz is not None:
                new_data_xyz=sel_data_xyz
            
        else:
            new_data=np.vstack((new_data,sel_data))
            if self.data_xyz is not None:
                new_data_xyz=np.vstack((new_data_xyz,sel_data_xyz))
    
    if new_data.shape[0] == 0:
        if verbose: 
            print("!!! ",self.code," has no data for the selected list of periods ",lperiod)
        if in_place:
            self.data = None
            self.data_xyz = None
            return(self)
        else:
            new_gts = self.copy()
            new_gts.data = None
            new_gts.data_xyz = None
            return(new_gts)

    
    # handle outliers

    ldate_outliers=self.data[:,0][self.outliers]
    lupdated_outliers=pyacs.gts.Gts.get_index_from_dates(ldate_outliers, new_data, tol=0.05)
    
    # handles offsets_date
    
    upd_offsets=[]
    for offset_date in self.offsets_dates:
        if offset_date>=new_data[0,0] and offset_date<=new_data[-1,0]:
            upd_offsets.append(offset_date)
                
    # return
    new_Gts=self.copy(data=new_data)
    if self.data_xyz is not None:
        new_Gts.data_xyz = new_data_xyz
        new_Gts.xyz2neu(corr=True)

        
    new_Gts.offsets_dates=upd_offsets
    new_Gts.outliers=lupdated_outliers
    
    if in_place:
        self = new_Gts
        return(self)
    else:
        return(new_Gts)

###################################################################
def exclude_periods(self,lperiod,in_place=False,verbose=False):
###################################################################
    """
    exclude periods
    
    :param lperiod: a list [start_date,end_date] or a list of periods e.g. periods=[[2000.1,2003.5],[2009.3,2010.8]]
    :param in_place: if True, will make change in place, if False, returns a new time series
    :param verbose: boolean, verbose mode
    """

    # import 
    import numpy as np
    import pyacs.gts.Gts

    # check data is not None
    from pyacs.gts.lib.errors import GtsInputDataNone
    
    try:
        if self.data is None:
            # raise exception
            raise GtsInputDataNone(inspect.stack()[0][3],__name__,self)
    except GtsInputDataNone as error:
        # print PYACS WARNING
        print( error )
        return( self )

    # check lperiod is not [[]]
    lperiod=__ensure_list_of_list(lperiod)
  
    # ensure lperiod is a list of lists
    
    if lperiod==[[]]:
        if in_place:
            return(self)
        else:
            return(self.copy())
    
    # initialize
    lperiod.sort()
    #new_data = None

    lindex=np.array([],dtype=int)

    # tmp Gts
    tmp_gts = self.copy()

    # loop on lperiod
    for period in lperiod:

        if len( lperiod ) == 1:        
            wlindex=np.argwhere( (self.data[:,0] <= period[0]) | (self.data[:,0] >= period[1]) )
            lindex=np.append(lindex, wlindex)

            new_data=self.data[lindex]
            if self.data_xyz is not None:
                new_data_xyz=self.data_xyz[lindex]


        else:
            tmp_gts = tmp_gts.exclude_periods(period)
            new_data=tmp_gts.data
            if self.data_xyz is not None:
                new_data_xyz=tmp_gts.data_xyz

    
    # handle case where all dates have been excluded
    if new_data.shape[0] == 0:
        if verbose: 
            print("!!! ",self.code," has no data for the selected list of periods ",lperiod)
        if in_place:
            self.data = None
            self.data_xyz = None
            return(self)
        else:
            new_gts = self.copy()
            new_gts.data = None
            new_gts.data_xyz = None
            return(new_gts)


    # handle outliers

    ldate_outliers=self.data[:,0][self.outliers]
    lupdated_outliers=pyacs.gts.Gts.get_index_from_dates(ldate_outliers, new_data, tol=0.05)
    
    # handles offsets_date
    
    upd_offsets=[]
    for offset_date in self.offsets_dates:
        if offset_date>=new_data[0,0] and offset_date<=new_data[-1,0]:
            upd_offsets.append(offset_date)
                
    # return
        
    new_Gts=self.copy(data=new_data)
    if self.data_xyz is not None:
        new_Gts.data_xyz = new_data_xyz
    new_Gts.offsets_dates=upd_offsets
    new_Gts.outliers=lupdated_outliers
    
    if in_place:
        self = new_Gts
        return(self)
    else:
        return(new_Gts)

###################################################################
def extract_dates(self,dates, tol= 0.05 , in_place=False, verbose=True):
###################################################################
    """
    Returns a time series extracted for a given list of dates
    
    :param dates: dates either as a list or  1D numpy array of decimal dates
    :param tol: date tolerance in days to assert that two dates are equal (default 0.05 day)
    :param in_place: if True, will make change in place, if False, return s a new time series
    :param verbose: boolean, verbose mode

    """

    # import 
    import numpy as np
    import pyacs.gts

    # check data is not None
    from pyacs.gts.lib.errors import GtsInputDataNone
    
    try:
        if self.data is None:
            # raise exception
            raise GtsInputDataNone(inspect.stack()[0][3],__name__,self)
    except GtsInputDataNone as error:
        # print PYACS WARNING
        print( error )
        return( self )
  
    new_data=None
    
    # extract dates
        
    index = np.array( pyacs.gts.Gts.get_index_from_dates(dates, self.data, tol=tol) )
    
    if verbose:
        print('-- Extracting ',index.shape[0],' entries from Gts or code: ',self.code)
    
    if index.shape[0] > 0:
            new_data=self.data[index,:]
    else:
        new_data=None
        if verbose:
            print("-- time series ",self.code," does not have dates at the asked dates ")

  
    # handles outliers

    if new_data is not None:    
        ldate_outliers=self.data[:,0][self.outliers]
        lupdated_outliers=pyacs.gts.Gts.get_index_from_dates(ldate_outliers, new_data, tol=tol)
    else:
        lupdated_outliers = []

    if verbose:
        print('-- Transmitting ',len(lupdated_outliers),' outliers to the extracted Gts ')
    
    # return
    
    new_Gts=self.copy(data=new_data)
    new_Gts.offsets_dates=self.offsets_dates
    new_Gts.outliers=lupdated_outliers
    
    if in_place:
        self = new_Gts
        return(self)
    else:
        return(new_Gts)


###################################################################
def extract_ndates_before_date(self,date,n,verbose=False):
###################################################################
    """
    Extract n values before a given date
    If n values are not available, returns all available values before date
    .data is set to None if no value at all is available
    
    :param date: date in decimal year
    :param n: number of observations to be extracted
    
    :return: a new Gts
    
    """

    # import 
    import numpy as np

    # check data is not None
    from pyacs.gts.lib.errors import GtsInputDataNone
    
    try:
        if self.data is None:
            # raise exception
            raise GtsInputDataNone(inspect.stack()[0][3],__name__,self)
    except GtsInputDataNone as error:
        # print PYACS WARNING
        print( error )
        return( self )

    # copy
    new_Gts=self.copy()
    new_Gts.data=None
    
    # extract data
    sel_data     = np.copy(self.data[ np.where( self.data[:,0] < date ) ] )
    if self.data_xyz is not None:
        sel_data_xyz = np.copy(self.data_xyz[ np.where( self.data[:,0] < date ) ] )
        
    # extract data
    if sel_data.shape[0]>n:
        sel_data=sel_data[-n:,:]
        if self.data_xyz is not None:
            sel_data_xyz=sel_data_xyz[-n:,:]
    elif sel_data.shape[0]>0:
        sel_data=sel_data[:,:]
        if self.data_xyz is not None:
            sel_data_xyz=sel_data_xyz[:,:]
    else:
        sel_data = None
        if verbose:
            print("-- time series ",self.code," does not have data before ",date)

    new_Gts.data=sel_data
    if self.data_xyz is not None:
        new_Gts.data_xyz = sel_data_xyz
        
    return(new_Gts)    
    
###################################################################
def extract_ndates_after_date(self,date,n,verbose=False):
###################################################################
    """
    Extract n values after a given date
    If n values are not available, returns all available values after date
    .data is set to None if no value at all is available

    :param date: date in decimal year
    :param n: number of observations to be extracted
    
    :return: a new Gts

    """

    # import 
    import numpy as np

    # check data is not None
    from pyacs.gts.lib.errors import GtsInputDataNone
    
    try:
        if self.data is None:
            # raise exception
            raise GtsInputDataNone(inspect.stack()[0][3],__name__,self)
    except GtsInputDataNone as error:
        # print PYACS WARNING
        print( error )
        return( self )

    # copy
    new_Gts=self.copy()
    new_Gts.data=None
    
    try:
        sel_data=np.copy(self.data[np.where((self.data[:,0]>date))])
    except:
        print("-- time series ",self.code," does not have data after ",date)
        return(new_Gts)
    
    # extract data
    if sel_data.shape[0]>n:
        sel_data=sel_data[:n,:]
    elif sel_data.shape[0]>0:
        sel_data=sel_data[:,:]
    else:
        sel_data = None
        if verbose:
            print("-- time series ",self.code," does not have data after ",date)
    
    new_Gts.data=sel_data
    
    return(new_Gts)    

###################################################################
def extract_ndates_around_date(self,date,n):
###################################################################
    """
    Extract n values before and n values after a given date
    If n values are not available, returns all available values
    .data is set to None if no value at all is available

    :param date: date in decimal year
    :param n: number of observations to be extracted
    
    :return: a new Gts

    """

    # import 
    import numpy as np

    # check data is not None
    from pyacs.gts.lib.errors import GtsInputDataNone
    
    try:
        if self.data is None:
            # raise exception
            raise GtsInputDataNone(inspect.stack()[0][3],__name__,self)
    except GtsInputDataNone as error:
        # print PYACS WARNING
        print( error )
        return( self )

    # copy
    new_Gts=self.copy()
    new_Gts.data=None
    
    try:
        sel_data_after=np.copy(self.data[np.where((self.data[:,0]>date))])
    except:
        print("-- time series ",self.code," does not have data after ",date)
        return(new_Gts)
    
    
    try:
        sel_data_before=np.copy(self.data[np.where((self.data[:,0]<date))])
    except:
        print("-- time series ",self.code," does not have data before ",date)
        return(new_Gts)
    
    # extract data
    if sel_data_after.shape[0]>n:
        sel_data_after=sel_data_after[:n,:]
    
    if sel_data_before.shape[0]>n:
        sel_data_before=sel_data_before[-n:,:]

    
    sel_data=np.vstack(( sel_data_before, sel_data_after))
        
    new_Gts.data=sel_data
    
    return(new_Gts)    
    

###################################################################
def substract_ts(self,ts,tol=0.05,verbose=True):
###################################################################
    """
    substract the ts provided as argument to the current time series
    
    :param ts: time series to be substracted as a Gts instance
    :param tol: date tolerance to decide whether two dates are identical in both time series. default = 1/4 day
    :param verbose: verbose mode
    :return : new Gts
    
    """

    # import 
    import numpy as np
    import pyacs.gts.Gts

    # check data is not None
    from pyacs.gts.lib.errors import GtsInputDataNone
    
    try:
        if self.data is None:
            # raise exception
            raise GtsInputDataNone(inspect.stack()[0][3],__name__,self)
    except GtsInputDataNone as error:
        # print PYACS WARNING
        print( error )
        return( self )

    # check data is not None
    
    try:
        if ts.data is None:
            # raise exception
            raise GtsInputDataNone(inspect.stack()[0][3],__name__,ts)
    except GtsInputDataNone as error:
        # print PYACS WARNING
        print( error )
        return( self )

    tol = tol /365.25 # tolerance in decimal year

    # find common dates
    
    #common_dates=np.intersect1d(np.round(self.data[:,0],decimals=7),np.round(ts.data[:,0],decimals=7))

    lindex=pyacs.gts.Gts.get_index_from_dates(self.data[:,0], ts.data, tol)

    if verbose:
        print('-- ',len(lindex),' common dates found.')
         
    common_dates = self.data[lindex,0]

    # test whether there are common dates
    
    if common_dates.shape[0] == 0:
        print('! WARNING No common dates between ',self.code,' from ',self.ifile)
        print('!!! and ',ts.code, ' from ',ts.ifile)
        
        new_data = None

    else:
        # extract
        extracted_target=self.extract_dates(common_dates,tol=tol)
        extracted_ref=ts.extract_dates(common_dates,tol=tol)
    
        new_data=extracted_target.data - extracted_ref.data
        
        new_data[:,0]=common_dates 
        
        new_data[:,4]=np.sqrt(extracted_target.data[:,4]**2+extracted_ref.data[:,4]**2) 
        new_data[:,5]=np.sqrt(extracted_target.data[:,5]**2+extracted_ref.data[:,5]**2) 
        new_data[:,6]=np.sqrt(extracted_target.data[:,6]**2+extracted_ref.data[:,6]**2) 
                
    new_code=self.code+'_'+ts.code

    new_Gts=self.copy(data=new_data)
    new_Gts.code=new_code

    return(new_Gts)

###################################################################
def add_offsets_dates(self,offsets_dates,in_place=False):
###################################################################
    """
    add_offsets_dates to a time series
    if in_place = True then replace the current time series
    """
    
    new_ts=self.copy(data=self.data)
    new_ts.offsets_dates=offsets_dates

    if in_place:
        self.data=new_ts.data.copy()
    return(new_ts)

###################################################################
def remove_velocity(self,vel_neu,in_place=False):
###################################################################
    """
    remove velocity from a time series
    vel_neu is a 1D array of any arbitrary length, but with the velocities (NEU) to be removed in the first 3 columns
    if in_place = True then replace the current time series
    """

    # import 
    import numpy as np

    # check data is not None
    from pyacs.gts.lib.errors import GtsInputDataNone
    
    try:
        if self.data is None:
            # raise exception
            raise GtsInputDataNone(inspect.stack()[0][3],__name__,self)
    except GtsInputDataNone as error:
        # print PYACS WARNING
        print( error )
        return( self )

    if self.t0 != None:
        ref_date=self.t0
    else:    
        ref_date=np.mean(self.data[0,0])
    
    v_neu=vel_neu[0:3]
    
    
    new_data=self.data.copy()
     
    new_data[:,1:4]=new_data[:,1:4]-np.dot( (new_data[:,0]-ref_date).reshape(-1,1) , v_neu.reshape(1,3) )

    new_Gts=self.copy(data=new_data)
    
    # inform the velocity used
    #vel = np.zeros((6))
    vel = vel_neu
    
    new_Gts.velocity = vel
    
    if in_place:
        self.data=new_Gts.data.copy()
        return( self )
    else:
        return(new_Gts)

###################################################################
def rotate(self,angle,in_place=False):
###################################################################
    """
    rotates the axis by an angle

    :param angle: angle in decimal degrees clockwise
    
    if in_place = True then replace the current time series
    """

    # import 
    import numpy as np

    # check data is not None
    from pyacs.gts.lib.errors import GtsInputDataNone
    
    try:
        if self.data is None:
            # raise exception
            raise GtsInputDataNone(inspect.stack()[0][3],__name__,self)
    except GtsInputDataNone as error:
        # print PYACS WARNING
        print( error )
        return( self )

    # computes the rotates components
    angle_radian = np.radians( -angle )
    
    new_data=self.data.copy()
    
    new_x = new_data[:,2] * np.cos( angle_radian ) - new_data[:,1] * np.sin( angle_radian ) 
    new_y = new_data[:,2] * np.sin( angle_radian ) + new_data[:,1] * np.cos( angle_radian ) 
     
    new_data[:,1] = new_y
    new_data[:,2] = new_x

    new_data[:,4] = new_data[:,5] = 1.E-3
    new_data[:,7:] = 0.0

    new_Gts=self.copy(data=new_data)
    
    
    if in_place:
        self.data=new_Gts.data.copy()
        return( self )
    else:
        return(new_Gts)


###################################################################
def set_zero_at_date(self,date,offset=None,in_place=False):
###################################################################
    """
    make a translation of a time series, setting to 0 at a given date
    if the provided date does not exist, uses the next date available
    
    :param date: date in decimal year
    :param offset: an offset (in mm) to be added. Could be a float, a list or 1D numpy array with 3 elements 
    
    """

    # import 
    import numpy as np

    # check data is not None
    from pyacs.gts.lib.errors import GtsInputDataNone
    
    try:
        if self.data is None:
            # raise exception
            raise GtsInputDataNone(inspect.stack()[0][3],__name__,self)
    except GtsInputDataNone as error:
        # print PYACS WARNING
        print( error )
        return( self )

    if offset is None:
        [cn,ce,cu] =[0.0,0.0,0.0]
    else:
        if isinstance(offset,float):
            [cn,ce,cu] =[offset/1000.,offset/1000.,offset/1000.]
        elif isinstance(offset,list):
            [cn,ce,cu] =[offset[0]/1000.,offset[1]/1000.,offset[2]/1000.]
        elif isinstance(offset,np.ndarray):
            [cn,ce,cu] =[offset[0]/1000.,offset[1]/1000.,offset[2]/1000.]
    
    
    
    
    new_data=self.data.copy()

    lindex=np.where(new_data[:,0] >= date)

    try:
        index=lindex[0][0]
    except:
        print("!!! bad date provided")
        return()
    
    print("-- Removing ",new_data[index,1],new_data[index,2],new_data[index,3])
     
    new_data[:,1]=new_data[:,1]-new_data[index,1] + cn
    new_data[:,2]=new_data[:,2]-new_data[index,2] + ce
    new_data[:,3]=new_data[:,3]-new_data[index,3] + cu

    new_Gts=self.copy(data=new_data)
    
    # origin XYZ would need to be changed
    
    if in_place:
        self.data=new_Gts.data.copy()
    return(new_Gts)

###################################################################
def displacement(self,sdate=None,edate=None,window=None,method='median',speriod=[],eperiod=[],verbose=True):
###################################################################
    """
    Calculates displacements between two dates or two periods
    """
    
    # import 
    import numpy as np

    # check data is not None
    from pyacs.gts.lib.errors import GtsInputDataNone
    
    try:
        if self.data is None:
            # raise exception
            raise GtsInputDataNone(inspect.stack()[0][3],__name__,self)
    except GtsInputDataNone as error:
        # print PYACS WARNING
        print( error )
        return( )


    if speriod != []:
        gts_sdate=self.extract_periods([speriod])
        if gts_sdate.data is None:
            print("!!! No data available in initial period ",speriod," for site ",self.code)
            return(None)
    else:
        gts_sdate=self.extract_periods([[sdate-window/365.25,sdate+window/365.25]])
        if gts_sdate.data is None:
            print("!!! No data available at initial date ",sdate," window=",window," days, for site ",self.code)
            return(None)

    if verbose:
        s_delta_days=(gts_sdate.data[-1,0]-gts_sdate.data[0,0])*365.25
        print("-- Initial position calculated using ",gts_sdate.data.shape[0]," data, spanning ",s_delta_days," days")
    
    if eperiod != []:
        gts_edate=self.extract_periods([eperiod])
        if gts_edate.data is None:
            print("!!! No data available in final period ",eperiod," for site ",self.code)
            return(None)
    else:
        gts_edate=self.extract_periods([[edate-window/365.25,edate+window/365.25]])
        if gts_edate.data is None:
            print("!!! No data available at final date ",edate," window=",window," days, for site ",self.code)
            return(None)

    if verbose:
        e_delta_days=(gts_edate.data[-1,0]-gts_edate.data[0,0])*365.25
        print("-- Final position calculated using ",gts_edate.data.shape[0]," data, spanning ",e_delta_days," days")

    if method=='median':
        #print gts_edate.data
        pos_sdate=np.median(gts_sdate.data[:,1:4],axis=0)
        pos_edate=np.median(gts_edate.data[:,1:4],axis=0)
        #print pos_sdate,pos_edate
    else:
        pos_sdate=np.mean(gts_sdate.data[:,1:4],axis=0)
        pos_edate=np.mean(gts_edate.data[:,1:4],axis=0)

    def wrms(data,ref):
        data[:,0:3]=data[:,0:3]-ref
        numerator=np.sum(data[:,0:3]**2 / data[:,3:6]**2,axis=0)
        denominator=np.sum(1. / data[:,3:6]**2,axis=0)
        wrms=np.sqrt(numerator / denominator)
        return(wrms)

    std_sdate=wrms(gts_sdate.data[:,1:7],pos_sdate)
    if std_sdate.all()==0.0:std_sdate=gts_sdate.data[0,4:7]
    
    std_edate=wrms(gts_edate.data[:,1:7],pos_edate)
    if std_edate.all()==0.0:std_edate=gts_edate.data[0,4:7]

    disp = pos_edate-pos_sdate
    std_disp = np.sqrt(std_edate**2+std_sdate**2)
    
    displacement=[disp[0],disp[1],disp[2],std_disp[0],std_disp[1],std_disp[2]]
    return(np.array(displacement))

###################################################################
def get_coseismic(self,eq_date,window_days=5,sample_after=1,method='median',in_place=False):
###################################################################
    """
    Get the coseismic displacement at a given date
    
    note: only median method implemented
    
    """
    
    # import 
    import numpy as np

    # check data is not None
    from pyacs.gts.lib.errors import GtsInputDataNone
    
    try:
        if self.data is None:
            # raise exception
            raise GtsInputDataNone(inspect.stack()[0][3],__name__,self)
    except GtsInputDataNone as error:
        # print PYACS WARNING
        print( error )
        return( self )

    tolerance=0.25/365.25
    gts_sdate=self.extract_periods([[eq_date-window_days/365.25,eq_date-tolerance]])
    gts_edate=self.extract_periods([[eq_date+tolerance,eq_date+window_days/365.25,]])
    
    pos_sdate=np.median(gts_sdate.data,axis=0)[1:4]
    pos_edate=np.median(gts_edate.data[:sample_after,:],axis=0)[1:4]

    std_sdate=np.std(gts_sdate.data,axis=0)[1:4]
    if np.max(std_sdate)==0.0:
        std_sdate=np.mean(gts_sdate.data,axis=0)[4:8]
    std_edate=np.std(gts_edate.data[:sample_after,:],axis=0)[1:4]
    if np.max(std_edate)==0.0:
        std_edate=np.mean(gts_edate.data,axis=0)[4:8]

    disp=pos_edate-pos_sdate
    std_disp=np.sqrt(std_edate**2+std_sdate**2)

    new_Gts=self.copy()
    
    if in_place:
        self.offsets_values=np.array([eq_date]+disp.tolist()+std_disp.tolist()).reshape(1,7)
        return(self)
        del new_Gts
    else:
        new_Gts=self.copy()
        new_Gts.offsets_values=np.array([eq_date]+disp.tolist()+std_disp.tolist()).reshape(1,7)
        return(new_Gts)

###################################################################
def decimate(self,time_step=30.,dates=[],method='median',verbose=False):
###################################################################
    """
    decimate a time series
    
    :param time_step: time step in days
    :param dates: list of dates where point are forced to be written regardless time_step
    :param method: method used to be used to calculated the position. choose among ['median','mean','exact']
    :param verbose: verbose mode
    
    :return : new Gts  
    """

    
    # import
    import numpy as np
    import pyacs.lib.astrotime

    # check data is not None
    from pyacs.gts.lib.errors import GtsInputDataNone
    
    try:
        if self.data is None:
            # raise exception
            raise GtsInputDataNone(inspect.stack()[0][3],__name__,self)
    except GtsInputDataNone as error:
        # print PYACS WARNING
        print( error )
        return( self )

    # start and end date
    start_decyear = self.data[0,0]
    end_decyear = self.data[-1,0]

    start_mjd = pyacs.lib.astrotime.decyear2mjd(start_decyear)
    end_mjd = pyacs.lib.astrotime.decyear2mjd(end_decyear)
    
    # new_gts to be filled
    new_gts=self.copy()
    
    new_gts.data=np.zeros((1,self.data.shape[1]))
    
    # loop on dates by time_step
    
    for date in np.arange(start_mjd ,end_mjd + time_step / 2. , time_step ):
        sub_ts=self.extract_periods( [pyacs.lib.astrotime.mjd2decyear(date-time_step/2.),pyacs.lib.astrotime.mjd2decyear(date+time_step/2.)] , verbose = verbose)
                
        if sub_ts.data is None:
            continue
        
        if method == 'median':
            new_obs = np.median(sub_ts.data,axis=0)
        if method == 'mean':
            new_obs = np.mean(sub_ts.data,axis=0)
        if method == 'exact':
            new_obs = sub_ts.data[int(sub_ts.data.shape[0])-1,:]

    
        new_gts.data = np.vstack( ( new_gts.data, new_obs.reshape(1,-1) ) )

    # case dates are provided
    
    for date in dates:
        sub_ts=self.extract_periods( [date,end_decyear] , verbose = verbose)
        
        if sub_ts.data is not None:
            new_obs = sub_ts.data[0,:]
            if verbose:
                print("-- adding observation at user requested date: %lf = %s = doy %d" % 
                      ( date, '-'.join(map(str,pyacs.lib.astrotime.decyear2cal(date))),pyacs.lib.astrotime.decyear2dayno(date)))
                
            if new_gts.data is not None:
                new_gts.data = np.vstack( ( new_gts.data, new_obs.reshape(1,-1) ) )
            else:
                new_gts.data = new_obs.new_obs.reshape(1,-1)

    # remove first obs
    
    if new_gts.data.shape[0] == 1:
        if verbose:
            print('!!! decimated Gts has no date')
        new_gts.data = None
        new_gts.data_xyz
        return(new_gts)
    
    else:
        
        new_gts.data = np.delete(new_gts.data,0,axis=0)
        new_gts.neu2xyz()
        
        # reorder
        new_gts.reorder(verbose=verbose)
        if verbose:
            print('-- decimated Gts has ',new_gts.data.shape[0],' entries')

        return(new_gts)



























