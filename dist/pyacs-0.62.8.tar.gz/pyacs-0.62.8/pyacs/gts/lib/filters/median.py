"""
Median filter for Gts based on scipy.signal.medfilt.
"""

###############################################################################
def median_filter(self , n , in_place=False , verbose=True):
###############################################################################
    """
    returns a filtered time series using scipy.signal.medfilt
    
    :param n: size of the median filter window
    :param in_place: if True then replace the current time series
    :param verbose: boolean, verbose mode
    :return: the filtered time series

    """
    
    import scipy.signal
    
    new_gts=self.copy()
    
    new_gts.data[:,1] = scipy.signal.medfilt(self.data[:,1],n)
    new_gts.data[:,2] = scipy.signal.medfilt(self.data[:,2],n)
    new_gts.data[:,3] = scipy.signal.medfilt(self.data[:,3],n)

    if in_place:
            self.data=new_gts.data
    else:
        return(new_gts)
