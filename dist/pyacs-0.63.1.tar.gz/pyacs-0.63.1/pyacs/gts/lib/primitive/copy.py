###################################################################
def copy(self,data=False, copy_outliers=True):
###################################################################
    """
    makes a (deep) copy of the time series
    if data is provided, fills data with the provided array.
    """

    # import 
    import numpy as np
    import copy
    import pyacs.gts
    
    # deep copy
    new_Gts=copy.deepcopy(self)
    
    if isinstance(data,np.ndarray):
        new_Gts.data=np.copy(data)
    
    # handles outliers

    if isinstance(new_Gts.data,np.ndarray):

        ldate_outliers = self.data[:,0][self.outliers]
        lupdated_outliers = pyacs.gts.Gts.get_index_from_dates(ldate_outliers, new_Gts.data, tol=0.01)

        new_Gts.outliers = lupdated_outliers 

    else:
        new_Gts.outliers = []

    return( new_Gts )
