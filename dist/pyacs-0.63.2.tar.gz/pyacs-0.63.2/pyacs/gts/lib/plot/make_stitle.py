###############################################################################
def make_stitle(component,velocity,data,unit, info=[]):
###############################################################################
    """
    
    :param info: a list of keywords of information to be displayed: 'wrms','bias','vel','period'
    """
    
    
    import pyacs.lib.astrotime
    import numpy as np
    
    str_title=''
  
    # component
    if component=='N':
        txt_component='North'
        idx = 0
    if component=='E':
        txt_component='East'
        idx = 1
    if component=='U':
        txt_component='Up'
        idx = 2
    
    str_title = str_title+("%s " % (txt_component) )
    
    # velocity
    if 'vel' in info:
        if isinstance(velocity,float):
            str_title = str_title+(" V = %.2lf %s/yr" % (velocity, unit) )

    # wrms
    if 'wrms' in info:
        wmean= np.sum( (data[:,idx]/data[:,idx+3]**2 ) ) / np.sum(1./data[:,idx+3]**2)
        wrms=np.sqrt( np.sum( ( (data[:,idx]-wmean)**2/data[:,idx+3]**2 ) ) / np.sum(1./data[:,idx+3]**2) )
        str_title = str_title+(" wrms=%5.1lf " % (wrms) )
    
    # period  
    if 'period' in info:
        sdoy,_ut=pyacs.lib.astrotime.decyear2dayno(data[0,0])
        syear=int(data[0,0])
        
        edoy,_ut=pyacs.lib.astrotime.decyear2dayno(data[-1,0])
        eyear=int(data[-1,0])
        
        duration=data[-1,0]-data[0,0]
        
        str_period=(" %04d/%03d - %04d/%03d - %4.1lf yr" % (syear,sdoy,eyear,edoy,duration))
        str_title=str_title + (" #%d (%s)" % ( data.shape[0], str_period )) 

    # bias
    if 'bias' in info:
        bias=np.median((data[:,1]))
        str_title=str_title+" bias=%5.1lf " % (bias)

    return(str_title)
