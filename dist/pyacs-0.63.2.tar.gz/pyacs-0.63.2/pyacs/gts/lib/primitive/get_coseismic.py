###################################################################
def get_coseismic(self,eq_date,window_days=5,sample_after=1,method='median',in_place=False):
###################################################################
    """
    Get the coseismic displacement at a given date
    
    note: only median method implemented
    
    """
    
    # import 
    import inspect
    import numpy as np

    # check data is not None
    from pyacs.gts.lib.errors import GtsInputDataNone
    
    try:
        if self.data is None:
            # raise exception
            raise GtsInputDataNone(inspect.stack()[0][3],__name__,self)
    except GtsInputDataNone as error:
        # print PYACS WARNING
        print( error )
        return( self )

    tolerance=0.25/365.25
    gts_sdate=self.extract_periods([[eq_date-window_days/365.25,eq_date-tolerance]])
    gts_edate=self.extract_periods([[eq_date+tolerance,eq_date+window_days/365.25,]])
    
    pos_sdate=np.median(gts_sdate.data,axis=0)[1:4]
    pos_edate=np.median(gts_edate.data[:sample_after,:],axis=0)[1:4]

    std_sdate=np.std(gts_sdate.data,axis=0)[1:4]
    if np.max(std_sdate)==0.0:
        std_sdate=np.mean(gts_sdate.data,axis=0)[4:8]
    std_edate=np.std(gts_edate.data[:sample_after,:],axis=0)[1:4]
    if np.max(std_edate)==0.0:
        std_edate=np.mean(gts_edate.data,axis=0)[4:8]

    disp=pos_edate-pos_sdate
    std_disp=np.sqrt(std_edate**2+std_sdate**2)

    new_Gts=self.copy()
    
    if in_place:
        self.offsets_values=np.array([eq_date]+disp.tolist()+std_disp.tolist()).reshape(1,7)
        return(self)
        del new_Gts
    else:
        new_Gts=self.copy()
        new_Gts.offsets_values=np.array([eq_date]+disp.tolist()+std_disp.tolist()).reshape(1,7)
        return(new_Gts)
