###################################################################
def displacement(self,sdate=None,edate=None,window=None,method='median',speriod=[],eperiod=[],verbose=True):
###################################################################
    """
    Calculates displacements between two dates or two periods
    
    :return: displacement as np.array([dn,de,du,sdn,sde,sdu])
    """
    
    # import 
    import inspect
    import numpy as np

    # check data is not None
    from pyacs.gts.lib.errors import GtsInputDataNone
    
    try:
        if self.data is None:
            # raise exception
            raise GtsInputDataNone(inspect.stack()[0][3],__name__,self)
    except GtsInputDataNone as error:
        # print PYACS WARNING
        print( error )
        return( )


    if speriod != []:
        gts_sdate=self.extract_periods([speriod])
        if gts_sdate.data is None:
            print("!!! No data available in initial period ",speriod," for site ",self.code)
            return(None)
    else:
        gts_sdate=self.extract_periods([[sdate-window/365.25,sdate+window/365.25]])
        if gts_sdate.data is None:
            print("!!! No data available at initial date ",sdate," window=",window," days, for site ",self.code)
            return(None)

    if verbose:
        s_delta_days=(gts_sdate.data[-1,0]-gts_sdate.data[0,0])*365.25
        print("-- Initial position calculated using ",gts_sdate.data.shape[0]," data, spanning ",s_delta_days," days")
    
    if eperiod != []:
        gts_edate=self.extract_periods([eperiod])
        if gts_edate.data is None:
            print("!!! No data available in final period ",eperiod," for site ",self.code)
            return(None)
    else:
        gts_edate=self.extract_periods([[edate-window/365.25,edate+window/365.25]])
        if gts_edate.data is None:
            print("!!! No data available at final date ",edate," window=",window," days, for site ",self.code)
            return(None)

    if verbose:
        e_delta_days=(gts_edate.data[-1,0]-gts_edate.data[0,0])*365.25
        print("-- Final position calculated using ",gts_edate.data.shape[0]," data, spanning ",e_delta_days," days")

    if method=='median':
        #print gts_edate.data
        pos_sdate=np.median(gts_sdate.data[:,1:4],axis=0)
        pos_edate=np.median(gts_edate.data[:,1:4],axis=0)
        #print pos_sdate,pos_edate
    else:
        pos_sdate=np.mean(gts_sdate.data[:,1:4],axis=0)
        pos_edate=np.mean(gts_edate.data[:,1:4],axis=0)

    def wrms(data,ref):
        data[:,0:3]=data[:,0:3]-ref
        numerator=np.sum(data[:,0:3]**2 / data[:,3:6]**2,axis=0)
        denominator=np.sum(1. / data[:,3:6]**2,axis=0)
        wrms=np.sqrt(numerator / denominator)
        return(wrms)

    std_sdate=wrms(gts_sdate.data[:,1:7],pos_sdate)
    if std_sdate.all()==0.0:std_sdate=gts_sdate.data[0,4:7]
    
    std_edate=wrms(gts_edate.data[:,1:7],pos_edate)
    if std_edate.all()==0.0:std_edate=gts_edate.data[0,4:7]

    disp = pos_edate-pos_sdate
    std_disp = np.sqrt(std_edate**2+std_sdate**2)
    
    displacement=[disp[0],disp[1],disp[2],std_disp[0],std_disp[1],std_disp[2]]
    
    return(np.array(displacement))
