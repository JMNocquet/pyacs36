###############################################################################
# CUSTOM IMPORT
###############################################################################
#
# __custom_import__ = ['find_l1trend',
#                      'remove_outliers',
#                      'find_outliers_around_date',
#                      'find_outliers_percentage',
#                      'find_outliers_simple',
#                      'find_outliers_vondrak',
#                      'find_outliers_sliding_window']
#
# for mod in __custom_import__:
#     exec('from .' + mod + ' import *')