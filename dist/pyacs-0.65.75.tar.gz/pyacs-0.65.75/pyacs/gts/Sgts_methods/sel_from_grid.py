###################################################################
def sel_from_grid(self, grid, depth_range=[0,200]):
###################################################################
    """
    selects sites that are above a grid (typically slab2 grid) in a given depth range

    :param grid: netcdf grid name
    :param depth_range: depth range in kilometres [depth_min, depth_max]

    :return: a new Sgts instance including all selected time series
    """

    # import
    from pyacs.gts.Sgts import Sgts

    import logging
    import pyacs.message.message as MESSAGE
    import pyacs.message.verbose_message as VERBOSE
    import pyacs.message.error as ERROR
    import pyacs.message.warning as WARNING
    import pyacs.message.debug_message as DEBUG
    import pyacs.debug

    import numpy as np
    from tqdm import tqdm
    import scipy.interpolate
    import netCDF4

    # reads the grid

    try:
        ds = netCDF4.Dataset(grid)
    except:
        ERROR(("Could not read grid: %s" % (grid)), exit=True)

    # creates the interpolator
    z = ds.variables['z'][:].T
    interp = scipy.interpolate.RegularGridInterpolator(
        tuple((ds.variables['x'][:], ds.variables['y'][:])),
        z.data,
        method='linear',
        bounds_error=False)

    # initialize new Sgts
    new_Sgts = Sgts(read=False)

    # create array of lon,lat,depth
    COOR = np.zeros(( self.n() , 3 ))
    np_name = np.array(self.lcode(),dtype=str)
    for i in np.arange( np_name.shape[0] ):
        COOR[i,0] = self.__dict__[ np_name[i] ].lon
        COOR[i,1] = self.__dict__[ np_name[i] ].lat


    # get depth
    COOR[:,2] = np.fabs( interp( (COOR[:,0], COOR[:,1]) ) )

    # get index
    lidx = np.where( (COOR[:,2] > depth_range[0]) & (COOR[:,2] < depth_range[1]) )[0]
    VERBOSE("#sites selected: %d / %d" % (len(lidx),np_name.shape[0]) )

    #return
    return self.sub(linclude=np_name[lidx])
