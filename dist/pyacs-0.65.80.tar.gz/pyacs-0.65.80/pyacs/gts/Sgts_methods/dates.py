def dates(self,unit='decyear'):
    """
    returns start and end dates of a Sgts intance
    :param self:
    :param unit: date unit. Choose among ['decyear','datetime']
    :return: start and end date
    """

    start_date = 9999.
    end_date   = 0.

    for wts in self.lGts():
        start_date = min(start_date,wts.data[0,0])
        end_date = max(end_date,wts.data[-1,0])

    return start_date,end_date
