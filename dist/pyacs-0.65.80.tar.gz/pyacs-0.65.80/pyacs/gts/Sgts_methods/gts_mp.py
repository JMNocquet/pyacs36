def gts_mp(self, method, *args, **kwargs):
    from pyacs.gts.Sgts import Sgts
    from tqdm import tqdm

    import logging
    import pyacs.message.message as MESSAGE
    import pyacs.message.verbose_message as VERBOSE
    import pyacs.message.error as ERROR
    import pyacs.message.warning as WARNING
    import pyacs.message.debug_message as DEBUG
    import pyacs.debug

    import ipyparallel as ipp

    sgts = self

    verbose = kwargs.get('verbose', False)
    ncpu = kwargs.get('ncpu', 4)

    MESSAGE("Will run %s method on %d Gts using %d CPU" % (method, sgts.n(), ncpu))

    def task(gts, method, *arg, **kwargs):
        func = getattr(gts, method)
        try:
            new_gts = func(*args, **kwargs)
        except:
            new_gts = None
        return new_gts

    # request a cluster
    n = sgts.n()
    with ipp.Cluster(n=ncpu) as rc:
        # get a view on the cluster
        view = rc.load_balanced_view()
        # submit the tasks
        asyncresult = view.map_async(task, sgts.lGts(), [method] * n, [args] * n, [kwargs] * n)
        # wait interactively for results
        asyncresult.wait_interactive()
        # retrieve actual results
        result = asyncresult.get()
    # at this point, the cluster processes have been shutdown

    # populates with results

    new_ts = Sgts(read=False)
    for gts in result:
        if gts is not None:
            new_ts.append(gts)

    # print missing
    lgood_code = new_ts.lcode()
    for code in sorted(sgts.lcode()):
        if code not in lgood_code:
            ERROR(("Problem while applying %s to %s. Skipped from output Sgts." % (method, code)))

    return (new_ts)
