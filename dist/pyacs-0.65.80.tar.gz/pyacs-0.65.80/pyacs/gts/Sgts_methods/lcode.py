###################################################################
def lcode(self,lexclude=[],linclude=[],min_obs=None,max_obs=None, min_duration=None):
###################################################################
    """
    Returns the list of Gts codes in the current Sgts
    exclude is a list of code to be excluded
     
    :param lexclude: list of sites to be excluded
    :param linclude: list of sites to be included, excluding all other.
    :param min_obs: minimum number of epochs for a site
    :param max_obs: maximum number of epochs for a site
    :param min_duration: minimum duration (decimal year) of time series for a site
    """
    # import
    import re

    import logging
    import pyacs.message.message as MESSAGE
    import pyacs.message.verbose_message as VERBOSE
    import pyacs.message.error as ERROR
    import pyacs.message.warning as WARNING
    import pyacs.message.debug_message as DEBUG

    lcode=[]
    if linclude != []:
        for k in list(self.__dict__.keys()):
            if ((re.match('[A-Z0-9_]{4}',k))) and (k not in lexclude) and (k in linclude):lcode.append(k)
    else:
        for k in list(self.__dict__.keys()):
            if ((re.match('[A-Z0-9_]{4}',k))) and (k not in lexclude):lcode.append(k)

    # min_obs
    if min_obs is not None:
        llcode = []
        for code in lcode:
            if self.__dict__[code].data.shape[0] < min_obs:
                VERBOSE("%s has less than %d epochs. Excluding it" %(code,self.__dict__[code].data.shape[0]))
            else:
                llcode.append(code)
        lcode = llcode

    # max_obs
    if max_obs is not None:
        llcode = []
        for code in lcode:
            if self.__dict__[code].data.shape[0] <= max_obs:
                llcode.append(code)
        lcode = llcode

    # min_duration
    if min_duration is not None:
        llcode = []
        for code in lcode:
            duration = self.__dict__[code].data.shape[-1,0] - self.__dict__[code].data.shape[0,0]
            if duration < min_duration:
                VERBOSE("%s time series has a duration less than %.3lf years. Excluding it" % (code, duration))
            else:
                llcode.append(code)
        lcode = llcode


    return(lcode)
