###############################################################################
def plot_component(self,
         component='E',
         lorder=[],
         shift = 10.,
         Hshift={},
         title=None,
         loffset=True,
         loutliers=True,
         verbose=False,
         date=[],
         yaxis=None,
         min_yaxis=None,
         yupaxis=None,
         xticks_minor_locator=1,
         error_scale=1.0,
         lperiod=[[]],
         lvline=[],
         save_dir_plots='.',
         save=None,
         show=True,
         unit='mm',
         date_unit='cal',
         date_ref=0.0,
         superimposed=None,
         lcolor=[],
         label=None,
         legend=0.2,
         grid=True,
         plot_size=None,
         xlabel_fmt=None,
         **kwargs):
    ###############################################################################
    """
    Create a plot for multiple time series using Matplotlib

    Coordinates of the time series are assumed to be in meters
    default plots units will be mm; Use unit='m' to get meters instead

    :param component: component to be displayed.Default is 'E'.
    :param lorder: list of code order from top to bottom
    :param shift: shift between two successive time series in mm
    :param Hshift: dictionnary to force offset of a time series Hshift = {'code':offset}
    :param title: string for title
    :param verbose: boolean
        verbose mode
    :param date: [sdate,edate]
        start and end date for plots
        sdate and edate in decimal years if date_unit is either 'decyear' or 'cal', or in days if date_unit is 'days'
    :param yaxis: [min_y,max_y]
        min and max value for the yaxis
        if not provided automatically adjusted
    :param yupaxis: same as yaxis but applies to the up component only
    :param xticks_minor_locator: where xticks_minor_locator will be placed. Float when date_unit is 'decyear' or 'days', a string '%Y','%m','%d' is date_unit is 'cal'.
    :param lcomponent: list of components to be plotted (default =['N','E','U'])
    :param error_scale: scaling factor for error bars (default = 1.0, 0 means no error bar)
    :param lperiod: list of periods to be drawn in background (color=light salmon)
    :param lvline: list of dates where vertical lines will be drawn in background (color=green)
    :param save_dir_plots: directory used for saving the plots
    :param save: name ,save the plot into name, if False, do not save
    :param show: boolean, is True show the plot
    :param unit: 'm','cm','mm', default='mm'
    :param date_unit: 'decyear' or 'cal' or 'days', default='decyear'
    :param shift: controls time series separation. default 10
    :param superimposed: if a gts is provided, it is superimposed to the master, default=None
    :param lcolor: color list used for the superimposed time series, default=['r','g','c','m','y','k','b']
    :param legend: value for legend space, default=0.2 (20%)
    :param plot_size: plot size as a tuple. Default, best guess.
    :param grid: boolean
    :param **kwargs: any argument to be passed to  matplotlib.pyplot.errorbar

    :note: The list of kwargs are:

    {  'linewidth' : 0,\
       'marker' : marker_main_symbol ,\
       'markersize' : marker_main_size, \
       'markerfacecolor' : marker_main_color,\
       'markeredgecolor' : marker_main_color,\
       'markeredgewidth' : marker_main_colorlw,\
       'ecolor' : error_bar_color,\
       'elinewidth' : error_bar_linewidth,\
       'capsize' : error_bar_capsize }

    """

    ###########################################################################
    # import
    ###########################################################################

    # system
    import inspect
    import numpy as np
    import os.path

    # matplotlib
    import matplotlib.pyplot as plt
    import matplotlib.ticker as ticker
    from matplotlib.ticker import MultipleLocator
    import matplotlib.dates as mdates

    # pyacs
    from pyacs.gts.lib.errors import GtsInputDataNone
    import pyacs.gts.lib.plot.init_plot_settings
    import pyacs.lib.astrotime
    from pyacs.gts.Gts import Gts
    import pyacs.lib.utils
    import pyacs.gts.lib.plot.make_stitle
    import pyacs.gts.lib.plot.gts_to_ts

    # debug
    from icecream import ic

    # lcolor
    if lcolor == []:
        import matplotlib.colors as mcolors
        lcolor = list(mcolors.BASE_COLORS.keys())[:-2] + list(mcolors.TABLEAU_COLORS.keys()) + list(mcolors.XKCD_COLORS.keys())

    ###########################################################################
    # ensure lperiod is a list of list
    ###########################################################################
    lperiod = pyacs.lib.utils.__ensure_list_of_list(lperiod)

    ###########################################################################
    # init default plot settings
    ###########################################################################

    H_plot_settings, H_kwargs_errorbar, H_kwargs_errorbar_superimposed = pyacs.gts.lib.plot.init_plot_settings.__init_kwargs()

    ###########################################################################
    # init plot settings with user provided values
    ###########################################################################

    for k, v in kwargs.items():
        H_kwargs_errorbar[k] = v

        # turn show to off by default
    plt.ioff()

    # some drawing default parameters
    params = {'legend.fontsize': 11}
    plt.rcParams.update(params)

    # For figure caption
    txt_component = {}
    txt_component['N'] = 'North'
    txt_component['E'] = 'East'
    txt_component['U'] = 'Up'

    # plot size
    if plot_size is None:
        plot_size = H_plot_settings['plot_size_3_component']

    lperiod_facecolor = 'r'
    lperiod_alpha = 0.4


    ###########################################################################
    # title and subtitle
    ###########################################################################

    if title is not None:
        stitle = title
    else:
        stitle = txt_component[component]

    ###########################################################################
    # to_unit
    ###########################################################################

    if unit == 'cm':
        to_unit = 100.

    if unit == 'mm':
        to_unit = 1000.

    ###########################################################################
    # START PLOTTING
    ###########################################################################
    plt.ioff()

    ###########################################################################
    # handle order
    ###########################################################################

    if lorder == []:
        # use alpha_numeric order
        lorder = sorted(self.lcode())

    lorder.reverse()

    ###########################################################################
    # format for printing duration in subplot titles
    ###########################################################################

    if date != []:
        duration = date[-1] - date[0]
    else:
        #ic(self.__dict__[lorder[0]])
        duration = self.__dict__[lorder[0]].data[-1, 0] - self.__dict__[lorder[0]].data[0, 0]

    ###########################################################################
    # x-tick label
    ###########################################################################
    # adjust tickers for the decyear case
    if date_unit == 'decyear' or date_unit == 'days':
        if xlabel_fmt != None:
            fmt = ticker.FormatStrFormatter(xlabel_fmt)
        else:
            if duration >= 1.0: fmt = ticker.FormatStrFormatter('%4.0lf')
            if duration < 1.0: fmt = ticker.FormatStrFormatter('%6.2lf')
            if duration < 0.2: fmt = ticker.FormatStrFormatter('%6.3lf')
            if duration < 0.1: fmt = ticker.FormatStrFormatter('%6.4lf')

        plt.rcParams['axes.formatter.limits'] = (-7, 17)

    if date_unit == 'cal':
        if xlabel_fmt is not None:
            fmt = mdates.DateFormatter(xlabel_fmt)


    ###########################################################################
    # handle shift
    ###########################################################################

    for i,code in enumerate(lorder):
        if code in Hshift.keys():
            Hshift[code] = shift * i + Hshift[code]
        else:
            Hshift[code] = shift * i

    ###########################################################################
    # init figure
    ###########################################################################
    Hctoidx={'N':0,'E':1,'U':2}
    idxc = Hctoidx[component]

    f, ax = plt.subplots(1,figsize=plot_size)

    # plot settings
    # grid
    ax.grid(grid)
    # xticks
    if date_unit == 'decyear':
        ax.xaxis.set_major_formatter(fmt)

    if date_unit == 'cal' and xlabel_fmt is not None:
        ax.xaxis.set_major_formatter(fmt)

    # subplot title
    ax.set_title(stitle, x=0, horizontalalignment='left', fontsize='11')

    ###########################################################################
    # rotate xticks labels
    ###########################################################################
    f.autofmt_xdate(bottom=0.2, rotation=30, ha='right')

    ###########################################################################
    # date & unit transformation
    ###########################################################################

    ts = self.sub(linclude=lorder)
    if date != []:
        ts = ts.gts('extract_periods',date)

    for i,code in enumerate(lorder):
        #ic(code)
        np_date, data = pyacs.gts.lib.plot.gts_to_ts.gts_to_ts(self.__dict__[code], \
                                                               date=date, \
                                                               unit=unit, \
                                                               date_unit=date_unit)

        # plot the data
        H_kwargs_errorbar['markerfacecolor'] = lcolor[i]
        #ic(code,Hshift[code])
        ax.errorbar(np_date, data[:, idxc] - np.median(data[:, idxc]) +Hshift[code], yerr=data[:, idxc + 3] * error_scale, label=code, **H_kwargs_errorbar)

        # superimposed time series
        ###########################################################################

        if superimposed is not None and code in superimposed.lcode():
            np_date, data = pyacs.gts.lib.plot.gts_to_ts.gts_to_ts(superimposed.__dict__[code], \
                                                                   date=date, \
                                                                   unit=unit, \
                                                                   date_unit=date_unit)

            ax.errorbar(np_date, data[:, idxc]- np.median(data[:, idxc])+Hshift[code], yerr=data[:, idxc + 3] * error_scale, color=lcolor[i])

        ###########################################################################
        if loffset:
            if date_unit == 'days':
                if (date_ref is None) or (date_ref == 0):
                    # reference data is year.000
                    date_ref = float(int(self.__dict__[code].data[0, 0]))

                ldate_offsets_in_date_unit = pyacs.lib.astrotime.decyear2mjd(
                    self.offsets_dates) - pyacs.lib.astrotime.decyear2mjd(date_ref)

            if date_unit == 'decyear':
                ldate_offsets_in_date_unit = np.array(self.offsets_dates) - date_ref

            if date_unit == 'cal':
                ldate_offsets_in_date_unit = pyacs.lib.astrotime.decyear2datetime(self.__dict__[code].offsets_dates)

            for odate in ldate_offsets_in_date_unit:
                ax.axvline(x=odate, linewidth=2, color='k', linestyle='--')


    # lperiod option: periods to be highlighted
    ###########################################################################

    if lperiod != [[]]:
        if date_unit == 'days':
            if (date_ref is None) or (date_ref == 0):
                # reference data is year.000
                date_ref = float(int(self.data[0, 0]))

            lperiod = pyacs.lib.astrotime.day_since_decyear(np.array(lperiod).flatten(), date_ref).reshape(-1, 2)

        if date_unit == 'decyear':
            lperiod = (np.array(lperiod).flatten() - date_ref).reshape(-1, 2)

        if date_unit == 'cal':
            lperiod = np.array(pyacs.lib.astrotime.decyear2datetime(np.array(lperiod).flatten())).reshape(-1, 2)

        # plot color background for periods
        for period in lperiod:
            (sdate, edate) = period
            ax.axvspan(sdate, edate, facecolor=lperiod_facecolor, alpha=lperiod_alpha)

    # vertical lines option
    ###########################################################################

    if lvline != []:

        if date_unit == 'decyear':
            lvline_in_date_unit = np.array(lvline) - date_ref

        if date_unit == 'days':
            lvline_in_date_unit = np.array(lvline) - date_ref

        if date_unit == 'cal':
            lvline_in_date_unit = pyacs.lib.astrotime.decyear2datetime(lvline)

        for odate in lvline_in_date_unit:
            ax.axvline(x=odate, linewidth=2, color='g', linestyle='--')

    # title
    ###########################################################################
    # plt.suptitle(stitle)

    # date
    ###########################################################################

    if date != []:

        # case 'days'
        if date_unit == 'days':
            if (date_ref is None) or (date_ref == 0):
                np_date_x = pyacs.lib.astrotime.decyear2mjd(np.array(date)) - pyacs.lib.astrotime.decyear2mjd(
                    date[0])
            else:
                np_date_x = pyacs.lib.astrotime.decyear2mjd(np.array(date)) - pyacs.lib.astrotime.decyear2mjd(
                    date_ref)

        # case 'decyear'
        if date_unit == 'decyear':
            if (date_ref is None) or (date_ref == 0):
                np_date_x = np.array(date)
            else:
                np_date_x = np.array(date) - date_ref

        # case 'cal'
        if date_unit == 'cal':
            np_date_x = pyacs.lib.astrotime.decyear2datetime(np.array(date))

        ax.set_xlim(np_date_x[0], np_date_x[1])

    # X Label
    ###########################################################################

    if date_unit == 'decyear':
        if (date_ref is None) or (date_ref == 0.0):
            str_xlabel = 'year'
        else:
            str_xlabel = ("decimal year since %s" % pyacs.lib.astrotime.decyear2datetime(date_ref))

    if date_unit == 'days':

        if (date_ref is None) or (date_ref == 0):
            # reference data is year.000
            date_ref = float(int(self.data[0, 0]))

        str_xlabel = ("days since %s" % pyacs.lib.astrotime.decyear2datetime(date_ref))

    if date_unit == 'cal':
        str_xlabel = ("calendar date")

    ax.set_xlabel(str_xlabel)

    # xtcicks minor locator
    ###########################################################################
    if date_unit == 'decyear':
        ax.xaxis.set_minor_locator(MultipleLocator(float(xticks_minor_locator)))

    if date_unit != 'days':
        idx_ax = 0
        if duration > 100:
            xticks_minor_locator = 10
        if duration > 1000:
            xticks_minor_locator = 100
        if duration > 10000:
            xticks_minor_locator = 1000

        ax.xaxis.set_minor_locator(MultipleLocator(float(xticks_minor_locator)))

    if date_unit == 'cal':
        # default
        if self.__dict__[code].data[-1, 0] - self.__dict__[code].data[0, 0] > 5.:
            locator = mdates.YearLocator()
        else:
            locator = mdates.MonthLocator()

        # user provided default
        if xticks_minor_locator == '%Y':
            locator = mdates.YearLocator()  # every year
        if xticks_minor_locator == '%m':
            locator = mdates.MonthLocator()  # every month
        if xticks_minor_locator == '%d':
            locator = mdates.DayLocator()  # every day

        ax.xaxis.set_minor_locator(locator)

    # y-axis label

    ax.set_ylabel(unit)


    # legend
    ###########################################################################

    handles, labels = ax.get_legend_handles_labels()

    # Shrink current axis by 20%
    box = ax.get_position()
    ax.set_position([box.x0, box.y0, box.width * (1-legend), box.height])

    # Put a legend to the right of the current axis
    ax.legend(handles[::-1], labels[::-1],loc='center left', bbox_to_anchor=(1, .5),markerscale=3. )

    # tight_layout
    ###########################################################################

    #plt.tight_layout()

    #plt.subplots_adjust(left=None, bottom=None, right=None, top=None, wspace=None, hspace=H_plot_settings['hspace'])

    # end of subplots
    ###########################################################################

    # save file as png if save option is set
    ###########################################################################

    if save is not None:

        # case save is a string

        if isinstance(save, str):

            # check whether save includes a path or simply a file name

            if os.path.sep in save:
                # save includes a path information
                fname = save
            else:
                # else
                fname = os.path.normpath(save_dir_plots + '/' + save)

        elif save:
            # save is simply set to True for automatic output file naming
            fname = os.path.normpath(save_dir_plots + '/' + self.code + '.png')

        # saving output file

        if verbose:
            print("-- Saving file to ", fname)

        # creates the directory of it does not exist

        if os.path.sep in fname:
            os.makedirs(os.path.dirname(fname), exist_ok=True)

        #        plt.savefig(fname, dpi=150, facecolor='w', edgecolor='w', orientation='portrait', papertype='a4', format='png',transparent=False, pad_inches=0.1)
        # change 05/04/2021 papertype appears to be decommissioned for matplotlib 3.3
        plt.savefig(fname, dpi=150, facecolor='w', edgecolor='w', orientation='portrait', format='png',
                    transparent=False, pad_inches=0.1)

    # show
    ###########################################################################
    if show:
        # do not block program execution when displaying figures
        plt.ion()
        plt.show()
    else:
        plt.close(f)

    # returns the Sgts for pyacs convention compatibility
    return ( self )

