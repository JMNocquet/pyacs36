###################################################################
def sel_rectangle(self,bounds,verbose=True):
###################################################################
    """
    selects the time series for sites within a rectangles
     
    :param bounds: [lon_min,lon_max,lat_min,lat_max]
    :pram verbose: verbose mode
     
    :return: a new Sgts instance
    """


    # import    
    from pyacs.gts.Sgts import Sgts
    import logging
    import pyacs.message.message as MESSAGE
    import pyacs.message.verbose_message as VERBOSE
    import pyacs.message.error as ERROR
    import pyacs.message.warning as WARNING
    import pyacs.message.debug_message as DEBUG
    import pyacs.debug
    from tqdm import tqdm

    [lon_min,lon_max,lat_min,lat_max]=bounds
    
    new_Sgts=Sgts(read=False)
    for gts in tqdm( self.lGts() ):
        current_lon=gts.lon
        current_lat=gts.lat
         
        if current_lon>=lon_min and current_lon<=lon_max<=lon_max and current_lat>= lat_min and current_lat<=lat_max:
            VERBOSE("%s selected" % gts.code )
            new_Sgts.append(gts)

    return(new_Sgts)
