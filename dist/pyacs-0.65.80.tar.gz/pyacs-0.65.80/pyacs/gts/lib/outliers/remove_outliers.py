###############################################################################
def remove_outliers(self, periods=None, in_place=False):
###############################################################################
    """
    removes outliers provided in self.outliers
    return a new Gts without the outliers
    if in_place = True then self has the outliers removed as well (in _place)
    """

    # import
    import numpy as np
    import logging
    import pyacs.message.message as MESSAGE
    import pyacs.message.verbose_message as VERBOSE
    import pyacs.message.error as ERROR
    import pyacs.message.warning as WARNING
    import pyacs.message.debug_message as DEBUG

    if self.outliers:
        if periods == None:
            data = np.delete(self.data, self.outliers, axis=0)
        else:
            lindex = self.lindex_in_periods(periods)
            ldelete = np.intersect1d(lindex, self.outliers)
            data = np.delete(self.data, ldelete, axis=0)

        if data.shape[0] == 0:
            ERROR("All data are outliers for site %s. Check your outlier detection thereshold or remove time series." % ( self.code ))
            ERROR("Setting data as None")
            data = None
    else:
        data = np.copy(self.data)

    new_Gts = self.copy()
    new_Gts.outliers = []
    new_Gts.data = data

    if in_place:
        self.data = new_Gts.data.copy()
        del new_Gts
        self.outliers = []

        return (self)
    else:
        return (new_Gts)
