def verbose(level='INFO'):
    """
    Set pyacs verbose level using module logging
    :param level: verbose level. Select among 'DEBUG','INFO' or 'VERBOSE','WARNING','ERROR' or 'SILENT'
    :return:
    """

    import logging
    import pyacs.message.message as MESSAGE
    import pyacs.message.verbose_message as VERBOSE
    import pyacs.message.error as ERROR
    import pyacs.message.warning as WARNING
    import pyacs.message.debug_message as DEBUG

    logging_levels={50:'CRITICAL',40:'ERROR',30:'WARNING',20:'INFO',10:'DEBUG',0:'NOTSET'}

    MESSAGE("Current verbose mode is %s " % logging_levels[logging.getLogger("my_logger").level])

    if level.upper() not in ['DEBUG','INFO','VERBOSE','WARNING','ERROR','SILENT']:
        WARNING("level argument not understood: %s" % level)
        WARNING("level must be among: %s" % ",".join(['DEBUG','INFO','VERBOSE','WARNING','ERROR','SILENT']))
        MESSAGE("Setting verbose level to INFO")
        level='INFO'

    if level.upper() == 'DEBUG':
        logging.getLogger("my_logger").setLevel(logging.DEBUG)

    if level.upper() == 'INFO':
        logging.getLogger("my_logger").setLevel(logging.INFO)

    if level.upper() == 'VERBOSE':
        logging.getLogger("my_logger").setLevel(logging.INFO)

    if level.upper() == 'ERROR':
        logging.getLogger("my_logger").setLevel(logging.ERROR)

    if level.upper() == 'SILENT':
        logging.getLogger("my_logger").setLevel(logging.ERROR)

    MESSAGE("Verbose mode set to: %s" % level )

    return