__version__ = '0.65.82'
import pyacs.verbose
pyacs.verbose = pyacs.verbose.verbose
import pyacs.debug
pyacs.debug = pyacs.debug.debug
