def l1trend(self, alpha='auto', ndays_mf=1, criterion='BIC'):
    """
    Performs l1 trend filter. For each component, optimal filter parameter is searched using BIC criterion
    Uses https://pypi.org/project/trendfilter/

    :param ndays_mf: parameter for a median filter to be applied prior to l1-trend filtering
    :param criterion: criterion to select optimal l1-trend filtering. 'BIC' (default), 'AICc', 'Cp' or 'MIX'

    :return: new Gts instance
    """

    PLOT = False

    from trendfilter import trend_filter
    import numpy as np
    from scipy.stats import chi2

    from icecream import ic
    ic.lineWrapWidth = 200
    import logging
    import pyacs.message.message as MESSAGE
    import pyacs.message.verbose_message as VERBOSE
    import pyacs.message.error as ERROR
    import pyacs.message.warning as WARNING
    import pyacs.message.debug_message as DEBUG
    import pyacs.debug

    from scipy.stats import chi2

    if pyacs.debug():
        ic.enable()
    else:
        ic.disable()

    if criterion not in ['BIC', 'AICc', 'Cp', 'MIX']:
        ERROR("keyword criterion must be either BIC, Cp, AICc or MIX", exit=True)

    # median filter if user required
    x = self.data[:, 0]
    if ndays_mf > 1:
        gts = self.median_filter(ndays_mf)
    else:
        gts = self.copy()

    # function to get statistics

    def get_stats_l1_model(y, fy, alpha):
        n = y.shape[0]
        cchi2 = np.sum((fy - y) ** 2 / (1.5 * np.median(np.fabs(np.diff(y)))) ** 2)
        dy = np.diff(fy) / (np.diff(x))
        cp = np.where(np.fabs(np.diff(dy)) > 0.1)[0].shape[0]
        AIC = n * np.log(cchi2 / n) + 2 * cp
        AICc = n * np.log(cchi2 / n) + 2 * cp + 2 * cp * (cp + 1) / (n - cp - 1)
        BIC = n * np.log(cchi2 / n) + np.log(n) * cp
        cdof = x.shape[0] - cp
        cchi2_probability = chi2.cdf(cchi2, cdof) * 100.
        Cp = cchi2 + cp + 2
        # VERBOSE("alpha: %f chi2 : %f fit %.2lf n_param %d chi2_proba: %.2lf Cp: %.2lf AIC: %.2lf BIC: %.2lf " % (
        # alpha, cchi2, np.sqrt(cchi2 / x.shape[0]), cp, cchi2_probability, Cp, AIC, BIC))
        return alpha, cchi2, np.sqrt(cchi2 / x.shape[0]), cp, cchi2_probability, Cp, AICc, BIC

    def best_l1trend(x, y, criterion_idx):

        # H of results
        H_alpha = {}
        step = 1
        CONV = False
        GO = True
        maxiter = 40
        niter = 0
        alpha = 0

        fy = trend_filter(x, y, l_norm=1, alpha_2=np.float_power(10, alpha))['y_fit']
        H_alpha[alpha] = get_stats_l1_model(y, fy, alpha)
        alpha_ref = alpha
        score_ref = H_alpha[alpha][criterion_idx]
        cpref = H_alpha[alpha][-5]
        fy_ref = fy
        ic(niter, alpha_ref, score_ref, cpref)

        # choose probable best start direction according to cp
        if cpref < 0.1 * fy.shape[0]:
            step = -1

        alpha = alpha + step

        while GO:
            niter = niter + 1

            fy = trend_filter(x, y, l_norm=1, alpha_2=np.float_power(10, alpha))['y_fit']
            H_alpha[alpha] = get_stats_l1_model(y, fy, alpha)
            score = H_alpha[alpha][criterion_idx]
            cp = H_alpha[alpha][-5]
            # ic(niter,alpha,score,cp)

            if score < score_ref:
                if np.fabs(score - score_ref) < 0.01:
                    GO = False
                    ic('convergence reached: delta_score < tol')
                if cp == cpref:
                    GO = False
                    ic('convergence reached: same number of parameters')
                alpha_ref = alpha
                score_ref = score
                cpref = cp
                fy_ref = fy
                # ic(niter,alpha_ref,score_ref,cpref)
            else:
                step = -step
                if alpha_ref + step in list(H_alpha.keys()):
                    step = step / 2

            alpha = alpha_ref + step

            # MAXITER
            if niter == maxiter:
                GO = False
                ic('convergence failed: maxiter reached')

        ic('final ', niter, alpha_ref, score_ref, cpref)

        return fy_ref, H_alpha, alpha_ref

    ####################################################################################################################
    # MAIN PART
    ####################################################################################################################

    try:

        # new gts
        ngts = gts.copy()
        if isinstance(alpha, float):
            VERBOSE("Doing l1 trend filtering using alpha %f" % alpha)
            VERBOSE('North component')
            ngts.data[:, 1] = trend_filter(x, gts.data[:, 1] * 1.E3, l_norm=1, alpha_2=alpha)['y_fit'] * 1.E-3
            VERBOSE('East  component')
            ngts.data[:, 2] = trend_filter(x, gts.data[:, 2] * 1.E3, l_norm=1, alpha_2=alpha)['y_fit'] * 1.E-3
            VERBOSE('Up    component')
            ngts.data[:, 3] = trend_filter(x, gts.data[:, 3] * 1.E3, l_norm=1, alpha_2=alpha)['y_fit'] * 1.E-3

        if isinstance(alpha, str) and criterion in ['BIC', 'AICc', 'Cp']:
            if criterion == 'BIC':
                idx = -1
            if criterion == 'AICc':
                idx = -2
            if criterion == 'Cp':
                idx = -3

            VERBOSE("Doing l1 trend filtering using optimal criterion %s" % criterion)
            VERBOSE('North component')
            ngts.data[:, 1] = best_l1trend(x, gts.data[:, 1] * 1.E3, idx)[0] * 1.E-3
            VERBOSE('East  component')
            ngts.data[:, 2] = best_l1trend(x, gts.data[:, 2] * 1.E3, idx)[0] * 1.E-3
            VERBOSE('Up    component')
            ngts.data[:, 3] = best_l1trend(x, gts.data[:, 3] * 1.E3, idx)[0] * 1.E-3

        if isinstance(alpha, str) and criterion == 'MIX':
            VERBOSE("Doing l1 trend filtering using optimal criterion %s" % criterion)
            VERBOSE('North component')
            idx = -1
            y, H_alpha, alpha_ref_bic = best_l1trend(x, gts.data[:, 1] * 1.E3, idx)
            idx = -2
            y, H_alpha, alpha_ref_aicc = best_l1trend(x, gts.data[:, 1] * 1.E3, idx)
            alpha = np.float_power(10, (alpha_ref_bic + alpha_ref_aicc) / 2)
            ngts.data[:, 1] = trend_filter(x, gts.data[:, 1] * 1.E3, l_norm=1, alpha_2=alpha)['y_fit'] * 1.E-3
            VERBOSE('East  component')
            idx = -1
            y, H_alpha, alpha_ref_bic = best_l1trend(x, gts.data[:, 2] * 1.E3, idx)
            idx = -2
            y, H_alpha, alpha_ref_aicc = best_l1trend(x, gts.data[:, 2] * 1.E3, idx)
            alpha = np.float_power(10, (alpha_ref_bic + alpha_ref_aicc) / 2)
            ngts.data[:, 2] = trend_filter(x, gts.data[:, 2] * 1.E3, l_norm=1, alpha_2=alpha)['y_fit'] * 1.E-3

            VERBOSE('Up    component')
            idx = -1
            y, H_alpha, alpha_ref_bic = best_l1trend(x, gts.data[:, 3] * 1.E3, idx)
            idx = -2
            y, H_alpha, alpha_ref_aicc = best_l1trend(x, gts.data[:, 3] * 1.E3, idx)
            alpha = np.float_power(10, (alpha_ref_bic + alpha_ref_aicc) / 2)
            ngts.data[:, 3] = trend_filter(x, gts.data[:, 3] * 1.E3, l_norm=1, alpha_2=alpha)['y_fit'] * 1.E-3

        #        if PLOT:
        #            import matplotlib.pyplot as plt
        #            plt.plot(x, y, 'bo', markersize=2.)
        #            plt.plot(x, fy, label=("%.3lf - %.1lf - %.1lf" % (alpha, cchi2, cchi2_probability)))

        # return
        return ngts

    except:
        ERROR("Something went wrong running l1trend on Gts %s" % self.code)
        return None

# OLD IMPLEMENTATION UNTIL PYACS 0.65.83
# def l1trend(self, alpha='auto',ndays_mf=1,criterion='BIC'):
#         """
#         Performs l1 trend filter. For each component, optimal filter parameter is searched using BIC criterion
#         Uses https://pypi.org/project/trendfilter/
#
#         :param ndays_mf: parameter for a median filter to be applied prior to l1-trend filtering
#         :param criterion: criterion to select optimal l1-trend filtering. 'BIC' (default), 'AICc' or 'MIX'
#
#         :return: new Gts instance
#         """
#
#         from trendfilter import trend_filter
#         import numpy as np
#
#         import logging
#         import pyacs.message.message as MESSAGE
#         import pyacs.message.verbose_message as VERBOSE
#         import pyacs.message.error as ERROR
#         import pyacs.message.warning as WARNING
#         import pyacs.message.debug_message as DEBUG
#         import pyacs.debug
#
#         from scipy.stats import chi2
#
#         if criterion == 'BIC':
#             idx = -1
#         if criterion == 'AICc':
#             idx = -2
#         if criterion not in ['BIC','AICc','MIX']:
#             ERROR("keyword criterion must be either BIC or AICc",exit=True)
#
#         # median filter if user required
#         x = self.data[:, 0]
#         if ndays_mf > 1:
#             gts = self.median_filter(ndays_mf)
#         else:
#             gts = self.copy()
#
#         # MIX case
#         if criterion == 'MIX':
#             # compute BIC & AIC
#             gts_bic = gts.l1trend(criterion='BIC')
#             gts_aicc = gts.l1trend(criterion='AICc')
#             # mix BIC & AICc
#             vgts_bic = gts_bic.ivel()
#             vgts_aicc = gts_aicc.ivel()
#             # instanciate new gts
#             # new gts
#             ngts = gts.copy()
#             for idx_component in np.arange(1,4):
#                 data = vgts_aicc.data[:,idx_component]
#                 median_vel = np.median(np.fabs( data ))
#                 # use 3 times the median to switch weight between BIC & AICc
#                 np_alpha = 1 - np.exp(- np.fabs( data ) ** 2 / (3*median_vel) ** 2)
#                 vv = np_alpha * data + (1 - np_alpha) * vgts_bic.data[:,idx_component]
#                 vv = vv - np.mean(vv)
#                 # integrate to get the mix time series
#                 dv = np.zeros((ngts.data.shape[0]))
#                 dt = np.diff(ngts.data[:,0])
#                 dv[1:] = np.cumsum( vv*dt )
#                 # fill ngts
#                 ngts.data[:,idx_component] = dv
#             # correct for trend and return
#             velocity = -vgts_bic.detrend().velocity
#
#             return ngts.detrend().remove_velocity(velocity)
#
#         # subroutine for optimal filtering parameter search
#         def f(x, y):
#
#             from scipy.stats import chi2
#
#             def get_stats_l1_model(y, fy, alpha):
#                 n = y.shape[0]
#                 cchi2 = np.sum((fy - y) ** 2)
#                 dy = np.diff(fy) / (np.diff(x))
#                 cp = np.where(np.fabs(np.diff(dy)) > 0.001)[0].shape[0]
#                 AIC = n * np.log(cchi2 / n) + 2 * cp
#                 AICc = n * np.log(cchi2 / n) + 2 * cp + 2 * cp * (cp + 1) / (n - cp - 1)
#                 BIC = n * np.log(cchi2 / n) + np.log(n) * cp
#                 cdof = x.shape[0] - cp
#                 cchi2_probability = chi2.cdf(cchi2, cdof) * 100.
#                 VERBOSE("alpha: %f chi2 : %f fit %.2lf n_param %d chi2_proba: %.2lf AIC: %.2lf BIC: %.2lf " % (
#                 alpha, cchi2, np.sqrt(cchi2 / x.shape[0]), cp, cchi2_probability, AIC, BIC))
#                 if pyacs.debug():
#                     import matplotlib.pyplot as plt
#                     plt.plot(x, y, 'bo', markersize=2.)
#                     plt.plot(x, fy, label=("%.3lf - %.1lf - %.1lf" % (alpha, cchi2, cchi2_probability)))
#                 return alpha, cchi2, np.sqrt(cchi2 / x.shape[0]), cp, cchi2_probability, AICc, BIC
#
#             # search for order of magnitude
#             alpha_ref = 1.
#             alpha = 1.
#             fy = trend_filter(x, y, l_norm=1, alpha_2=alpha_ref)['y_fit']
#             BIC_REF = get_stats_l1_model(y, fy, alpha_ref)[idx]
#             GO = True
#             delta = 10
#             while GO:
#                 alpha = alpha * delta
#                 fy = trend_filter(x, y, l_norm=1, alpha_2=alpha)['y_fit']
#                 BIC = get_stats_l1_model(y, fy, alpha)[idx]
#                 if BIC > BIC_REF:
#                     GO = False
#                 else:
#                     BIC_REF = BIC
#                     alpha_ref = alpha
#             VERBOSE("alpha_ref: %f BIC_REF: %f" % (alpha_ref, BIC_REF))
#             GO = True
#             delta = 0.1
#             alpha = alpha_ref
#             while GO:
#                 alpha = alpha * delta
#                 fy = trend_filter(x, y, l_norm=1, alpha_2=alpha)['y_fit']
#                 BIC = get_stats_l1_model(y, fy, alpha)[idx]
#                 if BIC > BIC_REF:
#                     GO = False
#                 else:
#                     BIC_REF = BIC
#                     alpha_ref = alpha
#             VERBOSE("alpha_ref: %f BIC_REF: %f" % (alpha_ref, BIC_REF))
#
#             # search
#             GO = True
#             delta = 1.5
#             alpha = alpha_ref
#             while GO:
#                 alpha = alpha * delta
#                 fy = trend_filter(x, y, l_norm=1, alpha_2=alpha)['y_fit']
#                 BIC = get_stats_l1_model(y, fy, alpha)[idx]
#                 if BIC > BIC_REF:
#                     GO = False
#                 else:
#                     BIC_REF = BIC
#                     alpha_ref = alpha
#             VERBOSE("alpha_ref: %f BIC_REF: %f" % (alpha_ref, BIC_REF))
#             GO = True
#             delta = 1. / 1.5
#             alpha = alpha_ref
#             while GO:
#                 alpha = alpha * delta
#                 fy = trend_filter(x, y, l_norm=1, alpha_2=alpha)['y_fit']
#                 BIC = get_stats_l1_model(y, fy, alpha)[idx]
#                 if BIC > BIC_REF:
#                     GO = False
#                 else:
#                     BIC_REF = BIC
#                     alpha_ref = alpha
#             VERBOSE("alpha_ref: %f BIC_REF: %f" % (alpha_ref, BIC_REF))
#
#             return trend_filter(x, y, l_norm=1, alpha_2=alpha_ref)['y_fit']
#
#         # new gts
#         ngts = gts.copy()
#         if isinstance(alpha,float):
#             VERBOSE("Doing l1 trend filtering using alpha %f" % alpha)
#             VERBOSE('North component')
#             ngts.data[:, 1] = trend_filter(x, gts.data[:, 1] * 1.E3,l_norm=1, alpha_2=alpha)['y_fit'] * 1.E-3
#             VERBOSE('East  component')
#             ngts.data[:, 2] = trend_filter(x, gts.data[:, 2] * 1.E3,l_norm=1, alpha_2=alpha)['y_fit'] * 1.E-3
#             VERBOSE('Up    component')
#             ngts.data[:, 3] = trend_filter(x, gts.data[:, 3] * 1.E3,l_norm=1, alpha_2=alpha)['y_fit'] * 1.E-3
#
#         else:
#             VERBOSE("Doing l1 trend filtering using optimal BIC criterion")
#             VERBOSE('North component')
#             ngts.data[:, 1] = f(x, gts.data[:, 1] * 1.E3) * 1.E-3
#             VERBOSE('East  component')
#             ngts.data[:, 2] = f(x, gts.data[:, 2] * 1.E3) * 1.E-3
#             VERBOSE('Up    component')
#             ngts.data[:, 3] = f(x, gts.data[:, 3] * 1.E3) * 1.E-3
#
#         # return
#         return ngts