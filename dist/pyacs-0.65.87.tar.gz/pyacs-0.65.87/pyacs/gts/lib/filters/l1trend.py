# function to get statistics
####################################################################################################################

def get_stats_l1_model(x, y, fy, alpha):
    """

    :param x: input time as 1D array
    :param y: input raw data as 1D array
    :param fy: input l1trend filtered data as 1D array
    :param alpha: hyperparameter used for l1 filtering
    :return: alpha, cchi2, sigma, cp, cchi2_probability, Cp, AICc, BIC
    """
    from scipy.stats import chi2
    import numpy as np

    n = y.shape[0]
    cchi2 = np.sum((fy - y) ** 2 / (1.5 * np.median(np.fabs(np.diff(y)))) ** 2)
    dy = np.diff(fy) / (np.diff(x))
    cp = np.where(np.fabs(np.diff(dy)) > 0.1)[0].shape[0]
    AIC = n * np.log(cchi2 / n) + 2 * cp
    AICc = n * np.log(cchi2 / n) + 2 * cp + 2 * cp * (cp + 1) / (n - cp - 1)
    BIC = n * np.log(cchi2 / n) + np.log(n) * cp
    cdof = x.shape[0] - cp
    cchi2_probability = chi2.cdf(cchi2, cdof) * 100.
    Cp = cchi2 + cp + 2
    # VERBOSE("alpha: %f chi2 : %f fit %.2lf n_param %d chi2_proba: %.2lf Cp: %.2lf AIC: %.2lf BIC: %.2lf " % (
    # alpha, cchi2, np.sqrt(cchi2 / x.shape[0]), cp, cchi2_probability, Cp, AIC, BIC))
    return alpha, cchi2, np.sqrt(cchi2 / x.shape[0]), cp, cchi2_probability, Cp, AICc, BIC

# function to pre-process time series before applying l1trend
####################################################################################################################

def pre_process_ts(self, threshold=5000.):
    """
    Pre-process a time series to avoid convergence problems in l1trend.
    It performs change point detection analysis, correct for unrealistically large velocity
    and return a cleaned time series
    """

    # import
    import numpy as np

    import logging
    import pyacs.message.message as MESSAGE
    import pyacs.message.verbose_message as VERBOSE
    import pyacs.message.error as ERROR
    import pyacs.message.warning as WARNING
    import pyacs.message.debug_message as DEBUG
    import pyacs.debug

    VERBOSE("Running pre_process_ts on Gts %s with threshold %.1lf" % (self.code, threshold))

    # detrend
    dts = self.detrend_median()
    # working time series
    nts = dts.copy()
    its = dts.median_filter(5)
    # compute ivel
    ivel = its.ivel()
    # set all reasonable ivel to zero
    for i in [1, 2, 3]:
        lidx = np.where(np.fabs(ivel.data[:, i]) < threshold * 1.E-3)[0]
        ivel.data[lidx, i] = 0.
        its.data[:, i] = np.append(0, np.cumsum(ivel.data[:, i] * np.diff(its.data[:, 0])))
        nts.data[:, i] = dts.data[:, i] - its.data[:, i]
    # remove obvious outliers
    ots = nts.find_outliers_simple()
    its.outliers = ots.outliers
    # return
    return ots.remove_outliers(), its.remove_outliers()

###############################################################################
def l1trend(self,
            alpha='auto',
            ndays_mf=1,
            criterion='BIC',
            lcomponent='ENU',
            algo='golden',
            pre_process=0,
            bounds=[-2, 1],
            tol=0.01):

    """
    Performs l1 trend filter. For each component, optimal filter parameter is searched using BIC criterion
    Uses https://pypi.org/project/trendfilter/

    :param alpha: either hyperparameter as float or 'auto' to find optimal filtering using criterion
    :param ndays_mf: parameter for a median filter to be applied prior to l1-trend filtering
    :param criterion: criterion to select automatic optimal l1-trend filtering. 'BIC' (default), 'AICc', 'Cp'
    :param lcomponent: list of components to be filtered. Other components will remain unchanged
    :param algo: algorithm to find optimal alpha. 'golden' (default) or 'custom'
    :param pre_process: pre-process time series to avoid convergence problems in l1trend. It corrects for unrealistically large
                        velocity using the threshold provided (mm/yr). Correction is then added again after l1_trend.
                        Default is 0 (no pre-processing)
    :param bounds: bounds for golden section search algorithm. Default is [-2, 1]
    :param tol: tolerance for golden section search algorithm. Default is 0.01

    :return: l1-trend filtered time series as new Gts instance
    """

    # imports
    ###########################################################################

    from trendfilter import trend_filter
    import numpy as np

    from icecream import ic
    ic.lineWrapWidth = 200
    import logging
    import pyacs.message.message as MESSAGE
    import pyacs.message.verbose_message as VERBOSE
    import pyacs.message.error as ERROR
    import pyacs.message.warning as WARNING
    import pyacs.message.debug_message as DEBUG
    import pyacs.debug

    # set icecream
    ###########################################################################
    if pyacs.debug():
        ic.enable()
    else:
        ic.disable()

    # check criterion
    ###########################################################################
    if criterion not in ['BIC', 'AICc', 'Cp']:
        ERROR("keyword criterion must be either BIC, Cp, AICc", exit=True)

    # component index and full/short name
    ###########################################################################
    H_component_full_name={}
    H_component_full_name[1]='North'
    H_component_full_name[2]='East'
    H_component_full_name[3]='Up'

    H_component_short_name={}
    H_component_short_name[1]='N'
    H_component_short_name[2]='E'
    H_component_short_name[3]='U'


    # working gts
    ###########################################################################
    gts = self.copy()

    # median filter if user required
    ###########################################################################
    if ndays_mf > 1:
        gts = self.median_filter(ndays_mf)

    # pre-process time series if user required
    ###########################################################################
    if pre_process > 0:
        gts, its = pre_process_ts(gts, threshold=pre_process)


    # original routine to find the optimal hyperparameter alpha in l1trend using BIC, AICc or Cp
    # prefered routine is now golden_section_search from pyacs >= 0.65.87
    ###########################################################################
    def best_l1trend_custom(x, y, criterion_idx):

        # import
        from icecream import ic
        from trendfilter import trend_filter
        from time import time

        # log execution time
        start_time = time()

        # H of results
        H_alpha = {}
        step = 1
        CONV = False
        GO = True
        maxiter = 40
        niter = 0
        alpha = 0

        # start with alpha = 0
        fy = trend_filter(x, y, l_norm=1, alpha_2=np.float_power(10, alpha))['y_fit']
        H_alpha[alpha] = get_stats_l1_model(x, y, fy, np.float_power(10, alpha))
        alpha_ref = alpha
        score_ref = H_alpha[alpha][criterion_idx]
        cpref = H_alpha[alpha][-5]
        fy_ref = fy
        ic(niter, alpha_ref, score_ref, cpref)

        # choose probable best start direction according to cp
        if cpref < 0.1 * fy.shape[0]:
            step = -1

        alpha = alpha + step

        # main loop
        while GO:
            niter = niter + 1
            fy = trend_filter(x, y, l_norm=1, alpha_2=np.float_power(10, alpha))['y_fit']
            H_alpha[alpha] = get_stats_l1_model(x, y, fy, np.float_power(10, alpha))
            score = H_alpha[alpha][criterion_idx]
            cp = H_alpha[alpha][-5]

            ic(niter,alpha,score,cp)

            if score < score_ref:
                if np.fabs(score - score_ref) < 0.01:
                    GO = False
                    VERBOSE('convergence reached: delta_score < tol')
                if cp == cpref:
                    GO = False
                    VERBOSE('convergence reached: number parameters is stable')
                alpha_ref = alpha
                score_ref = score
                cpref = cp
                fy_ref = fy
                # ic(niter,alpha_ref,score_ref,cpref)
            else:
                step = -step
                if alpha_ref + step in list(H_alpha.keys()):
                    step = step / 2

            alpha = alpha_ref + step

            # MAXITER
            if niter == maxiter:
                GO = False
                WARNING('convergence failed: maxiter reached')

        end_time = time()
        VERBOSE('execution time: %.2lf s' % (end_time - start_time))
        VERBOSE(("best_l1trend_custom (niter, alpha, cp, score, ndata): %03d %.3lf %05d %.2lf %d" %
                 (niter, alpha_ref, cpref, score_ref, x.shape[0])) )


        return fy_ref, H_alpha, alpha_ref


    # best_l1trend_golden, now prefered routine to find the optimal hyperparameter alpha in l1trend using BIC, AICc or Cp
    # This proves to be faster and more robust than best_l1trend_custom
    ####################################################################################################################

    def best_l1trend_golden(x, y, criterion_idx, bounds=[-2, 1], tol=0.01):
        """
        Find the optimal hyperparameter alpha in l1trend using BIC, AICc or Cp using golden section search algorithm
        :param x: input time
        :param y: input data
        :param criterion_idx: index of the criterion to be used. -1 for BIC, -2 for AICc, -3 for Cp
        :return: optimally l1trend filtered time series
        """
        # import
        ################################################################################################################

        from trendfilter import trend_filter
        from icecream import ic

        # convergence test
        ################################################################################################################
        def convergence_reached(score1, score2, score_ref, cp1, cp2, cpref):
            if np.fabs(score1 - score_ref) < 0.01 and np.fabs(score2 - score_ref) < 0.01:
                return True, 'convergence reached: delta_score < tol'
            if np.fabs(cp1-cp2) < 2 :
                return True, 'convergence reached: same number of parameters'
            if (cp1 == cpref) and (cp2 == cpref):
                return True, 'convergence reached: same number of parameters'
            return False, None


        # golden_section_search algorithm
        ################################################################################################################
        def golden_section_search(a, b, x, y, criterion_idx, maxiter=40, tol=1e-5):

            from time import time
            start_time = time()

            ic('a b ', a, b)

            a_start = a
            b_start = b

            # cost function
            ############################################################################################################
            def cost(alpha, x, y, criterion_idx):
                fy = trend_filter(x, y, l_norm=1, alpha_2=np.float_power(10, alpha))['y_fit']
                H_alpha = get_stats_l1_model(x, y, fy, np.float_power(10, alpha))
                score = H_alpha[criterion_idx]
                cp = H_alpha[-5]
                return score, cp, fy

            # initialization
            golden_ratio = (np.sqrt(5) - 1) / 2

            # check that l1trend algorithm converges at lower or upper bound
            # reduce bounds if necessary
            ic('check that l1trend algorithm converges at lower or upper bound')
            BOUND_OK = False
            while not BOUND_OK:

                try:
                    score_a, cpa, fa = cost(a, x, y, criterion_idx)
                    BOUND_OK = True
                except:
                    WARNING(("lower bound for hyperparameter golden section search in l1trend too low. Changing %.1lf -> %.1lf " % (a,a+.5)))
                    a = a + .5

                try:
                    score_b, cpb, fb = cost(b, x, y, criterion_idx)
                    BOUND_OK = True
                except:
                    WARNING(("upper bound for hyperparameter golden section search in l1trend too high. Changing %.1lf -> %.1lf " % (b,b-.5)))
                    b = b - .5
                if a >= b:
                    ERROR('a>b',exit=True)

            # check that minimum falls within bounds
            # extend bounds if necessary
            ic('check that minimum falls within bounds',a,b)
            BOUNDARY_OK = False
            while not BOUNDARY_OK:
                c = b - golden_ratio * (b - a)
                d = a + golden_ratio * (b - a)
                ic(a,b,c,d)
                score_c, cpc, fc = cost(c, x, y, criterion_idx)
                score_d, cpd, fd = cost(d, x, y, criterion_idx)

                best_idx = np.argmin( [score_a, score_c, score_d, score_b,] )
                if best_idx == 0:
                    #raise Exception('minimum found at lower bounds')
                    #return
                    a = a - 0.5
                    score_a, cpa, fa = cost(a, x, y, criterion_idx)
                if best_idx == 3:
                    #raise Exception('minimum found at upper bounds')
                    #return
                    b = b + 1
                    score_b, cpb, fb = cost(b, x, y, criterion_idx)

                if best_idx in [1,2]:
                    BOUNDARY_OK = True

            # main loop
            ic('main loop')
            niter=0
            score_ref = np.inf
            cp_ref = np.inf
            score_c = None
            score_d = None

            while niter < maxiter:

                niter = niter +1

                ic(niter,a,b,c,d)

                if score_c is None:
                    score_c, cpc, fc = cost(c,x, y, criterion_idx)
                if score_d is None:
                    score_d, cpd, fd = cost(d,x, y, criterion_idx)

                # test convergence reached
                END, message = convergence_reached(score_c,score_d,score_ref,cpc, cpd, cp_ref)
                if END:
                    best_of_c_d = np.argmin([score_c, score_d])
                    score_ref = [score_c, score_d][ best_of_c_d ]
                    cp_ref = np.array([cpc, cpd])[ best_of_c_d ]
                    alpha_ref = np.array([c, d])[ best_of_c_d ]
                    # check that the optimum is not at the boundary

                    if (np.fabs(c-a_start) < tol) :
                        WARNING( "optimum found at lower boundary. Re-running with modified boundaries" )
                        return golden_section_search(a_start-1, b, x, y, criterion_idx, maxiter=maxiter, tol=tol)
                    if (np.fabs(d - b_start) < tol):
                        WARNING( "optimum found at upper boundary. Re-running with modified boundaries" )
                        return golden_section_search(a, b_start+1, x, y, criterion_idx, maxiter=maxiter, tol=tol)

                    return [fc,fd][ best_of_c_d ]

                best_of_c_d = np.argmin([score_c, score_d])
                score_ref = [score_c, score_d][ best_of_c_d ]
                alpha_ref = [c,d][ best_of_c_d ]
                cp_ref = np.array([cpc,cpd])[ best_of_c_d ]


                if score_c < score_d:
                    ic('score_c < score_d')
                    b = d
                    # c will become d in next iteration
                    score_d = score_c
                    cpd = cpc
                    score_c = None
                    cpc = None
                else:
                    ic('else score_c < score_d')
                    a = c
                    # d will become c in next iteration
                    score_c = score_d
                    cpc = cpd
                    score_d = None
                    cpd = None

                c = b - golden_ratio * (b - a)
                d = a + golden_ratio * (b - a)

                DEBUG("new a,b,c,d: %.3lf %.3lf %.3lf %.3lf" % (a,b,c,d))
                ic('#iter golden ', niter, alpha_ref, cp_ref, score_ref)

            end_time = time()
            VERBOSE('execution time: %.2lf s' % (end_time - start_time))
            VERBOSE(("best_l1trend_custom (niter, alpha, cp, score, ndata): %03d %.3lf %05d %.2lf %d" %
                     (niter, alpha_ref, cp_ref, score_ref, x.shape[0])))

            WARNING("No convergence. maxiter %d reached" % maxiter)

            return [fc,fd][ best_of_c_d ]


        VERBOSE('running golden_section_search')

        # run golden section search
        try:
            fy = golden_section_search(bounds[0], bounds[1], x, y, criterion_idx, maxiter=40, tol=0.01)
        except:
            ERROR("Something went wrong running golden_section_search in l1trend on Gts %s" % self.code)
            raise Exception
            fy = np.nan
        return fy

    ####################################################################################################################
    # MAIN PART
    ####################################################################################################################

    #try:

    # new gts for output
    ngts = gts.copy()
    x = ngts.data[:, 0]

    ic(x.shape)
    ic(ngts.data.shape)

    # case user defined alpha
    if isinstance(alpha, float):
        VERBOSE("Doing l1 trend filtering using alpha %f" % alpha)
        for i in [1,2,3]:
            if H_component_short_name[i] in lcomponent:
                VERBOSE("%s component" % H_component_full_name[i])
                ngts.data[:, i] = trend_filter(x, gts.data[:, i] * 1.E3, l_norm=1, alpha_2=alpha)['y_fit'] * 1.E-3

    # automatic best alpha search using 'BIC', 'AICc' or 'Cp' criterion
    if isinstance(alpha, str) and criterion in ['BIC', 'AICc', 'Cp']:
        if criterion == 'BIC':
            idx = -1
        if criterion == 'AICc':
            idx = -2
        if criterion == 'Cp':
            idx = -3

        import time
        VERBOSE("Doing l1 trend filtering using optimal criterion %s and algo %s" % (criterion,algo))

        for i in [1,2,3]:
            if H_component_short_name[i] in lcomponent:
                VERBOSE("%s component" % H_component_full_name[i])
                try:
                    if algo == 'golden':
                        ic(algo)
                        ic(ngts.data.shape)
                        ngts.data[:, i] = best_l1trend_golden(x, gts.data[:, i] * 1.E3, idx, bounds=bounds, tol=tol) * 1.E-3
                    if algo == 'custom':
                        ngts.data[:, i] = best_l1trend_custom(x, gts.data[:, i] * 1.E3, idx)[0] * 1.E-3
                except:
                    WARNING("Something went wrong running l1trend on Gts %s" % self.code)
                    WARNING("Trying to split Gts %s using rupture" % self.code)
                    # split the time series
                    import ruptures as rpt
                    import pyacs.lib.astrotime as at
                    signal = gts.data[:, i] * 1.E3
                    model = "l1"  # "l2", "rbf"
                    algo_rpt = rpt.Dynp(model=model, min_size=1, jump=5).fit(signal)
                    idx_offset = algo_rpt.predict(n_bkps=1)[0]
                    date_offset_decyear = gts.data[idx_offset, 0]
                    date_offset_str = at.decyear2datetime(date_offset_decyear).isoformat()
                    WARNING("Splitting Gts %s at %.5lf = %s" % (self.code, date_offset_decyear, date_offset_str))
                    ngts1 = gts.copy()
                    ngts2 = gts.copy()
                    ngts1.data = gts.data[:idx_offset, :]
                    ngts2.data = gts.data[idx_offset:, :]

                    ngts1.plot()
                    ngts2.plot()

                    WARNING("Running l1trend  %s before %.5lf = %s" % (self.code, date_offset_decyear, date_offset_str))

                    lngts1 = ngts1.l1trend(alpha=alpha,ndays_mf=ndays_mf, criterion=criterion,
                                           lcomponent=lcomponent, algo=algo, pre_process=pre_process,
                                           bounds=bounds, tol=tol)
                    WARNING("Running l1trend  %s after %.5lf = %s" % (self.code, date_offset_decyear, date_offset_str))
                    lngts2 = ngts2.l1trend(alpha=alpha,ndays_mf=ndays_mf, criterion=criterion,
                                           lcomponent=lcomponent, algo=algo, pre_process=pre_process,
                                           bounds=bounds, tol=tol)

                    WARNING("Merging Gts %s" % self.code)
                    ngts.data = np.vstack((lngts1.data, lngts2.data))

        # pre_process case
        if pre_process > 0 and algo == 'golden':
            VERBOSE("Adding pre_processing correction")
            ngts.data[:, 1:4] = ngts.data[:, 1:4] + its.data[:, 1:4]


    # return
    return ngts

    #except:
    #    ERROR("Something went wrong running l1trend on Gts %s" % self.code)
    #    return None

