def gts_mp(self, method, *args, **kwargs):
    """
    Sgts.gts_mp is the parallelized version of Sgts.gts, using ipyparallel

    :param method: the Gts method to be applied to all time series (gts) of the current Sgts
    :param *args, **kwargs: arguments of method to be used when calling method
    :param ncpu: ncpu is an additional kwarg to define the number of CPU used. default is 4

    :return: the new Sgts including the gts processed by method
    """
    from pyacs.gts.Sgts import Sgts
    from tqdm import tqdm

    import logging
    import pyacs.message.message as MESSAGE
    import pyacs.message.verbose_message as VERBOSE
    import pyacs.message.error as ERROR
    import pyacs.message.warning as WARNING
    import pyacs.message.debug_message as DEBUG
    import pyacs.debug

    import ipyparallel as ipp
    from icecream import ic

    import inspect
    VERBOSE("Running Sgts.%s" % inspect.currentframe().f_code.co_name)

    sgts = self
    n = self.n()

    # get func

    import importlib
    import inspect
    import os

    try:
        func = getattr(self.__dict__[self.lcode()[0]], method)
    except:
        ERROR(("There is no Gts method called %s. Exit" % method), exit=True)

    # get func path
    ldir = []
    OK = False
    for cdir in inspect.getfile(func).split('/'):
        if OK:
            ldir.append(cdir)
        if cdir == 'gts':
            OK = True
    ldir.pop()

    str_4_import = 'pyacs.gts.' + '.'.join(ldir) + '.' + method
    mod = importlib.import_module(str_4_import)
    func = getattr(mod, method)

    arg = [args, kwargs]

    verbose = kwargs.get('verbose', False)
    ncpu = kwargs.get('ncpu', 4)

    if 'ncpu' in kwargs.keys():
        kwargs.pop('ncpu')

    MESSAGE("Will run %s method on %d Gts using %d CPU" % (method, sgts.n(), ncpu))

    def worker_wrapper(gts, arg):
        [args, kwargs] = arg
        return func(gts, *args, **kwargs)

    # request a cluster
    with ipp.Cluster(n=ncpu) as rc:
        # get a view on the cluster
        view = rc.load_balanced_view()
        # submit the tasks
        asyncresult = view.map_async(worker_wrapper, sgts.lGts(), [arg] * n)
        # wait interactively for results
        asyncresult.wait_interactive()
        # retrieve actual results
        result = asyncresult.get()
    # at this point, the cluster processes have been shutdown

    # get results
    new_ts = Sgts(read=False)
    for gts in result:
        if gts is not None:
            new_ts.append(gts)

    # print missing
    lgood_code = new_ts.lcode(force_4_digit=True)
    for code in sorted(sgts.lcode()):
        if code not in lgood_code:
            ERROR(("Problem while applying %s to %s. Skipped from output Sgts." % (method, code)))

    return (new_ts)
