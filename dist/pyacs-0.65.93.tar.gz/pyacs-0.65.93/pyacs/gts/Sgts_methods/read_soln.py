###################################################################
def read_soln(self,soln,verbose=True):
###################################################################
    """
    read a IGS soln file and add an offsets_dates for any P change in soln.
     
    :param soln: soln.snx IGS file
     
    :note: the method is in place
    """
    
    from pyacs.sol.discontinuity import Discontinuities
    import logging
    import pyacs.message.message as MESSAGE
    import pyacs.message.verbose_message as VERBOSE
    import pyacs.message.error as ERROR
    import pyacs.message.warning as WARNING
    import pyacs.message.debug_message as DEBUG



    import inspect

    VERBOSE("Running Sgts.%s" % inspect.currentframe().f_code.co_name)

    fsoln=Discontinuities()
    VERBOSE("Reading %s" % soln)
    fsoln.read_igs_discontinuity(soln)
    
    for gts in self.lGts():
        VERBOSE("Adding offsets for %s" % gts.code)
        if gts.code in fsoln.lsite_offsets_dates:
            gts.offsets_dates=fsoln.lsite_offsets_dates[gts.code]

    return()
