###################################################################
def sub(self,lexclude=[],linclude=None):
###################################################################
    """
    Returns a new Sgts instance excluding Gts with code in lexclude and keeping Gts with code in include
    
    :param lexclude: list of sites to be excluded
    :param linclude: list of sites to be included, excluding all others. Default None means linclude is ignored.
     
   """

    from pyacs.gts.Sgts import Sgts
    import logging
    import pyacs.message.message as MESSAGE
    import pyacs.message.verbose_message as VERBOSE
    import pyacs.message.error as ERROR
    import pyacs.message.warning as WARNING
    import pyacs.message.debug_message as DEBUG

    import inspect
    VERBOSE("Running Sgts.%s" % inspect.currentframe().f_code.co_name)

    if linclude is not None:
        sub_Sgts = Sgts(read=False)
        for code in linclude:
            if ( code not in lexclude) and ( self.has_ts( code ) ):
                sub_Sgts.append(self.__dict__[code].copy())
    else:
        sub_Sgts = self.copy()
        for code in lexclude:
            if self.has_ts( code ):
                sub_Sgts.delts(code)
     
    return( sub_Sgts )
