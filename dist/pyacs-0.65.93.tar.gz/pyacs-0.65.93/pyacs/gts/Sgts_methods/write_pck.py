###################################################################
def write_pck(self,outfile, verbose=True):
###################################################################
    """
    writes a Sgts object as a pck (pickle)
     
    :param outfile: output file name. If not provided, a pck extension will be added.
    :param verbose: verbose mode
     
    """
    # import
    import pickle
    import os


    import logging
    import pyacs.message.message as MESSAGE
    import pyacs.message.verbose_message as VERBOSE
    import pyacs.message.error as ERROR
    import pyacs.message.warning as WARNING
    import pyacs.message.debug_message as DEBUG

    import inspect

    VERBOSE("Running Sgts.%s" % inspect.currentframe().f_code.co_name)

    # add pck extension if not provided
     
    if outfile[-4:] != '.pck':
        outfile = outfile+'.pck'

    # create dir if it does not exist
    if os.path.dirname( outfile ) != '':
        os.makedirs( os.path.dirname( outfile ) , exist_ok=True )

    # write pickle
    ofile = open( outfile, 'wb')
    pickle.dump(self , ofile , pickle.DEFAULT_PROTOCOL)
    ofile.close()
