###############################################################################
def remove_outliers(self, periods=None, in_place=False):
###############################################################################
    """
    removes outliers provided in self.outliers
    return a new Gts without the outliers
    if in_place = True then self has the outliers removed as well (in _place)
    """

    # import
    import numpy as np
    import logging
    import pyacs.message.message as MESSAGE
    import pyacs.message.verbose_message as VERBOSE
    import pyacs.message.error as ERROR
    import pyacs.message.warning as WARNING
    import pyacs.message.debug_message as DEBUG

    if self.outliers:
        if periods == None:
            data = np.delete(self.data, self.outliers, axis=0)
            # added JMN 2024/05/15
            if self.data_xyz is not None:
                if self.data_xyz.shape[0] == self.data.shape[0]:
                    data_xyz = np.delete(self.data_xyz, self.outliers, axis=0)
                else:
                    WARNING(".data_xyz has not the same number of rows as .data. Setting to None")
                    data_xyz = None
            else:
                data_xyz = None
        else:
            lindex = self.lindex_in_periods(periods)
            ldelete = np.intersect1d(lindex, self.outliers)
            data = np.delete(self.data, ldelete, axis=0)
            # added JMN 2024/05/15
            if self.data_xyz is not None:
                if self.data_xyz.shape[0] == self.data.shape[0]:
                    data_xyz = np.delete(self.data_xyz, ldelete, axis=0)
                else:
                    WARNING(".data_xyz has not the same number of rows as .data. Setting to None")
                    data_xyz = None
            else:
                data_xyz = None

        if data.shape[0] == 0:
            ERROR("All data are outliers for site %s. Check your outlier detection threshold or remove time series." % ( self.code ))
            ERROR("Setting data as None")
            data = None
    else:
        data = np.copy(self.data)
        data_xyz = self.data_xyz

    new_Gts = self.copy()
    new_Gts.outliers = []
    new_Gts.data = data
    new_Gts.data_xyz = data_xyz

    if in_place:
        self.data = new_Gts.data.copy()
        del new_Gts
        self.outliers = []

        return (self)
    else:
        return (new_Gts)
