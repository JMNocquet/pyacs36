# function to get statistics
####################################################################################################################

def get_stats_l1_model(x, y, fy, alpha):
    """

    :param x: input time as 1D array
    :param y: input raw data as 1D array
    :param fy: input l1trend filtered data as 1D array
    :param alpha: hyperparameter used for l1 filtering
    :return: alpha, cchi2, sigma, bp, cchi2_probability, Cp, AICc, BIC
    """
    from scipy.stats import chi2
    import numpy as np
    import logging
    import pyacs.message.message as MESSAGE
    import pyacs.message.verbose_message as VERBOSE
    import pyacs.message.error as ERROR
    import pyacs.message.warning as WARNING
    import pyacs.message.debug_message as DEBUG
    import pyacs.debug

    # tolerance to detect velocity change
    #tol = .1 # mm/yr note JMN 10/08/2024: this seems to be too tight
    tol = 2. # mm/yr note JMN 10/08/2024: this seems to be too tight

    n = y.shape[0]
    sigma = 1.5 * np.median(np.fabs(np.diff(y)))
    cchi2 = np.sum( (fy - y)**2 / sigma**2 )

    # avoid division by zero
    #if np.sqrt(cchi2/n) < .5:
    #    c_cchi2 = n / 4
    #    WARNING("median of residuals gets too small. Set manually to .5. %.1lf %.1lf" % (cchi2, c_cchi2))
    #    cchi2 = c_cchi2

    dy = np.diff(fy) / (np.diff(x))
    # number of parameters = number of change points + 2 for start & end
    cp = np.where(np.fabs(np.diff(dy)) > tol )[0].shape[0] + 2
    AIC = n * np.log(cchi2 / n) + 2 * cp
    AICc = n * np.log(cchi2 / n) + 2 * cp + 2 * cp * (cp + 1) / (n - cp - 1)
    BIC = n * np.log(cchi2 / n) + np.log(n) * cp
    cdof = x.shape[0] - cp
    cchi2_probability = chi2.cdf(cchi2, cdof) * 100.
    Cp = cchi2 + cp
    VERBOSE("alpha: %10f log10_alpha: %6.2lf chi2 : %10.2f fit %8.2lf n_param %05d chi2_proba: %5.2lf Cp: %10.2lf AIC: %10.2lf BIC: %8.2lf " % (
     alpha, np.log10(alpha), cchi2, np.sqrt(cchi2 / x.shape[0]), cp, cchi2_probability, Cp, AIC, BIC))
    return alpha, cchi2, np.sqrt(cchi2 / x.shape[0]), cp, cchi2_probability, Cp, AICc, BIC

########################################################################################################################
def pre_process_test(gts, component, threshold=5000., logger=None):
    """
    Pre-process. Test whether a large offset is present in the time series.
    Find the largest offset exceeding threshold found in the time series.
    Returns the index in the time series immediately after the largest offset or a void list if no offset is found

    Parameters
    ----------
    gts : Gts
        Input time series
    component : str
        Component to test ('E', 'N', or 'U')
    threshold : float
        Threshold for offset detection
    logger : logging.Logger, optional
        Logger instance for logging messages

    Returns
    -------
    list
        List of indices where offsets are found
    """
    # import
    import numpy as np
    from icecream import ic
    import pyacs.lib.astrotime as at
    import pyacs.message.verbose_message as VERBOSE
    import pyacs.message.warning as WARNING
    import pyacs

    threshold_up = threshold * 5

    # set icecream
    if pyacs.debug():
        ic.enable()
    else:
        ic.disable()

    # Ensure threshold is float
    threshold = float(threshold)

    # get time period
    str_sdate = at.decyear2datetime(gts.data[0,0]).isoformat()[:10]
    str_edate = at.decyear2datetime(gts.data[-1,0]).isoformat()[:10]
    str_period = f"[{str_sdate} - {str_edate}]"

    mesg = f"Running pre_process_test on Gts {gts.code} {str_period} {component} with threshold {threshold:.1f}"
    VERBOSE(mesg)
    if logger:
        logger.info(mesg)

    # case only one value
    if gts.data.shape[0] == 1:
        mesg = f"In pre_process_test on Gts {gts.code} {str_period} {component}. Only one value found. No offset returned."
        if logger:
            logger.warning(mesg)
        else:
            WARNING(mesg)
        return []

    # case only two values
    if gts.data.shape[0] == 2:
        mesg = f"In pre_process_test on Gts {gts.code} {str_period} {component}. Only two values found."
        if logger:
            logger.warning(mesg)
        else:
            WARNING(mesg)
        
        ivel = gts.ivel()
        if 'E' in component or 'N' in component:
            if np.sqrt(ivel.data[0,1]**2 + ivel.data[0,2]**2) * 1.E3 > threshold:
                str_date_offset = f"{at.decyear2datetime(gts.data[idx, 0]).isoformat()[:19]}-{at.decyear2datetime(gts.data[idx+1, 0]).isoformat()[:19]}"
                mesg = f"In pre_process_test on Gts {gts.code} {str_period} {component}. Offset detected on horizontal component {str_date_offset}"
                if logger:
                    logger.warning(mesg)
                else:
                    WARNING(mesg)
                return [1]
        if 'U' in component:
            if np.fabs(ivel.data[0,3]) * 1.E3 > threshold_up:
                str_date_offset = f"{at.decyear2datetime(gts.data[idx, 0]).isoformat()[:19]}-{at.decyear2datetime(gts.data[idx+1, 0]).isoformat()[:19]}"
                mesg = f"In pre_process_test on Gts {gts.code} {str_period} {component}. Offset detected on up component {str_date_offset}"
                if logger:
                    logger.warning(mesg)
                else:
                    WARNING(mesg)
                return [1]
        return []

    # case 3 values
    if gts.data.shape[0] == 3:
        mesg = f"In pre_process_test on Gts {gts.code} {str_period} {component}. Only three values found."
        if logger:
            logger.warning(mesg)
        else:
            WARNING(mesg)
        ivel = gts.ivel()
        if 'E' in component or 'N' in component:
            idx = np.argmax(np.sqrt(ivel.data[:,1]**2 + ivel.data[:,2]**2))
            if np.sqrt(ivel.data[idx,1]**2 + ivel.data[idx,2]**2) * 1.E3 > threshold:
                str_date_offset = f"{at.decyear2datetime(gts.data[idx, 0]).isoformat()[:19]}-{at.decyear2datetime(gts.data[idx+1, 0]).isoformat()[:19]}"
                mesg = f"In pre_process_test on Gts {gts.code} {str_period} {component}. Offset detected on horizontal component {str_date_offset}"
                if logger:
                    logger.warning(mesg)
                else:
                    WARNING(mesg)
                return [idx+1]
            else:
                mesg = f"No offset found for Gts {gts.code} {str_period} {component} horizontal component"
                VERBOSE(mesg)
                if logger:
                    logger.info(mesg)
                return []
        if 'U' in component:
            idx = np.argmax(np.fabs(ivel.data[:,3]))
            if np.fabs(ivel.data[idx,3]) * 1.E3 > threshold_up:
                str_date_offset = f"{at.decyear2datetime(gts.data[idx, 0]).isoformat()[:19]}-{at.decyear2datetime(gts.data[idx+1, 0]).isoformat()[:19]}"
                mesg = f"In pre_process_test on Gts {gts.code} {str_period} {component}. Offset detected on up component {str_date_offset}"
                if logger:
                    logger.warning(mesg)
                else:
                    WARNING(mesg)
                return [idx+1]
            else:
                mesg = f"No offset found for Gts {gts.code} {str_period} {component} horizontal component"
                VERBOSE(mesg)
                if logger:
                    logger.info(mesg)
                return []
    # case 4-5 values
    if gts.data.shape[0] == 4 or gts.data.shape[0] == 5:
        mesg = f"In pre_process_test on Gts {gts.code} {str_period} {component}. Only four values found."
        if logger:
            logger.warning(mesg)
        else:
            WARNING(mesg)
        its = gts.median_filter(3)
        # compute ivel
        ivel = its.ivel()
        if 'E' in component or 'N' in component:
            norm_ivel = np.sqrt(ivel.data[:, 1] ** 2 + ivel.data[:, 2] ** 2) * 1.E3
            idx = np.argmax(norm_ivel)
            if norm_ivel[idx] > threshold:
                str_date_offset = f"{at.decyear2datetime(gts.data[idx, 0]).isoformat()[:19]}-{at.decyear2datetime(gts.data[idx+1, 0]).isoformat()[:19]}"
                mesg = f"Found offset on horizontal component at middle of {str_date_offset}"
                VERBOSE(mesg)
                if logger:
                    logger.info(mesg)
                return [idx+1]
            else:
                mesg = f"No offset found for Gts {gts.code} {str_period} {component} horizontal component"
                VERBOSE(mesg)
                if logger:
                    logger.info(mesg)
                return []
        if 'U' in component:
            norm_ivel = np.fabs(ivel.data[:, 3]) * 1.E3
            idx = np.argmax(norm_ivel)
            if norm_ivel[idx] > threshold_up:
                str_date_offset = f"{at.decyear2datetime(gts.data[idx, 0]).isoformat()[:19]}-{at.decyear2datetime(gts.data[idx+1, 0]).isoformat()[:19]}"
                mesg = f"Found offset on up component at middle of {str_date_offset}"
                VERBOSE(mesg)
                if logger:
                    logger.info(mesg)
                return [idx+1]
            else:
                mesg = f"No offset found for Gts {gts.code} {str_period} {component} up component"
                VERBOSE(mesg)
                if logger:
                    logger.info(mesg)
                return []
    # case >= 5 values
    if gts.data.shape[0] > 5:
        its3 = gts.median_filter(3)
        its5 = gts.median_filter(5)
        # compute ivel
        ivel3 = its3.ivel()
        ivel5 = its5.ivel()
        # compute the mean of the two ivels
        if 'E' in component or 'N' in component:
            mean_ivel = np.sqrt( ((ivel3.data[:, 1] + ivel5.data[:, 1]) / 2)**2 + ((ivel3.data[:, 2] + ivel5.data[:, 2]) / 2)**2) * 1.E3
            idx = np.argmax(mean_ivel)
            if mean_ivel[idx]**2 > threshold**2:
                str_date_offset = f"{at.decyear2datetime(gts.data[idx, 0]).isoformat()[:19]}-{at.decyear2datetime(gts.data[idx+1, 0]).isoformat()[:19]}"
                mesg = f"Found offset on horizontal component at middle of {str_date_offset}"
                VERBOSE(mesg)
                if logger:
                    logger.info(mesg)
                return [idx+1]
            else:
                mesg = f"No offset found for Gts {gts.code} {str_period} {component} horizontal component"
                VERBOSE(mesg)
                if logger:
                    logger.info(mesg)
                return []
        if 'U' in component:
            mean_ivel = (ivel3.data[:, 3] + ivel5.data[:, 3]) / 2 * 1.E3
            idx = np.argmax(mean_ivel**2)
            if mean_ivel[idx]**2 > threshold_up**2:
                str_date_offset = f"{at.decyear2datetime(gts.data[idx, 0]).isoformat()[:19]}-{at.decyear2datetime(gts.data[idx+1, 0]).isoformat()[:19]}"
                mesg = f"Found offset on up component at middle of {str_date_offset}"
                VERBOSE(mesg)
                if logger:
                    logger.info(mesg)
                return [idx+1]
            else:
                mesg = f"No offset found for Gts {gts.code} {str_period} {component} up component."
                VERBOSE(mesg)
                if logger:
                    logger.info(mesg)
                return []



########################################################################################################################
# function to pre-process time series before applying l1trend
####################################################################################################################

def pre_process_ts(self, threshold=5000.):
    """
    Pre-process a time series to avoid convergence problems in l1trend.
    It performs change point detection analysis, correct for unrealistically large velocity
    and return a cleaned time series
    """

    # import
    import numpy as np
    from icecream import ic
    import pyacs.lib.astrotime as at
    import logging
    import pyacs.message.message as MESSAGE
    import pyacs.message.verbose_message as VERBOSE
    import pyacs.message.error as ERROR
    import pyacs.message.warning as WARNING
    import pyacs.message.debug_message as DEBUG
    import pyacs.debug

    # set icecream
    ###########################################################################
    if pyacs.debug():
        ic.enable()
    else:
        ic.disable()


    VERBOSE("Running pre_process_ts on Gts %s with threshold %.1lf" % (self.code, threshold))

    # detrend
    dts = self.detrend_median()
    # working time series
    nts = dts.copy()
    its = dts.median_filter(5)
    # compute ivel
    ivel = its.ivel()
    # set all reasonable ivel to zero
    # horizontal components
    lidxe = np.where(np.fabs(ivel.data[:, 1]) > threshold * 1.E-3)[0]
    lidxn = np.where(np.fabs(ivel.data[:, 2]) > threshold * 1.E-3)[0]
    lidx = np.unique(np.sort(np.append(lidxe, lidxn)))
    VERBOSE("Found %d offsets in horizontal components" % lidx.shape[0])
    for i in lidx:
        VERBOSE("%s " % (at.decyear2datetime(its.data[i, 0]).isoformat()))
    lidxx = np.zeros(ivel.data.shape[0])
    lidxx[lidx] = 1
    ivel.data[:, 1] = ivel.data[:, 1] * lidxx
    ivel.data[:, 2] = ivel.data[:, 2] * lidxx

    # vertical component
    lidx = np.where(np.fabs(ivel.data[:, 2]) > threshold * 1.E-3)[0]
    VERBOSE("Found %d offsets in up component" % lidx.shape[0])
    for i in lidx:
        VERBOSE("%s " % (at.decyear2datetime(its.data[i, 0]).isoformat()))
    lidxx = np.zeros(ivel.data.shape[0])
    lidxx[lidx] = 1
    ivel.data[:, 3] = ivel.data[:, 3] * lidxx

    # compute its
    for i in [1, 2, 3]:
        its.data[:, i] = np.append(0, np.cumsum(ivel.data[:, i] * np.diff(its.data[:, 0])))
        nts.data[:, i] = dts.data[:, i] - its.data[:, i]
    # remove obvious outliers
    ots = nts.find_outliers_simple()
    its.outliers = ots.outliers
    # return
    return ots.remove_outliers(), its.remove_outliers()

###############################################################################
def l1trendi(self,
            alpha='auto',
            ndays_mf=1,
            criterion='BIC',
            lcomponent='ENU',
            algo='golden',
            pre_process=4000,
            bounds=[-2, 1],
            tol=0.01,
            refine=True,
            min_samples_per_segment=5,
            threshold_bias_res_detect=5,
            threshold_vel=3,
            min_sample_segment_refinement=1,
            norm='L2',
            verbose=False,
            log_dir=None):
    """
    Performs l1 trend filter on GPS time series. For each component, optimal filter parameter is searched using specified criterion.
    Uses https://pypi.org/project/trendfilter/

    Parameters
    ----------
    alpha : float or str
        Either hyperparameter as float or 'auto' to find optimal filtering using criterion
    ndays_mf : int
        Parameter for a median filter to be applied prior to l1-trend filtering
    criterion : str
        Criterion to select automatic optimal l1-trend filtering. Options: 'BIC' (default), 'AICc', 'Cp'
    lcomponent : str
        List of components to be filtered. Other components will remain unchanged
    algo : str
        Algorithm to find optimal alpha. Options: 'golden' (default) or 'custom'
    pre_process : float
        Pre-process time series to avoid convergence problems in l1trend. It corrects for unrealistically large
        velocity using the threshold provided (mm/yr). Correction is then added again after l1_trend.
        Default is 3600 (3.6 m/yr)
    bounds : list
        Bounds for golden section search algorithm. Default is [-2, 1]
    tol : float
        Tolerance for golden section search algorithm. Default is 0.01
    refine : bool
        If True, will run refinement after l1 trend filtering
    min_samples_per_segment : int
        Minimum number of samples per segment for refinement
    threshold_bias_res_detect : float
        Threshold for bias detection in refinement
    threshold_vel : float
        Threshold for velocity detection in refinement
    min_sample_segment_refinement : int
        Minimum number of samples per segment in refinement
    norm : str
        Norm to use for refinement. Options: 'L2' (default)
    verbose : bool
        Enable verbose output for debugging
    log_dir : str or None
        If provided, directory where the log file will be created. The log file will be named 'SITE_l1trendi.log'
        where SITE is the site code. If None, no file logging is performed.

    Returns
    -------
    Gts
        l1-trend filtered time series as new Gts instance

    Raises
    ------
    ValueError
        If invalid parameters are provided
    RuntimeError
        If processing fails
    """
    # Imports
    from trendfilter import trend_filter
    import numpy as np
    import pyacs.lib.astrotime as at
    from icecream import ic
    import logging
    import pyacs.message.message as MESSAGE
    import pyacs.message.verbose_message as VERBOSE
    import pyacs.message.error as ERROR
    import pyacs.message.warning as WARNING
    import pyacs.message.debug_message as DEBUG
    import pyacs.debug
    from time import time
    import os
    from datetime import datetime
    import shutil

    # function to get logger
    def get_logger(log_file):
        logger = logging.getLogger('pyacs.l1trendi')
        if not logger.hasHandlers():
            logger.setLevel(logging.INFO)
            file_handler = logging.FileHandler(log_file, mode='a')  # append mode
            file_handler.setLevel(logging.INFO)
            formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
            file_handler.setFormatter(formatter)
            logger.addHandler(file_handler)
        return logger

    # Setup logging
    if log_dir is not None:
        # Create log directory if it doesn't exist
        os.makedirs(log_dir, exist_ok=True)
        
        # Create log file path
        log_file = os.path.join(log_dir, f"{self.code}_l1trendi.log")

        # get logger
        logger = get_logger(log_file)

    else:
        logger = None



    # Log start of processing
    str_sdate = at.decyear2datetime(self.data[0,0]).isoformat()[:10]
    str_edate = at.decyear2datetime(self.data[-1,0]).isoformat()[:10]
    # Get time period string for logging
    str_period = f"[{str_sdate} - {str_edate}]"
    if log_dir is not None:
        logger.info(f"Starting l1trend processing for {self.code} {str_period} {lcomponent} {criterion} at {datetime.now().isoformat()}")
    VERBOSE(f"Starting l1trend processing for {self.code} {str_period} {lcomponent} {criterion} at {datetime.now().isoformat()}")

    # Setup debugging
    if pyacs.debug():
        ic.enable()
    else:
        ic.disable()

    # Validate input parameters
    if criterion not in ['BIC', 'AICc', 'Cp']:
        error_msg = f"Invalid criterion: {criterion}. Must be one of ['BIC', 'AICc', 'Cp']"
        if log_dir is not None:
            logger.error(error_msg)
        raise ValueError(error_msg)
    if algo not in ['golden', 'custom']:
        error_msg = f"Invalid algorithm: {algo}. Must be one of ['golden', 'custom']"
        if log_dir is not None:
            logger.error(error_msg)
        raise ValueError(error_msg)
    if not isinstance(ndays_mf, int) or ndays_mf < 1:
        error_msg = f"Invalid ndays_mf: {ndays_mf}. Must be a positive integer"
        if log_dir is not None:
            logger.error(error_msg)
        raise ValueError(error_msg)
    if not isinstance(pre_process, (int, float)) or pre_process <= 0:
        error_msg = f"Invalid pre_process: {pre_process}. Must be positive"
        if log_dir is not None:
            logger.error(error_msg)
        raise ValueError(error_msg)

    # Component mapping
    COMPONENT_MAP = {
        1: {'full': 'North', 'short': 'N'},
        2: {'full': 'East', 'short': 'E'},
        3: {'full': 'Up', 'short': 'U'}
    }

    # Criterion index mapping
    CRITERION_INDEX = {
        'BIC': -1,
        'AICc': -2,
        'Cp': -3
    }

    # Start timing
    start_time = time()

    try:
        # Create working copy
        gts = self.copy()
        
        # Apply median filter if requested
        if ndays_mf > 1:
            VERBOSE(f"Applying median filter with window size {ndays_mf}")
            if log_dir is not None:
                logger.info(f"Applying median filter with window size {ndays_mf}")
            gts = self.median_filter(ndays_mf)

        # Create output Gts
        ngts = gts.copy()
        #ngts.offsets_dates = []
        x = ngts.data[:, 0]

        # Validate data
        if ngts.data.shape[0] <= 2:
            warning_msg = f"Too few data points ({ngts.data.shape[0]}) in Gts {ngts.code}. Returning original Gts {str_period}"
            if log_dir is not None:
                logger.warning(warning_msg)
            else:
                WARNING(warning_msg)

            return ngts


        # Process each component
        for i in [1, 2, 3]:
            if COMPONENT_MAP[i]['short'] not in lcomponent:
                continue

            comp_name = COMPONENT_MAP[i]['full']
            VERBOSE(f"Processing {comp_name} component for {gts.code} {str_period}")
            if log_dir is not None:
                logger.info(f"Processing {comp_name} component for {gts.code} {str_period}")

            # Handle user-defined alpha
            if isinstance(alpha, float):
                VERBOSE(f"Using fixed alpha={alpha} for {comp_name} component")
                if log_dir is not None:
                    logger.info(f"Using fixed alpha={alpha} for {comp_name} component")
                ngts.data[:, i] = trend_filter(x, gts.data[:, i] * 1.E3, l_norm=1, alpha_2=alpha)['y_fit'] * 1.E-3
                continue

            # Automatic alpha search
            if alpha == 'auto':
                criterion_idx = CRITERION_INDEX[criterion]
                VERBOSE(f"Searching optimal alpha using {criterion} criterion for {comp_name} component")
                if log_dir is not None:
                    logger.info(f"Searching optimal alpha using {criterion} criterion for {comp_name} component")

                # Pre-process if requested
                if pre_process > 0:
                    VERBOSE(f"Optimal alpha: Running pre-process detection for large offsets in {comp_name} component")
                    if log_dir is not None:
                        logger.info(f"Optimal alpha: Running pre-process detection for large offsets in {comp_name} component")
                    lidx_offset = pre_process_test(gts, COMPONENT_MAP[i]['short'], threshold=pre_process, logger=logger)
                    
                    if len(lidx_offset) > 0:
                        # Handle time series split
                        idx_offset = lidx_offset[0]
                        date_offset = at.decyear2datetime(gts.data[idx_offset,0]).isoformat()[:19]
                        warning_msg = (f"Optimal alpha: Splitting Gts {self.code} {comp_name} component at {date_offset}")
                        if log_dir is not None:
                            logger.info(warning_msg)
                        else:
                            WARNING(warning_msg)

                        
                        # Process each segment
                        segments = [
                            (gts.data[:idx_offset, :], "before"),
                            (gts.data[idx_offset:, :], "after")
                        ]
                        
                        results = []
                        for segment_data, position in segments:
                            segment_gts = gts.copy()
                            segment_gts.data = segment_data
                            
                            result = segment_gts.l1trendi(
                                alpha=alpha, ndays_mf=ndays_mf, criterion=criterion,
                                lcomponent=COMPONENT_MAP[i]['short'], algo=algo,
                                pre_process=pre_process, bounds=bounds, tol=tol,
                                refine=False,
                                min_samples_per_segment=min_samples_per_segment,
                                threshold_bias_res_detect=threshold_bias_res_detect,
                                threshold_vel=threshold_vel,
                                min_sample_segment_refinement=min_sample_segment_refinement,
                                norm=norm,
                                log_dir=log_dir
                            )
                            results.append(result)
                        
                        # Merge results
                        ngts.data[:, i] = np.hstack((results[0].data[:, i], results[1].data[:, i]))
                        date_offset_dec_year = (ngts.data[idx_offset,0]+ngts.data[idx_offset-1,0])/2
                        date_offset_str = at.decyear2datetime(date_offset_dec_year).isoformat()[:19]
                        ngts.offsets_dates.append(date_offset_dec_year)
                        continue

                # Process without splitting
                idx_offset = []
                try:
                    if algo == 'golden':
                        ngts.data[:, i] = best_l1trend_golden(x, gts.data[:, i] * 1.E3, criterion_idx, bounds=bounds, tol=tol, logger=logger) * 1.E-3
                        VERBOSE(f"Optimal alpha: Successfully processed {comp_name} component with algo golden")
                        if log_dir is not None:
                            logger.info(f"Optimal alpha: Successfully processed {comp_name} component with algo golden")
                    else:
                        ngts.data[:, i] = best_l1trend_custom(x, gts.data[:, i] * 1.E3, criterion_idx, logger=logger)[0] * 1.E-3
                        VERBOSE(f"Optimal alpha: Successfully processed {comp_name} component with algo custom")
                        if log_dir is not None:
                            logger.info(f"Optimal alpha: Successfully processed {comp_name} component with algo custom")

                except Exception as e:
                    warning_msg = f"Failed in algo {algo} search to process {comp_name} component: {str(e)}"
                    if log_dir is not None:
                        logger.error(warning_msg)
                    ERROR(warning_msg, exit=True)
                    continue

        # print offsets_dates
        ngts.offsets_dates = sorted(set(ngts.offsets_dates))
        mesg = f"List of offsets detected for {ngts.code}"
        logger.info(mesg)
        for date_offset in ngts.offsets_dates:
            mesg = f"{date_offset:.5f} {at.decyear2datetime(date_offset).isoformat()[:19]}"
            if log_dir is not None:
                logger.info(mesg)
            VERBOSE(mesg)


        # Apply refinement if requested
        if refine:
            VERBOSE(f"Applying refinement for {ngts.code} {lcomponent} {str_period}")
            if log_dir is not None:
                logger.info(f"Applying refinement for {ngts.code} {lcomponent} {str_period}")
            ngts = ngts.refine_l1trend(
                self,
                min_samples_per_segment=min_samples_per_segment,
                threshold_bias_res_detect=threshold_bias_res_detect,
                threshold_vel=threshold_vel,
                min_sample_segment_refinement=min_sample_segment_refinement,
                norm=norm,
                lcomponent=lcomponent
            )


        # Log completion
        elapsed = time() - start_time
        VERBOSE(f"Completed l1trendi processing for {self.code} in {elapsed:.1f} seconds")
        if log_dir is not None:
            logger.info(f"Completed l1trendi processing for {self.code} in {elapsed:.1f} seconds")
            # Clean up logging
            for handler in logger.handlers[:]:
                handler.close()
                logger.removeHandler(handler)
        
        
        return ngts

    except Exception as e:
        error_msg = f"Failed to process Gts {self.code}: {str(e)}"
        if log_dir is not None:
            logger.error(error_msg)
            # Clean up logging
            for handler in logger.handlers[:]:
                handler.close()
                logger.removeHandler(handler)
        raise RuntimeError(f"l1trend processing failed: {str(e)}")
        ERROR(error_msg, exit=True)

def best_l1trend_golden(x, y, criterion_idx, bounds=[-2, 1], tol=0.01, logger=None):
    """
    Find the optimal hyperparameter alpha in l1trend using golden section search algorithm.
    
    Parameters
    ----------
    x : numpy.ndarray
        Input time array
    y : numpy.ndarray
        Input data array
    criterion_idx : int
        Index of the criterion to use (-1 for BIC, -2 for AICc, -3 for Cp)
    bounds : list
        Bounds for the search [lower, upper]
    tol : float
        Tolerance for convergence
    logger : logging.Logger, optional
        Logger instance for logging messages
        
    Returns
    -------
    numpy.ndarray
        Optimally filtered data
    """
    from trendfilter import trend_filter
    from time import time
    import numpy as np
    import pyacs.message.verbose_message as VERBOSE
    import pyacs.message.warning as WARNING
    from icecream import ic

    # Start timing
    start_time = time()
    msg = f"Starting golden section search optimization ({y.shape[0]} epochs)"
    VERBOSE(msg)
    if logger:
        logger.info(msg)

    # if y.shape[0] <=5, return the best fitting line
    if y.shape[0] <= 5:
        # Compute best fitting line using least squares
        coeffs = np.polyfit(x, y, 1)  # 1st degree polynomial (line)
        fy = coeffs[0] * x + coeffs[1]  # y = mx + b
        mesg = (f"Less than 5 epochs in best_l1trend_golden. Using best fitting line.")
        if logger:
            logger.warning(mesg)
        else:
            WARNING(mesg)
        return fy


    def convergence_reached(score1, score2, score_ref, cp1, cp2, cpref, ny):
        """Check if convergence criteria are met."""
        if np.fabs(score1 - score_ref) < 0.01 and np.fabs(score2 - score_ref) < 0.01:
            return True, 'Convergence reached: delta_score < tol'
        if np.fabs(cp1-cp2) < 2:
            return True, 'Convergence reached: same number of parameters'
        if (cp1 == cpref) and (cp2 == cpref):
            return True, 'Convergence reached: same number of parameters'
        if (cp1 >= ny) and (cp2 >= ny):
            return True, 'Stop: too many breakpoints'
        return False, None

    def cost(alpha, x, y, criterion_idx):
        """Compute cost function for given alpha."""
        try:
            fy = trend_filter(x, y, l_norm=1, alpha_2=np.float_power(10, alpha))['y_fit']
            H_alpha = get_stats_l1_model(x, y, fy, np.float_power(10, alpha))
            return H_alpha[criterion_idx], H_alpha[-5], fy
        except Exception as e:
            warning_msg = f"Error in cost function for alpha={alpha}: {str(e)}"

            if logger:
                logger.warning(warning_msg)
            else:
                WARNING(warning_msg)

            return np.inf, 0, np.zeros_like(y)

    def golden_section_search(a, b, x, y, criterion_idx, maxiter=40, tol=1e-5):
        """Perform golden section search optimization."""
        ny = y.shape[0]
        golden_ratio = (np.sqrt(5) - 1) / 2
        a_start, b_start = a, b

        # Validate bounds
        try:
            score_a, cpa, fa = cost(a, x, y, criterion_idx)
            score_b, cpb, fb = cost(b, x, y, criterion_idx)
        except Exception as e:
            warning_msg = f"Failed to validate bounds: {str(e)}"
            WARNING(warning_msg)
            if logger:
                logger.warning(warning_msg)
            return np.zeros_like(y)

        # Main optimization loop
        niter = 0
        while niter < maxiter:
            niter += 1
            c = b - golden_ratio * (b - a)
            d = a + golden_ratio * (b - a)

            try:
                score_c, cpc, fc = cost(c, x, y, criterion_idx)
                score_d, cpd, fd = cost(d, x, y, criterion_idx)

                # Check convergence
                END, message = convergence_reached(score_c, score_d, min(score_c, score_d), cpc, cpd, min(cpc, cpd), ny)
                if END:
                    VERBOSE(message)
                    if logger:
                        logger.info(message)
                    best_idx = np.argmin([score_c, score_d])
                    return [fc, fd][best_idx]

                # Update search interval
                if score_c < score_d:
                    b = d
                    score_d = score_c
                    cpd = cpc
                else:
                    a = c
                    score_c = score_d
                    cpc = cpd

            except Exception as e:
                warning_msg = f"Error in iteration {niter}: {str(e)}"
                WARNING(warning_msg)
                if logger:
                    logger.warning(warning_msg)
                break

        warning_msg = f"No convergence after {maxiter} iterations"
        WARNING(warning_msg)
        if logger:
            logger.warning(warning_msg)
        return fc if score_c < score_d else fd

    try:
        # Run golden section search
        result = golden_section_search(bounds[0], bounds[1], x, y, criterion_idx, maxiter=40, tol=tol)
        
        # Log completion
        elapsed = time() - start_time
        VERBOSE(f"Golden section search completed in {elapsed:.2f} seconds")
        if logger:
            logger.info(f"Golden section search completed in {elapsed:.2f} seconds")
        
        return result

    except Exception as e:
        warning_msg = f"Golden section search failed: {str(e)}"
        WARNING(warning_msg)
        if logger:
            logger.warning(warning_msg)
        return np.zeros_like(y)

def best_l1trend_custom(x, y, criterion_idx, logger=None):
    """
    Find the optimal hyperparameter alpha in l1trend using a custom search algorithm.
    
    Parameters
    ----------
    x : numpy.ndarray
        Input time array
    y : numpy.ndarray
        Input data array
    criterion_idx : int
        Index of the criterion to use (-1 for BIC, -2 for AICc, -3 for Cp)
    logger : logging.Logger, optional
        Logger instance for logging messages
        
    Returns
    -------
    tuple
        (optimal filtered data, history dictionary, optimal alpha)
    """
    from trendfilter import trend_filter
    from time import time
    import numpy as np
    import pyacs.message.verbose_message as VERBOSE
    import pyacs.message.warning as WARNING
    from icecream import ic

    # Start timing
    start_time = time()
    VERBOSE("Starting custom l1trend optimization")
    if logger:
        logger.info("Starting custom l1trend optimization")

    # Initialize variables
    H_alpha = {}
    step = 1
    maxiter = 40
    niter = 0
    alpha = 0

    try:
        # Start with alpha = 0
        fy = trend_filter(x, y, l_norm=1, alpha_2=np.float_power(10, alpha))['y_fit']
        H_alpha[alpha] = get_stats_l1_model(x, y, fy, np.float_power(10, alpha))
        alpha_ref = alpha
        score_ref = H_alpha[alpha][criterion_idx]
        cpref = H_alpha[alpha][-5]
        fy_ref = fy

        # Choose initial search direction based on number of change points
        if cpref < 0.1 * fy.shape[0]:
            step = -1

        alpha = alpha + step

        # Main optimization loop
        while niter < maxiter:
            niter += 1
            try:
                fy = trend_filter(x, y, l_norm=1, alpha_2=np.float_power(10, alpha))['y_fit']
                H_alpha[alpha] = get_stats_l1_model(x, y, fy, np.float_power(10, alpha))
                score = H_alpha[alpha][criterion_idx]
                cp = H_alpha[alpha][-5]

                if score < score_ref:
                    if np.fabs(score - score_ref) < 0.01:
                        VERBOSE('Convergence reached: delta_score < tol')
                        if logger:
                            logger.info('Convergence reached: delta_score < tol')
                        break
                    if cp == cpref:
                        VERBOSE('Convergence reached: number of parameters is stable')
                        if logger:
                            logger.info('Convergence reached: number of parameters is stable')
                        break
                    alpha_ref = alpha
                    score_ref = score
                    cpref = cp
                    fy_ref = fy
                else:
                    step = -step
                    if alpha_ref + step in H_alpha:
                        step = step / 2

                alpha = alpha_ref + step

            except Exception as e:
                warning_msg = f"Error in iteration {niter}: {str(e)}"
                WARNING(warning_msg)
                if logger:
                    logger.warning(warning_msg)
                break

        # Log results
        elapsed = time() - start_time
        VERBOSE(f"Custom optimization completed in {elapsed:.2f} seconds")
        VERBOSE(f"Results: niter={niter}, alpha={alpha_ref:.3f}, cp={cpref}, score={score_ref:.2f}, ndata={x.shape[0]}")
        if logger:
            logger.info(f"Custom optimization completed in {elapsed:.2f} seconds")
            logger.info(f"Results: niter={niter}, alpha={alpha_ref:.3f}, cp={cpref}, score={score_ref:.2f}, ndata={x.shape[0]}")

        return fy_ref, H_alpha, alpha_ref

    except Exception as e:
        warning_msg = f"Custom optimization failed: {str(e)}"
        WARNING(warning_msg)
        if logger:
            logger.warning(warning_msg)
        return np.zeros_like(y), {}, 0

