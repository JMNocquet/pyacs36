#############################################################################################################################
def check_l1_trend(ts, l1ts, component='EN', min_samples_per_segment=6, threshold_bias_res_detect=40, threshold_vel=8):
#############################################################################################################################
    """
    inspect the result from l1trend model of a time series.
    Returns a list periods ([sdate,edate]) where bad modelling is suspected.

    :param ts: raw time series
    :param l1ts: l1trend time series
    :param component: components to be analyzed. Default: 'EN'
    :param min_samples_per_segment: minimum number of samples for a segment to inspected (default: 6)
    :param threshold_bias_res_detect: threshold to detect bias residuals (default: 40)
    :param threshold_vel: instantaneous velocity threshold for a segment to be considered in detection (default: 8 mm/yr)

    :return
    """

    # import
    import numpy as np

    import logging
    import pyacs.message.message as MESSAGE
    import pyacs.message.verbose_message as VERBOSE
    import pyacs.message.error as ERROR
    import pyacs.message.warning as WARNING
    import pyacs.message.debug_message as DEBUG
    import pyacs.debug

    # initialize
    H_period = {}
    H_cp_pb = {}
    H_cp = {}

    VERBOSE("Searching suspicious periods for %s" % (l1ts.code))

    # measure bias
    ####################################################################################################################
    def measure_bias(t, y):
        """
        provides a measure of potentiel bias in a residual time series (0-100)
        """

        import numpy as np

        nsample = y.shape[0]
        mid_date = (t[-1] + t[0]) / 2

        lidx_1 = np.where(t < mid_date)[0]
        lidx_2 = np.where(t > mid_date)[0]

        n_positif1 = np.where(y[lidx_1] >= 0)[0].shape[0]
        n_negatif2 = np.where(y[lidx_2] <= 0)[0].shape[0]

        n_negatif1 = lidx_1.shape[0] - n_positif1
        n_positif2 = lidx_2.shape[0] - n_negatif2

        res = np.max([np.fabs(((n_positif1 + n_negatif2) / nsample * 100.) - 50.) * 2,
                      np.fabs(((n_negatif1 + n_positif2) / nsample * 100.) - 50.) * 2])

        resv = np.median(np.fabs(y))

        return res, resv

    # find nodes of piecewice linear function
    #def make_node_ts(x, y, threshold=2.):
    def make_node_ts(x, y, threshold=.5): # note JMN 10/08/2025: .5 seems to be too tight ans results in too many breakpoints
        """
        Assuming that y is piecewise linear, find the breakpoints. Returns the indices of breakpoint in the time series
        """
        dy = np.diff(y) / (np.diff(x))
        cp = np.where(np.fabs(np.diff(dy)) > threshold)[0]
        return cp + 1

    # compute measure of bias in the residuals
    def compute_measure_bias(t, l1y, y, cp, min_samples_per_segment=6, threshold_bias_res_detect=40, threshold_vel=8,
                             verbose=True):
        """
        compute indicators of fit from a residual time series being obs minus piecewise_linear.
        Given some thresholds, return the list of periods with suspected problems and the index of
        associated breakpoints in the breakpoint list
        """
        # import
        import numpy as np
        import pyacs.lib.astrotime as at
        datetime_t = at.decyear2datetime(t)
        rms_l1 = np.median(np.fabs(y))

        # computes average velocity
        ivel = np.diff(l1y) / np.diff(t)
        median_vel = np.median(ivel)
        median_vel_change = np.median(np.fabs(ivel - median_vel))
        lperiod = []
        lcp = []
        for i in np.arange(cp.shape[0] - 1):
            wt = t[cp[i]:cp[i + 1] + 1]
            wy = y[cp[i]:cp[i + 1] + 1]
            if wt.shape[0] < min_samples_per_segment:
                continue

            mb, resv = measure_bias(wt, wy)

            # threshold for velocity 4 * median scatter
            rvel = np.fabs(np.mean(np.diff(l1y[cp[i]:cp[i + 1] + 1]) / np.diff(wt)) - median_vel) / median_vel_change

            if mb > threshold_bias_res_detect and rvel > threshold_vel:
                VERBOSE(("detected period: %s-%s nsample: %3d velocity_bias_measure: %.1lf rms_l1: %.1lf vs %.1lf rvel %.1lf " % \
                          (datetime_t[cp[i]].isoformat()[:10], datetime_t[cp[i + 1]].isoformat()[:10], wt.shape[0], mb,
                           resv, rms_l1, rvel)))


                lperiod.append([t[cp[i]], t[cp[i + 1]]])
                lcp.append(cp[i])
        return lperiod, lcp

    # define n_median_filter
    n_median_filter = np.min([11, ts.data.shape[0]-1])
    if n_median_filter % 2 == 0:
        n_median_filter = n_median_filter - 1

    # East component
    if 'E' in component:
        VERBOSE('Component E')
        t = ts.data[:, 0]
        y = ts.data[:, 2] * 1.E3
        l1y = l1ts.data[:, 2] * 1.E3
        fy = ts.median_filter(n=n_median_filter).data[:, 2] * 1.E3
        lidx = make_node_ts(t, l1y)
        H_cp['E'] = lidx
        H_period['E'], H_cp_pb['E'] = compute_measure_bias(t, l1y, fy - l1y, lidx,
                                                           min_samples_per_segment=min_samples_per_segment, \
                                                           threshold_bias_res_detect=threshold_bias_res_detect,
                                                           threshold_vel=threshold_vel)
        VERBOSE("#%d periods suspected" % len(H_period['E']))
    # North component
    if 'N' in component:
        VERBOSE('Component N')
        t = ts.data[:, 0]
        y = ts.data[:, 1] * 1.E3
        l1y = l1ts.data[:, 1] * 1.E3
        fy = ts.median_filter(n=n_median_filter).data[:, 1] * 1.E3
        lidx = make_node_ts(t, l1y)
        H_cp['N'] = lidx
        H_period['N'], H_cp_pb['N'] = compute_measure_bias(t, l1y, fy - l1y, lidx,
                                                           min_samples_per_segment=min_samples_per_segment, \
                                                           threshold_bias_res_detect=threshold_bias_res_detect,
                                                           threshold_vel=threshold_vel)
        VERBOSE("#%d periods suspected" % len(H_period['N']))

    # Up component
    if 'U' in component:
        VERBOSE('Component U')
        t = ts.data[:, 0]
        y = ts.data[:, 3] * 1.E3
        l1y = l1ts.data[:, 3] * 1.E3
        fy = ts.median_filter(n=n_median_filter).data[:, 3] * 1.E3
        lidx = make_node_ts(t, l1y)
        H_cp['U'] = lidx
        H_period['U'], H_cp_pb['U'] = compute_measure_bias(t, l1y, fy - l1y, lidx,
                                                           min_samples_per_segment=min_samples_per_segment, \
                                                           threshold_bias_res_detect=threshold_bias_res_detect,
                                                           threshold_vel=threshold_vel)
        VERBOSE("#%d periods suspected" % len(H_period['U']))


    return H_period, H_cp, H_cp_pb

########################################################################################################################
# piecewise_linear_3_segments_known_dates_known_int_fin
########################################################################################################################

def piecewise_linear_3_segments_known_dates_known_int_fin(t0, y0, tn, yn, t1, t2, t, y, norm='L2'):
    """
    find values of optimal piecewise linear function p(t) with break points at t1,t2 for function t,y,
    under the constraints that p(t0) = y0 and p(tn)=yn
    """

    import numpy as np
    lidx_segment1 = np.where((t > t0) & (t <= t1))[0]
    lidx_segment2 = np.where((t > t1) & (t <= t2))[0]
    lidx_segment3 = np.where((t > t2) & (t <= tn))[0]

    # segment #1
    A1 = np.zeros((lidx_segment1.shape[0], 2))
    Dt = (t[lidx_segment1] - t0) / (t1 - t0)
    A1[:, 0] = Dt
    D1 = y[lidx_segment1] - y0 + y0 * Dt

    # segment #2
    A2 = np.zeros((lidx_segment2.shape[0], 2))
    Dt = (t[lidx_segment2] - t1) / (t2 - t1)
    A2[:, 0] = 1 - Dt
    A2[:, 1] = Dt
    D2 = y[lidx_segment2]
    # segment #3
    A3 = np.zeros((lidx_segment3.shape[0], 2))
    Dt = (t[lidx_segment3] - tn) / (tn - t2)
    A3[:, 1] = -Dt
    D3 = y[lidx_segment3] - yn - Dt * yn

    A = np.vstack((A1, A2, A3))
    D = np.concatenate((D1, D2, D3))

    # solve
    N = np.dot(A.T, A)
    DD = np.dot(A.T, D)
    if norm == 'L2':
        import numpy.linalg
        res = numpy.linalg.solve(N, DD)
    if norm == 'L1':
        from pyacs.lib.robustestimators import Dikin
        res = Dikin(A, D, None)[0]

    return np.interp(t, [t0, t1, t2, tn], [y0, res[0], res[1], yn])

########################################################################################################################
# piecewise_linear_3_segments_known_dates_known_int_fin
########################################################################################################################

def piecewise_linear_4_segments_known_dates_known_int_fin(t0, y0, tn, yn, t1, t2, t3, t, y, norm='L2'):
    """
    find values of optimal piecewise linear function p(t) with break points at t1,t2, t3 for function t,y,
    under the constraints that p(t0) = y0 and p(tn)=yn
    """

    import numpy as np

    epsilon = 1/365.25/4

    lidx_segment1 = np.where((t >= (t0-epsilon)) & (t <= t1))[0]
    lidx_segment2 = np.where((t > t1) & (t <= t2))[0]
    lidx_segment3 = np.where((t > t2) & (t <= t3))[0]
    lidx_segment4 = np.where((t > t3) & (t <= (tn+epsilon) ))[0]

    # segment #1
    A1 = np.zeros((lidx_segment1.shape[0], 3))
    Dt = (t[lidx_segment1] - t0) / (t1 - t0)
    A1[:, 0] = Dt
    D1 = y[lidx_segment1] - y0 + y0 * Dt

    # segment #2
    A2 = np.zeros((lidx_segment2.shape[0], 3))
    Dt = (t[lidx_segment2] - t1) / (t2 - t1)
    A2[:, 0] = 1 - Dt
    A2[:, 1] = Dt
    D2 = y[lidx_segment2]

    # segment #3
    A3 = np.zeros((lidx_segment3.shape[0], 3))
    Dt = (t[lidx_segment3] - t2) / (t3 - t2)
    A3[:, 1] = 1 - Dt
    A3[:, 2] = Dt
    D3 = y[lidx_segment3]

    # segment #4
    A4 = np.zeros((lidx_segment4.shape[0], 3))
    Dt = (t[lidx_segment4] - tn) / (tn - t3)
    A4[:, 2] = -Dt
    D4 = y[lidx_segment4] - yn - Dt * yn

    A = np.vstack((A1, A2, A3, A4))
    D = np.concatenate((D1, D2, D3, D4))

    # solve
    N = np.dot(A.T, A)
    DD = np.dot(A.T, D)
    if norm == 'L2':
        import numpy.linalg
        res = numpy.linalg.solve(N, DD)
    if norm == 'L1':
        from pyacs.lib.robustestimators import Dikin
        res = Dikin(A, D, None)[0]

    return np.interp(t, [t0, t1, t2, t3, tn], [y0, res[0], res[1], res[2], yn])

########################################################################################################################
# find_optimal_3_segments_pwlf
########################################################################################################################

def find_optimal_3_segments_pwlf(t,y):
    import numpy as np
    fit_ref = np.sum((y-np.mean(y))**2)
    n = y.shape[0]
    for i in np.arange(1,n-2):
        for j in np.arange(i+1,n-1):
            y_fit = piecewise_linear_3_segments_known_dates_known_int_fin(t[0],y[0],t[-1],y[-1],t[i],t[j],t,y)
            fit = np.sum((y-y_fit)**2)
            if fit < fit_ref:
                fit_ref = fit
                y_fit_ref = y_fit
    return y_fit_ref

########################################################################################################################
# find_optimal_4_segments_pwlf
########################################################################################################################

def find_optimal_4_segments_pwlf(t,y):
    import numpy as np
    fit_ref = np.sum((y-np.mean(y))**2)
    n = y.shape[0]
    for i in np.arange(4,n-(2+4)):
        for j in np.arange(i+1,n-1):
            for k in np.arange(j+1,n-4):
                y_fit = piecewise_linear_4_segments_known_dates_known_int_fin(t[0],y[0],t[-1],y[-1],t[i],t[j],t[k],t,y)
                fit = np.sum((y-y_fit)**2)
                if fit < fit_ref:
                    fit_ref = fit
                    y_fit_ref = y_fit
    return y_fit_ref

########################################################################################################################
# MAIN FUNCTION refine_l1trend
########################################################################################################################

def refine_l1trend(self,
                   rawts,
                   lcomponent='ENU',
                   min_samples_per_segment=10,
                   threshold_bias_res_detect=10,
                   threshold_vel=8,
                   min_sample_segment_refinement=1,
                   norm='L2',
                   output='ts'):
    """
    Refine results from l1trend by optimizing the date of breakpoints for suspected periods.
    The algorithm first identify periods where the l1trend model might be improved.
    For every candidate period, the algorithm checks different metrics to decide if the model should be refined.
    Finally, for the selected periods, it optimizes the date of breakpoints.

    :param rawts: raw time series, originally processed by l1trend
    :param lcomponent: component to refine (default: 'ENU')
    :param min_samples_per_segment: minimum number of samples for a segment to be considered as a candidate
                                    for improvement (default: 10)
    :param threshold_bias_res_detect: threshold to detect bias residuals (default: 10)
    :param threshold_vel: threshold to detect high velocities (default: 8)
    :param min_sample_segment_refinement: minimum number of samples for a segment in the refined model (default: 1)
    :param norm: norm to be minimized for improvement (default: 'L2')
    :param output: output type 'ts' for the refined Gts, 'info' for the periods suspected, 'both' for both (default: 'ts')
    """

    # import
    import logging
    import pyacs.message.message as MESSAGE
    import pyacs.message.verbose_message as VERBOSE
    import pyacs.message.error as ERROR
    import pyacs.message.warning as WARNING
    import pyacs.message.debug_message as DEBUG
    import pyacs.debug
    from icecream import ic

    # Verbose message
    VERBOSE("Refining l1trend results")
    VERBOSE("Parameters used for refinement")
    VERBOSE("min_samples_per_segment: %d" % min_samples_per_segment)
    VERBOSE("threshold_bias_res_detect: %d" % threshold_bias_res_detect)
    VERBOSE("threshold_vel: %d" % threshold_vel)
    VERBOSE("min_sample_segment_refinement: %d" % min_sample_segment_refinement)
    VERBOSE("norm: %s" % norm)

    # set icecream
    ###########################################################################
    if pyacs.debug():
        ic.enable()
    else:
        ic.disable()
    ###########################################################################

    VERBOSE("Refine l1trend at suspected periods for %s" % (self.code))

    #############################################################################################################################
    def refine_l1trend_suspect_periods(ts, l1ts, H_cp, H_scp, norm='L2', min_sample_segment_refinement=1):
    #############################################################################################################################
        """
        refine an l1trend time series estimates for suspected periods provided by H_cp and H_scp

        :param ts: raw time series
        :param l1ts: l1trend time series
        :param H_cp: dictionary of breakpoints index for the whole time series
        :param H_scp: dictionary of breakpoints index for the suspected periods
        :param norm: norm to be minimized for improvement (default: 'L2')
        :param min_sample_segment_refinement: minimum number of samples for a segment in the refined model (default: 1)

        :return: the refined l1trend time series
        """

        VERBOSE("Trying refinement of suspect periods for %s" % (self.code))

        # import
        import numpy as np
        import pyacs.lib.astrotime as at

        ic(min_sample_segment_refinement)


        # make_date_index_for_period_test
        ################################################################################################################
        def make_date_index_for_period_test(mts, H_cp, H_cp_pb, component):
            """
            For each suspicious periods, make a list of date to be tested. Merges periods if they are contiguous or
            share periods
            """

            import pyacs.lib.astrotime as at
            import numpy as np

            period_segments = []

            # date_breakpoints of l1trend in seconds
            date_breakpoints = at.decyear2seconds(mts.data[H_cp[component], 0])
            # adds first and last dates
            date_breakpoints = np.append(np.array(at.decyear2seconds(mts.data[0, 0])), date_breakpoints)
            date_breakpoints = np.append(date_breakpoints, np.array(at.decyear2seconds(mts.data[-1, 0])))

            # build suspicious periods
            suspicious_periods_start = at.decyear2seconds(mts.data[H_cp_pb[component], 0])

            test_periods_seconds = np.zeros((suspicious_periods_start.shape[0], 2), dtype=int)
            for i in np.arange(suspicious_periods_start.shape[0]):
                idx = np.where(suspicious_periods_start[i] == date_breakpoints)[0][0]
                date_bps = np.max([np.min([date_breakpoints[idx - 1], date_breakpoints[idx] - 10 * 86400]),
                                   date_breakpoints[idx] - 40 * 86400])
                date_bpe = np.min([np.max([date_breakpoints[idx + 2], date_breakpoints[idx + 1] + 10 * 86400]),
                                   date_breakpoints[idx + 1] + 40 * 86400])
                test_periods_seconds[i, :] = np.array([date_bps, date_bpe]).T

            # merge contiguous periods
            lcorrected_test_periods_seconds = []
            i = 0
            while i < test_periods_seconds.shape[0]:
                j = i
                for j in np.arange(i, test_periods_seconds.shape[0] - 1):
                    if test_periods_seconds[j, 1] >= test_periods_seconds[j + 1, 0]:
                        j = j + 1
                    else:
                        break
                lcorrected_test_periods_seconds.append([test_periods_seconds[i, 0], test_periods_seconds[j, 1]])
                i = j + 1

            np_corrected_test_periods_seconds = np.array(lcorrected_test_periods_seconds)

            # convert back to index
            np_corrected_test_periods_index = np.copy(np_corrected_test_periods_seconds)
            t_seconds = at.decyear2seconds(mts.data[:, 0])
            for i in np.arange(np_corrected_test_periods_seconds.shape[0]):
                idxs = np.argmin(np.fabs(t_seconds - np_corrected_test_periods_seconds[i, 0]))
                idxe = np.argmin(np.fabs(t_seconds - np_corrected_test_periods_seconds[i, 1]))
                np_corrected_test_periods_index[i, :] = [idxs, idxe]

            # prepare index list for tests
            index_list = []
            # coarse exploration step = 10 days
            step_days = 10
            for i in np.arange(np_corrected_test_periods_index.shape[0]):
                index_list.append(
                    np.linspace(np_corrected_test_periods_index[i, 0], np_corrected_test_periods_index[i, 1], step_days,
                                dtype=int))

            # fine exploration during suspicious periods - every day

            for i in np.arange(len(H_cp_pb[component])):
                idx = np.where(H_cp[component] == H_cp_pb[component][i])[0][0]
                a = np.arange(H_cp_pb[component][i], H_cp[component][idx + 1] + 1)
                for j in np.arange(len(index_list)):
                    if (a[0] >= index_list[j][0]) and (a[-1] <= index_list[j][-1]):
                        index_list[j] = np.append(index_list[j], a)

                        # sort and unique
            for i in np.arange(len(index_list)):
                index_list[i] = np.sort(np.unique(index_list[i]))

            return index_list

        # refine
        ################################################################################################################
        def refine(mfts, l1ts, lindex, icomponent, min_segment=4):

            # min_segment - minimum number of samples for a segment
            #min_segment = 1

            ic(min_segment)

            H_icomponent = {1: 'N', 2: 'E', 3: 'U'}

            # loop on periods
            for i in np.arange(len(lindex)):
                IMPROVEMENT = False
                np_idx = lindex[i]
                fit_before = np.mean(np.fabs(
                    mfts.data[np_idx[0]:np_idx[-1] + 1, icomponent] - l1ts.data[np_idx[0]:np_idx[-1] + 1,
                                                                      icomponent])) * 1.E3
                rfit_before = fit_before

                t0 = ts.data[np_idx[0], 0]
                y0 = l1ts.data[np_idx[0], icomponent] * 1.E3
                tn = ts.data[np_idx[-1], 0]
                yn = l1ts.data[np_idx[-1], icomponent] * 1.E3
                t = ts.data[np_idx[0]:np_idx[-1] + 1, 0]
                y = mfts.data[np_idx[0]:np_idx[-1] + 1, icomponent] * 1.E3
                VERBOSE("testing period: %s-%s" % (at.decyear2datetime(t0).isoformat()[:10], at.decyear2datetime(tn).isoformat()[:10]))

                y[0] = y0
                y[-1] = yn

                # find optimal 3 segments
                VERBOSE("Finding optimal 3-segments piecewise linear approximation")
                y3_fit = find_optimal_3_segments_pwlf(t, y)

                fit_after = np.mean(np.fabs(mfts.data[np_idx[0]:np_idx[-1] + 1, icomponent] * 1.E3 - y3_fit))
                ic(fit_after)

                if (fit_before - fit_after) > 0 and (rfit_before - fit_after) / rfit_before * 100. > 0:

                    wl1ts.data[np_idx[0]:np_idx[-1] + 1, icomponent] = np.copy(y3_fit) * 1.E-3
                    IMPROVEMENT = True
                    fit_before = fit_after

                if IMPROVEMENT:
                    VERBOSE("period: %s-%s improvement: %.1lf %%" % \
                          (at.decyear2datetime(t0).isoformat()[:10], at.decyear2datetime(tn).isoformat()[:10],
                           (rfit_before - fit_before) / rfit_before * 100.))
                else:
                    VERBOSE("period: %s-%s improvement: NO " % (
                    at.decyear2datetime(t0).isoformat()[:10], at.decyear2datetime(tn).isoformat()[:10]))

                # find optimal 4 segments
                FOUR_SEGMENT = False
                if FOUR_SEGMENT:
                    VERBOSE("Finding optimal 4-segments piecewise linear approximation")
                    y4_fit = find_optimal_4_segments_pwlf(t, y)

                    fit_after = np.mean(np.fabs(mfts.data[np_idx[0]:np_idx[-1] + 1, icomponent] * 1.E3 - y4_fit))
                    ic(fit_after)

                    if (fit_before - fit_after) > 0 and (rfit_before - fit_after) / rfit_before * 100. > 0:

                        wl1ts.data[np_idx[0]:np_idx[-1] + 1, icomponent] = np.copy(y4_fit) * 1.E-3
                        IMPROVEMENT = True
                        fit_before = fit_after

                    if IMPROVEMENT:
                        VERBOSE("period: %s-%s improvement: %.1lf %%" % \
                              (at.decyear2datetime(t0).isoformat()[:10], at.decyear2datetime(tn).isoformat()[:10],
                               (rfit_before - fit_before) / rfit_before * 100.))
                    else:
                        VERBOSE("period: %s-%s improvement: NO " % (
                        at.decyear2datetime(t0).isoformat()[:10], at.decyear2datetime(tn).isoformat()[:10]))

                if pyacs.debug():

                    # plot to see performance
                    import matplotlib.pyplot as plt
                    plt.figure(figsize=(10, 5))
                    plt.title("%s period: %s-%s component %s" %
                              (l1ts.code, at.decyear2datetime(t0).isoformat()[:10], at.decyear2datetime(tn).isoformat()[:10], H_icomponent[icomponent] ))
                    plt.plot(at.decyear2datetime(t), y, 'bo')

                    plt.plot(at.decyear2datetime(t), l1ts.data[np_idx[0]:np_idx[-1]+1, icomponent] * 1.E3, 'r')
                    plt.plot(at.decyear2datetime(t), y3_fit, 'g')
                    plt.xlim( at.decyear2datetime(t0-1/365.25), at.decyear2datetime(tn-1/365.25))
                    plt.show()

            return wl1ts

        ############### MAIN #################################################################

        # compute median filter for statistics
        n_median_filter = np.min([5, ts.data.shape[0]-1])
        if n_median_filter % 2 == 0:
            n_median_filter = n_median_filter - 1
        mfts = ts.median_filter(n=n_median_filter)

        wl1ts = l1ts.copy()

        ic(H_scp)
        ic()
        # EAST COMPONENT
        if 'E' in list( H_scp.keys() ):
            component = 'E'
            icomponent = 2

            VERBOSE("%s component: %s" % (l1ts.code, component))

            # get index_list
            lindex = make_date_index_for_period_test(ts, H_cp, H_scp, component)

            # refine
            wl1ts = refine(mfts, l1ts, lindex, icomponent, min_segment=min_sample_segment_refinement)
            #wl1ts = refine(ts, l1ts, lindex, icomponent, min_segment=min_sample_segment_refinement)

        # NORTH COMPONENT
        if 'N' in list( H_scp.keys()):
            component = 'N'
            icomponent = 1

            VERBOSE("%s component: %s" % (l1ts.code, component))

            # get index_list
            ic(H_cp)
            ic(H_scp)
            lindex = make_date_index_for_period_test(ts, H_cp, H_scp, component)
            ic(lindex)
            # refine
            wl1ts = refine(mfts, l1ts, lindex, icomponent, min_segment=min_sample_segment_refinement)
            #wl1ts = refine(ts, l1ts, lindex, icomponent, min_segment=min_sample_segment_refinement)

        # UP COMPONENT
        if 'U' in list( H_scp.keys()):
            component = 'U'
            icomponent = 3

            VERBOSE("%s component: %s" % (l1ts.code, component))

            # get index_list
            lindex = make_date_index_for_period_test(ts, H_cp, H_scp, component)

            # refine
            wl1ts = refine(mfts, l1ts, lindex, icomponent, min_segment=min_sample_segment_refinement)
            #wl1ts = refine(ts, l1ts, lindex, icomponent, min_segment=min_sample_segment_refinement)


        return wl1ts

    ####################################################################################################################
    # MAIN
    ####################################################################################################################


    VERBOSE("Searching suspect periods for %s" % (self.code))
    H_period,H_cp, H_cp_pb = check_l1_trend(rawts, self,
                                            component=lcomponent,
                                            min_samples_per_segment=min_samples_per_segment,
                                            threshold_bias_res_detect=threshold_bias_res_detect,
                                            threshold_vel=threshold_vel)


    rts = refine_l1trend_suspect_periods( rawts, self , H_cp, H_cp_pb, norm='L2',
                                          min_sample_segment_refinement=min_sample_segment_refinement)

    if output == 'ts':
        return rts
    if output == 'both':
        return rts, H_period, H_cp, H_cp_pb
    if output == 'info':
        return H_period, H_cp, H_cp_pb
