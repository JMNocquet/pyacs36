#############################################################################################################################
def l1trend_to_breakpoints(self, tol='auto', threshold=[1.,1., 5.]):
#############################################################################################################################
    """
    Convert a Gts resulting from a L1-trend-filtering to a dictionary of breakpoints.
    The breakpoints are computed by looking for significant changes in the slope of the time series.

    Parameters
    ----------
    tol : float or 'auto'
        Tolerance for detecting breakpoints in mm/yr. If 'auto', finds the greatest tol
        such that the max difference between interpolated breakpoints and the time series is below a threshold for each component.
    threshold : list of floats
        List of thresholds in mm for each component ('N', 'E', 'U') to determine the best tolerance if tol is 'auto'.
        Default is [1., 1., 5.] for 'N', 'E', and 'U' respectively.
        If tol is a float, this parameter is ignored.
    Returns
    -------
    bp : record
        Dictionary with keys as component names ('E', 'N', 'U') and dates/values as
        bp[component][0], H_bp[component][1]
    """

    from pyacs.gts.Gts import Gts
    import numpy as np

    lcomponent = ['N', 'E', 'U']
    bp  = {comp: [[],[]] for comp in lcomponent}   
    time_decyear = self.data[:,0]

    def compute_bp(tol_vals, lcomponent=['N', 'E', 'U']):
        bp_local = {comp: [[], []] for comp in lcomponent}
        licomponent = np.array([['N', 'E', 'U'].index(comp) for comp in lcomponent])
        for i, icomponent in enumerate(licomponent):
            y = self.data[:, icomponent + 1]
            dy = np.diff(y) / (np.diff(time_decyear))
            cp = np.where(np.fabs(np.diff(dy)) > tol_vals[i])[0]
            cp = cp + 1
            bp_local[lcomponent[i]][0] = time_decyear[cp]
            bp_local[lcomponent[i]][1] = y[cp]
            bp_local[lcomponent[i]][0] = np.insert(bp_local[lcomponent[i]][0], 0, time_decyear[0])
            bp_local[lcomponent[i]][1] = np.insert(bp_local[lcomponent[i]][1], 0, y[0])
            bp_local[lcomponent[i]][0] = np.append(bp_local[lcomponent[i]][0], time_decyear[-1])
            bp_local[lcomponent[i]][1] = np.append(bp_local[lcomponent[i]][1], y[-1])
        return bp_local

    if tol == 'auto':
        tol_candidates = np.array([0.5, 1, 2, 3, 4, 5, 10, 20, 50, 100])
        best_tol = [tol_candidates[0]] * 3
        for i, component in enumerate(lcomponent):
            for t in tol_candidates:
                tol_vals = [0.0005, 0.0005, 0.0005]
                tol_vals[i] = t / 1000.0
                bp_test = compute_bp(tol_vals, lcomponent=[lcomponent[i]])
                bp_times = bp_test[component][0]
                bp_values = bp_test[component][1]
                icomponent = np.array(['N', 'E', 'U'].index(component)) + 1
                values = self.data[:,icomponent]
                interp_values = np.interp(time_decyear, bp_times, bp_values)
                max_mm = np.max(np.abs(interp_values - values)) * 1E3
                if max_mm < threshold[i]:
                    best_tol[i] = t
                else:
                    break
        tol_vals = [t / 1000.0 for t in best_tol]
        bp = compute_bp(tol_vals)
#        print('best tol per component =', {comp: t for comp, t in zip(lcomponent, best_tol)}, 'mm/yr')
    else:
        tol_val = float(tol) / 1000.0
        bp = compute_bp([tol_val, tol_val, tol_val])
#        print('tol = %.3f mm/yr' % (tol_val * 1000.0))
    return bp

#############################################################################################################################
def clean_l1trend(self, raw_gts, threshold = 'auto'):
#############################################################################################################################
    """
    Cleans breakpoints from L1-trend filtered time series.
    Removes breakpoints that are too close in value (<0.5 mm/yr).
    Returns a new Gts object interpolated on the dates from l1trend_gts.

    Parameters
    ----------
    raw_gts : pyacs.gts.Gts.Gts
        Raw time series.

    Returns
    -------
    pyacs.gts.Gts.Gts
        Cleaned/interpolated Gts object.
    """

    # import
    import numpy as np
    from pyacs.gts.Gts import Gts

    if isinstance(threshold, str) and threshold == 'auto':
        # Compute threshold from median difference (in mm)
        diff = raw_gts.data[:,1:4] - self.data[:,1:4]
        threshold = np.median(np.abs(diff), axis=0) * 1E3  # mm

    # Get breakpoints using tol='auto' and threshold
    bp = self.l1trend_to_breakpoints(tol='auto', threshold=threshold)

    # Interpolate cleaned breakpoints on l1trend_gts dates
    new_data = np.zeros_like(self.data)
    new_data[:,0] = self.data[:,0]
    for i, comp in enumerate(['N', 'E', 'U']):
        # Interpolate breakpoints on l1trend_gts dates (no cleaning)
        bp_dates = bp[comp][0]
        bp_values = bp[comp][1]
        new_data[:,i+1] = np.interp(new_data[:,0], bp_dates, bp_values)
    # Copy uncertainties from l1trend_gts
    new_data[:,4:8] = self.data[:,4:8]

    # Create new Gts object
    cleaned_gts = Gts(code=self.code, data=new_data)
    return cleaned_gts

#############################################################################################################################
def check_l1_trend(ts, l1ts, component='EN', min_samples_per_segment=6, threshold_bias_res_detect=40, threshold_vel=8):
#############################################################################################################################
    """
    inspect the result from l1trend model of a time series.
    Returns a list periods ([sdate,edate]) where bad modelling is suspected.

    :param ts: raw time series
    :param l1ts: l1trend time series
    :param component: components to be analyzed. Default: 'EN'
    :param min_samples_per_segment: minimum number of samples for a segment to inspected (default: 6)
    :param threshold_bias_res_detect: threshold to detect bias residuals (default: 40)
    :param threshold_vel: instantaneous velocity threshold for a segment to be considered in detection (default: 8 mm/yr)

    :return
    """

    # import
    import numpy as np

    import logging
    import pyacs.message.message as MESSAGE
    import pyacs.message.verbose_message as VERBOSE
    import pyacs.message.error as ERROR
    import pyacs.message.warning as WARNING
    import pyacs.message.debug_message as DEBUG
    import pyacs.debug

    # initialize
    H_period = {}
    H_cp_pb = {}
    H_cp = {}

    VERBOSE("Searching suspicious periods for %s" % (l1ts.code))

    # measure bias
    ####################################################################################################################
    def measure_bias(t, y):
        """
        provides a measure of potentiel bias in a residual time series (0-100)
        """

        import numpy as np

        nsample = y.shape[0]
        mid_date = (t[-1] + t[0]) / 2

        lidx_1 = np.where(t < mid_date)[0]
        lidx_2 = np.where(t > mid_date)[0]

        n_positif1 = np.where(y[lidx_1] >= 0)[0].shape[0]
        n_negatif2 = np.where(y[lidx_2] <= 0)[0].shape[0]

        n_negatif1 = lidx_1.shape[0] - n_positif1
        n_positif2 = lidx_2.shape[0] - n_negatif2

        res = np.max([np.fabs(((n_positif1 + n_negatif2) / nsample * 100.) - 50.) * 2,
                      np.fabs(((n_negatif1 + n_positif2) / nsample * 100.) - 50.) * 2])

        resv = np.median(np.fabs(y))

        return res, resv

    # find nodes of piecewice linear function
    def make_node_ts(x, y, threshold=.5):
    # note JMN 10/08/2025: .5 seems to be too tight ans results in too many breakpoints
    # from pyacs.0.65.97 the time series is pre-processed using l1trend_to_breakpoints and 0.5 should be fine
        """
        Assuming that y is piecewise linear, find the breakpoints. Returns the indices of breakpoint in the time series
        """
        dy = np.diff(y) / (np.diff(x))
        cp = np.where(np.fabs(np.diff(dy)) > threshold)[0]
        return cp + 1

    # compute measure of bias in the residuals
    def compute_measure_bias(t, l1y, y, cp, min_samples_per_segment=6, threshold_bias_res_detect=40, threshold_vel=8,
                             verbose=True):
        """
        compute indicators of fit from a residual time series being obs minus piecewise_linear.
        Given some thresholds, return the list of periods with suspected problems and the index of
        associated breakpoints in the breakpoint list
        """
        # import
        import numpy as np
        import pyacs.lib.astrotime as at
        datetime_t = at.decyear2datetime(t)
        rms_l1 = np.median(np.fabs(y))

        # computes average velocity
        ivel = np.diff(l1y) / np.diff(t)
        median_vel = np.median(ivel)
        median_vel_change = np.median(np.fabs(ivel - median_vel))
        lperiod = []
        lcp = []
        for i in np.arange(cp.shape[0] - 1):
            wt = t[cp[i]:cp[i + 1] + 1]
            wy = y[cp[i]:cp[i + 1] + 1]
            if wt.shape[0] < min_samples_per_segment:
                continue

            mb, resv = measure_bias(wt, wy)

            # threshold for velocity 4 * median scatter
            rvel = np.fabs(np.mean(np.diff(l1y[cp[i]:cp[i + 1] + 1]) / np.diff(wt)) - median_vel) / median_vel_change

            if mb > threshold_bias_res_detect and rvel > threshold_vel:
                VERBOSE((" %s-%s nsample: %3d velocity_bias_measure: %.1lf rms_l1: %.1lf vs %.1lf rvel %.1lf " % \
                          (datetime_t[cp[i]].isoformat()[:10], datetime_t[cp[i + 1]].isoformat()[:10], wt.shape[0], mb,
                           resv, rms_l1, rvel)))


                lperiod.append([t[cp[i]], t[cp[i + 1]]])
                lcp.append(cp[i])
        return lperiod, lcp

    # define n_median_filter
    n_median_filter = np.min([11, ts.data.shape[0]-1])
    if n_median_filter % 2 == 0:
        n_median_filter = n_median_filter - 1

    # East component
    if 'E' in component:
        VERBOSE('Component E')
        t = ts.data[:, 0]
        y = ts.data[:, 2] * 1.E3
        l1y = l1ts.data[:, 2] * 1.E3
        fy = ts.median_filter(n=n_median_filter).data[:, 2] * 1.E3
        lidx = make_node_ts(t, l1y)
        H_cp['E'] = lidx
        VERBOSE("Searching suspicious periods for component E ")
        H_period['E'], H_cp_pb['E'] = compute_measure_bias(t, l1y, fy - l1y, lidx,
                                                           min_samples_per_segment=min_samples_per_segment, \
                                                           threshold_bias_res_detect=threshold_bias_res_detect,
                                                           threshold_vel=threshold_vel)
        VERBOSE("#%d periods suspected for component E" % len(H_period['E']))
    # North component
    if 'N' in component:
        VERBOSE('Component N')
        t = ts.data[:, 0]
        y = ts.data[:, 1] * 1.E3
        l1y = l1ts.data[:, 1] * 1.E3
        fy = ts.median_filter(n=n_median_filter).data[:, 1] * 1.E3
        lidx = make_node_ts(t, l1y)
        H_cp['N'] = lidx
        VERBOSE("Searching suspicious periods for component N ")
        H_period['N'], H_cp_pb['N'] = compute_measure_bias(t, l1y, fy - l1y, lidx,
                                                           min_samples_per_segment=min_samples_per_segment, \
                                                           threshold_bias_res_detect=threshold_bias_res_detect,
                                                           threshold_vel=threshold_vel)
        VERBOSE("#%d periods suspected for component N" % len(H_period['N']))

    # Up component
    if 'U' in component:
        VERBOSE('Component U')
        t = ts.data[:, 0]
        y = ts.data[:, 3] * 1.E3
        l1y = l1ts.data[:, 3] * 1.E3
        fy = ts.median_filter(n=n_median_filter).data[:, 3] * 1.E3
        lidx = make_node_ts(t, l1y)
        H_cp['U'] = lidx
        VERBOSE("Searching suspicious periods for component U ")
        H_period['U'], H_cp_pb['U'] = compute_measure_bias(t, l1y, fy - l1y, lidx,
                                                           min_samples_per_segment=min_samples_per_segment, \
                                                           threshold_bias_res_detect=threshold_bias_res_detect,
                                                           threshold_vel=threshold_vel)
        VERBOSE("#%d periods suspected for component U" % len(H_period['U']))


    return H_period, H_cp, H_cp_pb

########################################################################################################################
# piecewise_linear_3_segments_known_dates_known_int_fin
########################################################################################################################

def piecewise_linear_3_segments_known_dates_known_int_fin(t0, y0, tn, yn, t1, t2, t, y, norm='L2'):
    """
    find values of optimal piecewise linear function p(t) with break points at t1,t2 for function t,y,
    under the constraints that p(t0) = y0 and p(tn)=yn
    """

    import numpy as np
    lidx_segment1 = np.where((t > t0) & (t <= t1))[0]
    lidx_segment2 = np.where((t > t1) & (t <= t2))[0]
    lidx_segment3 = np.where((t > t2) & (t <= tn))[0]

    # segment #1
    A1 = np.zeros((lidx_segment1.shape[0], 2))
    Dt = (t[lidx_segment1] - t0) / (t1 - t0)
    A1[:, 0] = Dt
    D1 = y[lidx_segment1] - y0 + y0 * Dt

    # segment #2
    A2 = np.zeros((lidx_segment2.shape[0], 2))
    Dt = (t[lidx_segment2] - t1) / (t2 - t1)
    A2[:, 0] = 1 - Dt
    A2[:, 1] = Dt
    D2 = y[lidx_segment2]
    # segment #3
    A3 = np.zeros((lidx_segment3.shape[0], 2))
    Dt = (t[lidx_segment3] - tn) / (tn - t2)
    A3[:, 1] = -Dt
    D3 = y[lidx_segment3] - yn - Dt * yn

    A = np.vstack((A1, A2, A3))
    D = np.concatenate((D1, D2, D3))

    # solve
    N = np.dot(A.T, A)
    DD = np.dot(A.T, D)
    if norm == 'L2':
        import numpy.linalg
        res = numpy.linalg.solve(N, DD)
    if norm == 'L1':
        from pyacs.lib.robustestimators import Dikin
        res = Dikin(A, D, None)[0]

    return np.interp(t, [t0, t1, t2, tn], [y0, res[0], res[1], yn])

########################################################################################################################
# piecewise_linear_3_segments_known_dates_known_int_fin
########################################################################################################################

def piecewise_linear_4_segments_known_dates_known_int_fin(t0, y0, tn, yn, t1, t2, t3, t, y, norm='L2'):
    """
    find values of optimal piecewise linear function p(t) with break points at t1,t2, t3 for function t,y,
    under the constraints that p(t0) = y0 and p(tn)=yn
    """

    import numpy as np

    epsilon = 1/365.25/4

    lidx_segment1 = np.where((t >= (t0-epsilon)) & (t <= t1))[0]
    lidx_segment2 = np.where((t > t1) & (t <= t2))[0]
    lidx_segment3 = np.where((t > t2) & (t <= t3))[0]
    lidx_segment4 = np.where((t > t3) & (t <= (tn+epsilon) ))[0]

    # segment #1
    A1 = np.zeros((lidx_segment1.shape[0], 3))
    Dt = (t[lidx_segment1] - t0) / (t1 - t0)
    A1[:, 0] = Dt
    D1 = y[lidx_segment1] - y0 + y0 * Dt

    # segment #2
    A2 = np.zeros((lidx_segment2.shape[0], 3))
    Dt = (t[lidx_segment2] - t1) / (t2 - t1)
    A2[:, 0] = 1 - Dt
    A2[:, 1] = Dt
    D2 = y[lidx_segment2]

    # segment #3
    A3 = np.zeros((lidx_segment3.shape[0], 3))
    Dt = (t[lidx_segment3] - t2) / (t3 - t2)
    A3[:, 1] = 1 - Dt
    A3[:, 2] = Dt
    D3 = y[lidx_segment3]

    # segment #4
    A4 = np.zeros((lidx_segment4.shape[0], 3))
    Dt = (t[lidx_segment4] - tn) / (tn - t3)
    A4[:, 2] = -Dt
    D4 = y[lidx_segment4] - yn - Dt * yn

    A = np.vstack((A1, A2, A3, A4))
    D = np.concatenate((D1, D2, D3, D4))

    # solve
    N = np.dot(A.T, A)
    DD = np.dot(A.T, D)
    if norm == 'L2':
        import numpy.linalg
        res = numpy.linalg.solve(N, DD)
    if norm == 'L1':
        from pyacs.lib.robustestimators import Dikin
        res = Dikin(A, D, None)[0]

    return np.interp(t, [t0, t1, t2, t3, tn], [y0, res[0], res[1], res[2], yn])

########################################################################################################################
# find_optimal_3_segments_pwlf
########################################################################################################################

def find_optimal_3_segments_pwlf(t,y):
    import numpy as np
    fit_ref = np.sum((y-np.mean(y))**2)
    n = y.shape[0]
    for i in np.arange(1,n-2):
        for j in np.arange(i+1,n-1):
            y_fit = piecewise_linear_3_segments_known_dates_known_int_fin(t[0],y[0],t[-1],y[-1],t[i],t[j],t,y)
            fit = np.sum((y-y_fit)**2)
            if fit < fit_ref:
                fit_ref = fit
                y_fit_ref = y_fit
    return y_fit_ref

########################################################################################################################
# find_optimal_4_segments_pwlf
########################################################################################################################

def find_optimal_4_segments_pwlf(t,y):
    import numpy as np
    fit_ref = np.sum((y-np.mean(y))**2)
    n = y.shape[0]
    for i in np.arange(4,n-(2+4)):
        for j in np.arange(i+1,n-1):
            for k in np.arange(j+1,n-4):
                y_fit = piecewise_linear_4_segments_known_dates_known_int_fin(t[0],y[0],t[-1],y[-1],t[i],t[j],t[k],t,y)
                fit = np.sum((y-y_fit)**2)
                if fit < fit_ref:
                    fit_ref = fit
                    y_fit_ref = y_fit
    return y_fit_ref

########################################################################################################################
# MAIN FUNCTION refine_l1trend
########################################################################################################################

def refine_l1trend(self,
                   rawts,
                   lcomponent='ENU',
                   min_samples_per_segment=10,
                   threshold_bias_res_detect=10,
                   threshold_vel=8,
                   min_sample_segment_refinement=1,
                   norm='L2',
                   output='ts'):
    """
    Refine results from l1trend by optimizing the date of breakpoints for suspected periods.
    The algorithm first identify periods where the l1trend model might be improved.
    For every candidate period, the algorithm checks different metrics to decide if the model should be refined.
    Finally, for the selected periods, it optimizes the date of breakpoints.

    :param rawts: raw time series, originally processed by l1trend
    :param lcomponent: component to refine (default: 'ENU')
    :param min_samples_per_segment: minimum number of samples for a segment to be considered as a candidate
                                    for improvement (default: 10)
    :param threshold_bias_res_detect: threshold to detect bias residuals (default: 10)
    :param threshold_vel: threshold to detect high velocities (default: 8)
    :param min_sample_segment_refinement: minimum number of samples for a segment in the refined model (default: 1)
    :param norm: norm to be minimized for improvement (default: 'L2')
    :param output: output type 'ts' for the refined Gts, 'info' for the periods suspected, 'both' for both (default: 'ts')
    """

    # import
    import logging
    import pyacs.message.message as MESSAGE
    import pyacs.message.verbose_message as VERBOSE
    import pyacs.message.error as ERROR
    import pyacs.message.warning as WARNING
    import pyacs.message.debug_message as DEBUG
    import pyacs.debug
    from icecream import ic

    # Verbose message
    VERBOSE("----------------------------------------------------------")
    VERBOSE("Refining l1trend results using refine_l1trend for %s" % (self.code))
    VERBOSE("----------------------------------------------------------")
    VERBOSE("Parameters used for refinement")
    VERBOSE("min_samples_per_segment: %d" % min_samples_per_segment)
    VERBOSE("threshold_bias_res_detect: %d" % threshold_bias_res_detect)
    VERBOSE("threshold_vel: %d" % threshold_vel)
    VERBOSE("min_sample_segment_refinement: %d" % min_sample_segment_refinement)
    VERBOSE("norm: %s" % norm)
    VERBOSE("----------------------------------------------------------")

    # set icecream
    ###########################################################################
    if pyacs.debug():
        ic.enable()
    else:
        ic.disable()
    ###########################################################################


    #############################################################################################################################
    def refine_l1trend_suspect_periods(ts, l1ts, H_cp, H_scp, norm='L2', min_sample_segment_refinement=1):
    #############################################################################################################################
        """
        refine an l1trend time series estimates for suspected periods provided by H_cp and H_scp

        :param ts: raw time series
        :param l1ts: l1trend time series
        :param H_cp: dictionary of breakpoints index for the whole time series
        :param H_scp: dictionary of breakpoints index for the suspected periods
        :param norm: norm to be minimized for improvement (default: 'L2')
        :param min_sample_segment_refinement: minimum number of samples for a segment in the refined model (default: 1)

        :return: the refined l1trend time series
        """

        VERBOSE("Trying to refine piecewise linear approximation for suspect periods for %s" % (self.code))

        # import
        import numpy as np
        import pyacs.lib.astrotime as at

        ic(min_sample_segment_refinement)


        # make_date_index_for_period_test
        ################################################################################################################
        def make_date_index_for_period_test(mts, H_cp, H_cp_pb, component):
            """
            For each suspicious periods, make a list of date to be tested. Merges periods if they are contiguous or
            share periods
            """

            import pyacs.lib.astrotime as at
            import numpy as np

            period_segments = []

            # date_breakpoints of l1trend in seconds
            date_breakpoints = at.decyear2seconds(mts.data[H_cp[component], 0])
            # adds first and last dates
            date_breakpoints = np.append(np.array(at.decyear2seconds(mts.data[0, 0])), date_breakpoints)
            date_breakpoints = np.append(date_breakpoints, np.array(at.decyear2seconds(mts.data[-1, 0])))

            # build suspicious periods
            suspicious_periods_start = at.decyear2seconds(mts.data[H_cp_pb[component], 0])

            test_periods_seconds = np.zeros((suspicious_periods_start.shape[0], 2), dtype=int)
            for i in np.arange(suspicious_periods_start.shape[0]):
                idx = np.where(suspicious_periods_start[i] == date_breakpoints)[0][0]
                date_bps = np.max([np.min([date_breakpoints[idx - 1], date_breakpoints[idx] - 10 * 86400]),
                                   date_breakpoints[idx] - 40 * 86400])
                date_bpe = np.min([np.max([date_breakpoints[idx + 2], date_breakpoints[idx + 1] + 10 * 86400]),
                                   date_breakpoints[idx + 1] + 40 * 86400])
                test_periods_seconds[i, :] = np.array([date_bps, date_bpe]).T

            # merge contiguous periods
            lcorrected_test_periods_seconds = []
            i = 0
            while i < test_periods_seconds.shape[0]:
                j = i
                for j in np.arange(i, test_periods_seconds.shape[0] - 1):
                    if test_periods_seconds[j, 1] >= test_periods_seconds[j + 1, 0]:
                        j = j + 1
                    else:
                        break
                lcorrected_test_periods_seconds.append([test_periods_seconds[i, 0], test_periods_seconds[j, 1]])
                i = j + 1

            np_corrected_test_periods_seconds = np.array(lcorrected_test_periods_seconds)

            # convert back to index
            np_corrected_test_periods_index = np.copy(np_corrected_test_periods_seconds)
            t_seconds = at.decyear2seconds(mts.data[:, 0])
            for i in np.arange(np_corrected_test_periods_seconds.shape[0]):
                idxs = np.argmin(np.fabs(t_seconds - np_corrected_test_periods_seconds[i, 0]))
                idxe = np.argmin(np.fabs(t_seconds - np_corrected_test_periods_seconds[i, 1]))
                np_corrected_test_periods_index[i, :] = [idxs, idxe]

            # prepare index list for tests
            index_list = []
            # coarse exploration step = 10 days
            step_days = 10
            for i in np.arange(np_corrected_test_periods_index.shape[0]):
                index_list.append(
                    np.linspace(np_corrected_test_periods_index[i, 0], np_corrected_test_periods_index[i, 1], step_days,
                                dtype=int))

            # fine exploration during suspicious periods - every day

            for i in np.arange(len(H_cp_pb[component])):
                idx = np.where(H_cp[component] == H_cp_pb[component][i])[0][0]
                a = np.arange(H_cp_pb[component][i], H_cp[component][idx + 1] + 1)
                for j in np.arange(len(index_list)):
                    if (a[0] >= index_list[j][0]) and (a[-1] <= index_list[j][-1]):
                        index_list[j] = np.append(index_list[j], a)

                        # sort and unique
            for i in np.arange(len(index_list)):
                index_list[i] = np.sort(np.unique(index_list[i]))

            return index_list

        # refine
        ################################################################################################################
        def refine(mfts, l1ts, lindex, icomponent, min_segment=4):

            # min_segment - minimum number of samples for a segment
            #min_segment = 1

            ic(min_segment)

            H_icomponent = {1: 'N', 2: 'E', 3: 'U'}

            # loop on periods
            for i in np.arange(len(lindex)):
                IMPROVEMENT = False
                np_idx = lindex[i]
                fit_before = np.mean(np.fabs(
                    mfts.data[np_idx[0]:np_idx[-1] + 1, icomponent] - l1ts.data[np_idx[0]:np_idx[-1] + 1,
                                                                      icomponent])) * 1.E3
                rfit_before = fit_before

                t0 = ts.data[np_idx[0], 0]
                y0 = l1ts.data[np_idx[0], icomponent] * 1.E3
                tn = ts.data[np_idx[-1], 0]
                yn = l1ts.data[np_idx[-1], icomponent] * 1.E3
                t = ts.data[np_idx[0]:np_idx[-1] + 1, 0]
                y = mfts.data[np_idx[0]:np_idx[-1] + 1, icomponent] * 1.E3
                VERBOSE("testing period: %s-%s" % (at.decyear2datetime(t0).isoformat()[:10], at.decyear2datetime(tn).isoformat()[:10]))

                y[0] = y0
                y[-1] = yn

                # find optimal 3 segments
                VERBOSE("Finding optimal 3-segments piecewise linear approximation")
                y3_fit = find_optimal_3_segments_pwlf(t, y)

                fit_after = np.mean(np.fabs(mfts.data[np_idx[0]:np_idx[-1] + 1, icomponent] * 1.E3 - y3_fit))
                ic(fit_after)

                if (fit_before - fit_after) > 0 and (rfit_before - fit_after) / rfit_before * 100. > 0:

                    wl1ts.data[np_idx[0]:np_idx[-1] + 1, icomponent] = np.copy(y3_fit) * 1.E-3
                    IMPROVEMENT = True
                    fit_before = fit_after

                if IMPROVEMENT:
                    VERBOSE("period: %s-%s improvement: %.1lf %%" % \
                          (at.decyear2datetime(t0).isoformat()[:10], at.decyear2datetime(tn).isoformat()[:10],
                           (rfit_before - fit_before) / rfit_before * 100.))
                else:
                    VERBOSE("period: %s-%s improvement: NO " % (
                    at.decyear2datetime(t0).isoformat()[:10], at.decyear2datetime(tn).isoformat()[:10]))

                # find optimal 4 segments
                FOUR_SEGMENT = False
                if FOUR_SEGMENT:
                    VERBOSE("Finding optimal 4-segments piecewise linear approximation")
                    y4_fit = find_optimal_4_segments_pwlf(t, y)

                    fit_after = np.mean(np.fabs(mfts.data[np_idx[0]:np_idx[-1] + 1, icomponent] * 1.E3 - y4_fit))
                    ic(fit_after)

                    if (fit_before - fit_after) > 0 and (rfit_before - fit_after) / rfit_before * 100. > 0:

                        wl1ts.data[np_idx[0]:np_idx[-1] + 1, icomponent] = np.copy(y4_fit) * 1.E-3
                        IMPROVEMENT = True
                        fit_before = fit_after

                    if IMPROVEMENT:
                        VERBOSE("period: %s-%s improvement: %.1lf %%" % \
                              (at.decyear2datetime(t0).isoformat()[:10], at.decyear2datetime(tn).isoformat()[:10],
                               (rfit_before - fit_before) / rfit_before * 100.))
                    else:
                        VERBOSE("period: %s-%s improvement: NO " % (
                        at.decyear2datetime(t0).isoformat()[:10], at.decyear2datetime(tn).isoformat()[:10]))

                if pyacs.debug():

                    # plot to see performance
                    import matplotlib.pyplot as plt
                    plt.figure(figsize=(10, 5))
                    plt.title("%s period: %s-%s component %s" %
                              (l1ts.code, at.decyear2datetime(t0).isoformat()[:10], at.decyear2datetime(tn).isoformat()[:10], H_icomponent[icomponent] ))
                    plt.plot(at.decyear2datetime(t), y, 'bo')

                    plt.plot(at.decyear2datetime(t), l1ts.data[np_idx[0]:np_idx[-1]+1, icomponent] * 1.E3, 'r')
                    plt.plot(at.decyear2datetime(t), y3_fit, 'g')
                    plt.xlim( at.decyear2datetime(t0-1/365.25), at.decyear2datetime(tn-1/365.25))
                    plt.show()

            return wl1ts

        ############### MAIN #################################################################

        # compute median filter for statistics
        n_median_filter = np.min([5, ts.data.shape[0]-1])
        if n_median_filter % 2 == 0:
            n_median_filter = n_median_filter - 1
        mfts = ts.median_filter(n=n_median_filter)

        wl1ts = l1ts.copy()

        ic(H_scp)
        ic()
        # EAST COMPONENT
        if 'E' in list( H_scp.keys() ):
            component = 'E'
            icomponent = 2

            VERBOSE("%s component: %s" % (l1ts.code, component))

            # get index_list
            lindex = make_date_index_for_period_test(ts, H_cp, H_scp, component)

            # refine
            wl1ts = refine(mfts, l1ts, lindex, icomponent, min_segment=min_sample_segment_refinement)
            #wl1ts = refine(ts, l1ts, lindex, icomponent, min_segment=min_sample_segment_refinement)
        else:
            VERBOSE("No suspicious periods found for %s component %s" % (l1ts.code, component))

        # NORTH COMPONENT
        if 'N' in list( H_scp.keys()):
            component = 'N'
            icomponent = 1

            VERBOSE("%s component: %s" % (l1ts.code, component))

            # get index_list
            ic(H_cp)
            ic(H_scp)
            lindex = make_date_index_for_period_test(ts, H_cp, H_scp, component)
            ic(lindex)
            # refine
            wl1ts = refine(mfts, l1ts, lindex, icomponent, min_segment=min_sample_segment_refinement)
            #wl1ts = refine(ts, l1ts, lindex, icomponent, min_segment=min_sample_segment_refinement)
        else:
            VERBOSE("No suspicious periods found for %s component %s" % (l1ts.code, component))

        # UP COMPONENT
        if 'U' in list( H_scp.keys()):
            component = 'U'
            icomponent = 3

            VERBOSE("%s component: %s" % (l1ts.code, component))

            # get index_list
            lindex = make_date_index_for_period_test(ts, H_cp, H_scp, component)

            # refine
            wl1ts = refine(mfts, l1ts, lindex, icomponent, min_segment=min_sample_segment_refinement)
            #wl1ts = refine(ts, l1ts, lindex, icomponent, min_segment=min_sample_segment_refinement)

        else:
            VERBOSE("No suspicious periods found for %s component %s" % (l1ts.code, component))

        return wl1ts

    ####################################################################################################################
    # MAIN
    ####################################################################################################################

    # clean l1trend
    VERBOSE("Cleaning l1trend breakpoints for %s" % (self.code))
    #l1ts = self.clean_l1trend(rawts)   # note JMN 10/08/2025: this is a hack to avoid too close breakpoints
    l1ts = self.simplify_l1trend(tolerance=.5, components='NEU')   # note JMN 10/08/2025: this is a hack to avoid too close breakpoints
    #l1ts = self.copy()
    #VERBOSE("Searching suspicious periods for %s" % (self.code))
    
    H_period,H_cp, H_cp_pb = check_l1_trend(rawts, l1ts,
                                            component=lcomponent,
                                            min_samples_per_segment=min_samples_per_segment,
                                            threshold_bias_res_detect=threshold_bias_res_detect,
                                            threshold_vel=threshold_vel)

    #print('H_cp')
    #print(H_cp)

    # Convert H_period decimal years to seconds
    import pyacs.lib.astrotime as at
    H_period_seconds = {}
    for component in H_period.keys():
        H_period_seconds[component] = []
        for period in H_period[component]:
            start_seconds = at.decyear2seconds(period[0])
            end_seconds = at.decyear2seconds(period[1])
            H_period_seconds[component].append([start_seconds, end_seconds])


    # convert H_cp in seconds
    H_cp_seconds = {}
    for component in H_cp.keys():
        H_cp_start_end = l1ts.data[H_cp[component],0]
        
        # Insert l1ts.data[0,0] at the first and l1ts.data[-1,0] at the last element
        import numpy as np
        
        H_cp_start_end = np.insert(H_cp_start_end, 0, l1ts.data[0,0])
        H_cp_start_end = np.insert(H_cp_start_end, -1, l1ts.data[-1,0])
        
        H_cp_seconds[component] = at.decyear2seconds(H_cp_start_end)

    #print('H_cp_seconds')
    #print(H_cp_seconds)

    #print('H_period_seconds')
    #print(H_period_seconds)

    # build H_period_test
    H_period_test = {}
    for component in H_period_seconds.keys():
        H_period_test[component] = []
        for period in H_period_seconds[component]:
            start_seconds = period[0]
            end_seconds = period[1]
            
            # Find the previous and next elements from H_cp_seconds
            cp_seconds = H_cp_seconds[component]
            
            # Find the index of the closest breakpoint before start_seconds
            prev_idx = 0
            for i, cp_time in enumerate(cp_seconds):
                if cp_time < start_seconds:
                    prev_idx = i
                else:
                    break
            
            # Find the index of the closest breakpoint after end_seconds
            next_idx = len(cp_seconds) - 1
            for i, cp_time in enumerate(cp_seconds):
                if cp_time > end_seconds:
                    next_idx = i
                    break
            
            # Replace start and end with previous and next breakpoints
            new_start = cp_seconds[prev_idx]
            new_end = cp_seconds[next_idx]
            
            H_period_test[component].append([new_start, new_end])
    
    #print('H_period_test')
    #print(H_period_test)

    # Merge periods in H_period_test only if corresponding periods in H_period_seconds are contiguous
    H_period_for_test = {}
    for component in H_period_test.keys():
        H_period_for_test[component] = []
        
        if len(H_period_test[component]) == 0:
            continue
            
        # Get corresponding periods from H_period_seconds
        seconds_periods = H_period_seconds[component]
        
        # Sort periods by start time (both H_period_test and seconds periods)
        sorted_test_periods = sorted(H_period_test[component], key=lambda x: x[0])
        sorted_seconds_periods = sorted(seconds_periods, key=lambda x: x[0])
        
        # Initialize with the first period
        merged_periods = [sorted_test_periods[0]]
        merged_seconds_indices = [0]  # Track which seconds periods are merged
        
        # Check each subsequent period for contiguity in H_period_seconds
        for i, current_test_period in enumerate(sorted_test_periods[1:], 1):
            last_merged = merged_periods[-1]
            last_seconds_idx = merged_seconds_indices[-1]
            
            # Check if corresponding periods in H_period_seconds are contiguous
            # Two periods are contiguous if: current_start == last_end (exactly adjacent)
            # Add a small tolerance for floating point precision
            tolerance = 1e-6  # 1 microsecond tolerance in seconds
            
            current_seconds_period = sorted_seconds_periods[i]
            last_seconds_period = sorted_seconds_periods[last_seconds_idx]
            
            if abs(current_seconds_period[0] - last_seconds_period[1]) <= tolerance:
                # Seconds periods are contiguous, merge the test periods
                merged_periods[-1] = [last_merged[0], current_test_period[1]]
                merged_seconds_indices[-1] = i  # Update to the latest merged index
            else:
                # Seconds periods are not contiguous, add as new period
                merged_periods.append(current_test_period)
                merged_seconds_indices.append(i)
        
        H_period_for_test[component] = merged_periods
    
    #print('H_period_for_test (merged)')
    #print(H_period_for_test)

    #H_period_for_test = H_period_test

    VERBOSE("Refining l1trend results using the new strategy for %s" % (self.code))

    # Copy l1ts to refine_l1ts for refinement
    refine_l1ts = l1ts.copy()
    
    # Convert l1ts.data[:,0] from decimal year to seconds
    t_seconds = at.decyear2seconds(l1ts.data[:,0])
    
    # Process each component
    for component in H_period_for_test.keys():
        if len(H_period_for_test[component]) == 0:
            VERBOSE("No test periods for component %s" % component)
            continue
            
        VERBOSE("Processing component %s with %d test periods" % (component, len(H_period_for_test[component])))
        
        # Get component index
        comp_idx = {'N': 1, 'E': 2, 'U': 3}[component]
        
        for i, period in enumerate(H_period_for_test[component]):
            start_seconds = period[0]
            end_seconds = period[1]
            
            # Convert seconds to datetime for human-readable output
            start_dt = at.seconds2datetime(start_seconds)
            end_dt = at.seconds2datetime(end_seconds)
            VERBOSE("Processing period %d/%d for component %s: [%s, %s]" % 
                   (i+1, len(H_period_for_test[component]), component, 
                    start_dt.isoformat()[:19], end_dt.isoformat()[:19]))
            
            # Extract time window corresponding to the tested period
            # Find indices where time is within the period
            mask = (t_seconds >= start_seconds) & (t_seconds <= end_seconds)
            period_indices = np.where(mask)[0]
            
            if len(period_indices) < 3:
                VERBOSE("Period too short, skipping")
                continue
                
            # Extract data for the time window
            t_period = t_seconds[period_indices]
            y_period = rawts.data[period_indices, comp_idx] * 1E3  # Convert to mm
            l1_period = l1ts.data[period_indices, comp_idx] * 1E3  # Convert to mm
            
            # Get start and end values from l1ts
            y0 = l1_period[0]
            yn = l1_period[-1]
            
            VERBOSE("Time window: %d points, start: %.3f mm, end: %.3f mm" % 
                   (len(period_indices), y0, yn))
            
            # Compute number of breakpoints in l1ts for that time window/component
            # Get breakpoints for the component
            bp_dates = H_cp_seconds[component]
            
            bp_values = l1ts.data[H_cp[component], comp_idx]

            # Find the indexes in t_seconds corresponding to bp_dates
            bp_indices = []
            for bp_time in bp_dates:
                # Find the closest index in t_seconds
                closest_idx = np.argmin(np.abs(t_seconds - bp_time))
                bp_indices.append(closest_idx)

            bp_values = l1ts.data[bp_indices, comp_idx]


            # Find breakpoints within the period
            period_bp_indices = []
            for i, bp_idx in enumerate(bp_indices):
                if bp_idx >= period_indices[0] and bp_idx <= period_indices[-1]:
                    period_bp_indices.append(i)
            
            period_bp_dates = bp_dates[period_bp_indices]
            period_bp_values = bp_values[period_bp_indices]
            
            nbp = len(period_bp_dates) - 2  # Exclude start and end points
            VERBOSE("Number of breakpoints in period: %d" % nbp)
            
            if nbp <= 0:
                VERBOSE("No breakpoints to refine, skipping")
                continue
                
            # Limit nbp for performance - exhaustive search becomes too slow for n>=4
            max_nbp = 3  # Limit to 3 breakpoints for reasonable performance
            if nbp > max_nbp:
                VERBOSE("Too many breakpoints (%d), limiting to %d for performance" % (nbp, max_nbp))
                nbp = max_nbp
                
            # Run optimal_pwlf_refinement (use fast version for nbp > 3)
            try:
                if nbp <= 3 and len(period_indices) < 100:
                    VERBOSE("Running optimal_pwlf_refinement (exhaustive search) with %d breakpoints" % nbp)
                    optimal_bp, optimal_vals, min_error = optimal_pwlf_refinement(t_period, y_period, y0, yn, nbp)
                else:
                    VERBOSE("Running optimal_pwlf_refinement_fast because exhaustive search would be too slow with %d breakpoints and %d points" % (nbp, len(period_indices)))
                    optimal_bp, optimal_vals, min_error = optimal_pwlf_refinement_fast(t_period, y_period, y0, yn)
            except Exception as e:
                VERBOSE("Error in optimal_pwlf_refinement: %s" % str(e))
                continue
                
            # Calculate error for original l1ts in this period
            original_error = np.sum((y_period - l1_period)**2)
            
            VERBOSE("Original error: %.6f, Optimal error: %.6f" % (original_error, min_error))
            
            # Test if optimal_pwlf_refinement significantly improves fit
            improvement_ratio = original_error / min_error if min_error > 0 else float('inf')
            significant_improvement = improvement_ratio > 1.1  # 10% improvement threshold
            
            if significant_improvement:
                VERBOSE("Significant improvement detected (ratio: %.2f), updating refine_l1ts" % improvement_ratio)
                
                # Interpolate optimal solution back to the period indices
                optimal_interp = np.interp(t_period, optimal_bp, optimal_vals)
                
                # Insert optimal solution into refine_l1ts
                refine_l1ts.data[period_indices, comp_idx] = optimal_interp / 1E3  # Convert back to m
                
                VERBOSE("Successfully updated refine_l1ts for period %d" % (i+1))
            else:
                VERBOSE("No significant improvement (ratio: %.2f), keeping original" % improvement_ratio)
                
#        except Exception as e:
#            VERBOSE("Error in optimal_pwlf_refinement: %s" % str(e))
#            continue
    
    VERBOSE("Refinement completed for %s" % (self.code))

    return refine_l1ts

    rts = refine_l1trend_suspect_periods( rawts, l1ts , H_cp, H_cp_pb, norm='L2',
                                          min_sample_segment_refinement=min_sample_segment_refinement)

    if output == 'ts':
        return rts
    if output == 'both':
        return rts, H_period, H_cp, H_cp_pb
    if output == 'info':
        return H_period, H_cp, H_cp_pb

#############################################################################################################################
def simplify_l1trend(self, tolerance=1.0, components='ENU'):
#############################################################################################################################
    """
    Remove unnecessary breakpoints from an L1-trend filtered time series.
    
    This function iteratively removes breakpoints and tests if the simplified model
    still fits the original time series within a specified tolerance.
    
    Parameters
    ----------
    tolerance : float
        Maximum allowed difference (in mm) between original and simplified model.
        Default is 1.0 mm.
    components : str
        Components to process. Default is 'ENU'.
        
    Returns
    -------
    pyacs.gts.Gts.Gts
        Simplified Gts object with unnecessary breakpoints removed.
    """
    
    import numpy as np
    from pyacs.gts.Gts import Gts
    
    # Convert tolerance from mm to m for consistency with PYACS Gts format 
    tolerance_m = tolerance / 1000.0
    
    # Get breakpoints from the current L1-trend
    bp = self.l1trend_to_breakpoints(tol=0.1)
    
    # Initialize new data array
    new_data = np.zeros_like(self.data)
    new_data[:,0] = self.data[:,0]  # Copy dates
    new_data[:,4:8] = self.data[:,4:8]  # Copy uncertainties
    
    # Process each component
    for comp in components:
        if comp not in ['N', 'E', 'U']:
            continue
            
        comp_idx = {'N': 1, 'E': 2, 'U': 3}[comp]
        
        # Get breakpoints for this component
        bp_dates = bp[comp][0]
        bp_values = bp[comp][1]
        
        if len(bp_dates) <= 2:  # Only start and end points
            # No breakpoints to simplify, just interpolate
            new_data[:, comp_idx] = np.interp(new_data[:,0], bp_dates, bp_values)
            continue
        
        # Start with all breakpoints
        current_dates = bp_dates.copy()
        current_values = bp_values.copy()
        
        # Iteratively remove breakpoints (except first and last)
        removed_any = True
        while removed_any and len(current_dates) > 2:
            removed_any = False
            
            # Try removing each breakpoint (except first and last)
            for i in range(1, len(current_dates) - 1):
                # Create test breakpoints without the current breakpoint
                test_dates = np.delete(current_dates, i)
                test_values = np.delete(current_values, i)
                
                # Interpolate test model on original dates
                test_interp = np.interp(self.data[:,0], test_dates, test_values)
                
                # Compare with original L1-trend values
                original_values = self.data[:, comp_idx]
                max_diff = np.max(np.abs(test_interp - original_values))
                
                # If within tolerance, remove this breakpoint
                if max_diff <= tolerance_m:
                    current_dates = test_dates
                    current_values = test_values
                    removed_any = True
                    break  # Start over with the new set of breakpoints
        
        # Interpolate final simplified breakpoints on original dates
        new_data[:, comp_idx] = np.interp(new_data[:,0], current_dates, current_values)
    
    # Create new Gts object
    simplified_gts = Gts(code=self.code, data=new_data)
    
    return simplified_gts

#############################################################################################################################
def optimal_pwlf_refinement(t, y, y0, yn, nbp):
#############################################################################################################################
    """
    Find the optimal piecewise linear function with nbp breakpoints fitting y.
    
    The function finds the optimal piecewise linear function (opwlf) fitting y with 
    nbp breakpoints according to the L2 norm. The obtained optimal piecewise linear 
    function verifies opwlf[0]=y0 and opwlf[-1]=yn, that is end and starting point 
    of y are kept fixed.
    
    The problem is applied to small dimension (n<=6), so that a systematic search 
    can be performed and does not require complex optimization approaches.
    
    Parameters
    ----------
    t : numpy.ndarray
        Time array expressed in integer seconds
    y : numpy.ndarray
        Values of the function to fit
    y0 : float
        Value of the function at t[0] (fixed)
    yn : float
        Value of the function at t[-1] (fixed)
    nbp : int
        Number of breakpoints (excluding start and end points)
        
    Returns
    -------
    tuple
        (optimal_breakpoints, optimal_values, min_error)
        - optimal_breakpoints: array of breakpoint times
        - optimal_values: array of function values at breakpoints
        - min_error: minimum L2 error achieved
    """
    
    import numpy as np
    from itertools import combinations
    
    n = len(t)
    
    if n <= 2:
        # No breakpoints possible, return start and end points
        return np.array([t[0], t[-1]]), np.array([y0, yn]), np.sum((y - np.linspace(y0, yn, n))**2)
    
    if nbp >= n - 1:
        # Too many breakpoints, use all points
        return t, y, 0.0
    
    # Generate all possible combinations of breakpoint positions
    # We need to choose nbp positions from the interior points (excluding first and last)
    interior_indices = list(range(1, n-1))
    
    if len(interior_indices) < nbp:
        # Not enough interior points, use all available
        nbp = len(interior_indices)
    
    min_error = float('inf')
    optimal_breakpoints = None
    optimal_values = None
    
    # Try all combinations of breakpoint positions
    for bp_indices in combinations(interior_indices, nbp):
        # Sort breakpoint indices
        bp_indices = sorted(bp_indices)
        
        # Create breakpoint array including start and end points
        bp_times = np.array([t[0]] + [t[i] for i in bp_indices] + [t[-1]])
        
        # For each combination, we need to find the optimal values at breakpoints
        # that minimize the L2 error while keeping y0 and yn fixed
        
        # The problem can be solved using linear algebra
        # We'll solve for the interior breakpoint values
        
        if nbp == 0:
            # No interior breakpoints, just linear interpolation
            pwlf_values = np.linspace(y0, yn, n)
            error = np.sum((y - pwlf_values)**2)
            
            if error < min_error:
                min_error = error
                optimal_breakpoints = bp_times
                optimal_values = np.array([y0, yn])
                
        else:
            # We need to solve for the interior breakpoint values
            # The system is overdetermined, so we'll use least squares
            
            # Create the system matrix
            # Each segment contributes equations: y = a*t + b
            # where a and b are determined by the breakpoint values
            
            A = np.zeros((n, nbp))
            b = np.zeros(n)
            
            # Fill the matrix and vector
            for i in range(n):
                # Find which segment t[i] belongs to
                segment_idx = 0
                for j in range(len(bp_times) - 1):
                    if bp_times[j] <= t[i] <= bp_times[j + 1]:
                        segment_idx = j
                        break
                
                if segment_idx == 0:
                    # First segment: y = y0 + (bp1 - y0)/(t1 - t0) * (t - t0)
                    if nbp > 0:
                        A[i, 0] = (t[i] - t[0]) / (bp_times[1] - t[0])
                    b[i] = y0 + (t[i] - t[0]) / (bp_times[1] - t[0]) * (0 - y0)
                elif segment_idx == len(bp_times) - 2:
                    # Last segment: y = bp_n + (yn - bp_n)/(tn - t_n) * (t - t_n)
                    if nbp > 0:
                        A[i, -1] = 1 - (t[i] - bp_times[-2]) / (bp_times[-1] - bp_times[-2])
                    b[i] = yn + (t[i] - bp_times[-2]) / (bp_times[-1] - bp_times[-2]) * (0 - yn)
                else:
                    # Middle segment: y = bp_j + (bp_{j+1} - bp_j)/(t_{j+1} - t_j) * (t - t_j)
                    bp_idx = segment_idx - 1  # Index in interior breakpoints
                    if bp_idx < nbp - 1:
                        A[i, bp_idx] = 1 - (t[i] - bp_times[segment_idx]) / (bp_times[segment_idx + 1] - bp_times[segment_idx])
                        A[i, bp_idx + 1] = (t[i] - bp_times[segment_idx]) / (bp_times[segment_idx + 1] - bp_times[segment_idx])
                    else:
                        A[i, bp_idx] = 1 - (t[i] - bp_times[segment_idx]) / (bp_times[segment_idx + 1] - bp_times[segment_idx])
            
            # Solve the least squares problem
            try:
                interior_values = np.linalg.lstsq(A, y - b, rcond=None)[0]
                
                # Reconstruct the full piecewise linear function
                pwlf_values = np.zeros(n)
                for i in range(n):
                    # Find which segment t[i] belongs to
                    segment_idx = 0
                    for j in range(len(bp_times) - 1):
                        if bp_times[j] <= t[i] <= bp_times[j + 1]:
                            segment_idx = j
                            break
                    
                    if segment_idx == 0:
                        # First segment
                        if nbp > 0:
                            pwlf_values[i] = y0 + (interior_values[0] - y0) * (t[i] - t[0]) / (bp_times[1] - t[0])
                        else:
                            pwlf_values[i] = y0 + (yn - y0) * (t[i] - t[0]) / (bp_times[1] - t[0])
                    elif segment_idx == len(bp_times) - 2:
                        # Last segment
                        if nbp > 0:
                            pwlf_values[i] = interior_values[-1] + (yn - interior_values[-1]) * (t[i] - bp_times[-2]) / (bp_times[-1] - bp_times[-2])
                        else:
                            pwlf_values[i] = y0 + (yn - y0) * (t[i] - t[0]) / (bp_times[-1] - t[0])
                    else:
                        # Middle segment
                        bp_idx = segment_idx - 1
                        if bp_idx < nbp - 1:
                            pwlf_values[i] = interior_values[bp_idx] + (interior_values[bp_idx + 1] - interior_values[bp_idx]) * (t[i] - bp_times[segment_idx]) / (bp_times[segment_idx + 1] - bp_times[segment_idx])
                        else:
                            pwlf_values[i] = interior_values[bp_idx] + (yn - interior_values[bp_idx]) * (t[i] - bp_times[segment_idx]) / (bp_times[-1] - bp_times[segment_idx])
                
                # Calculate error
                error = np.sum((y - pwlf_values)**2)
                
                if error < min_error:
                    min_error = error
                    optimal_breakpoints = bp_times
                    optimal_values = np.array([y0] + list(interior_values) + [yn])
                    
            except np.linalg.LinAlgError:
                # Skip this combination if the system is singular
                continue
    
    return optimal_breakpoints, optimal_values, min_error

#############################################################################################################################
def optimal_pwlf_refinement_fast(t, y, y0, yn):
#############################################################################################################################
    """
    Fast version of optimal_pwlf_refinement using l1trendi with criterion AICc.
    
    Parameters
    ----------
    t : numpy.ndarray
        Time array expressed in integer seconds
    y : numpy.ndarray
        Values of the function to fit
    y0 : float
        Value of the function at t[0] (fixed)
    yn : float
        Value of the function at t[-1] (fixed)
        
    Returns
    -------
    tuple
        (optimal_breakpoints, optimal_values, min_error)
    """

    # import
    import numpy as np
    import pyacs.lib.astrotime as at
    
    # create a fake Gts object  
    from pyacs.gts.Gts import Gts
    fake_data = np.ones((len(t), 10)) * 1.E-3 # mm
    fake_data[:,0] = at.datetime2decyear(at.seconds2datetime(t))
    fake_data[:,1] = y * 1E-3 # mm
    fake_code = ("fake [%s-%s] [%.2lf - %.2lf]" % (at.seconds2datetime(t[0]).isoformat()[:19], at.seconds2datetime(t[-1]).isoformat()[:19], y0, yn))
    fake_gts = Gts(code=fake_code, data=fake_data)

    # run l1trendi with criterion AICc
    l1ts = fake_gts.l1trendi(criterion='AICc', lcomponent='N')

    # simplify l1ts
    l1ts = l1ts.simplify_l1trend(tolerance=.5, components='N')

    # run refine_l1trend
    l1ts = l1ts.refine_l1trend(rawts=fake_gts, lcomponent='N')

    # get the breakpoints
    breakpoints = l1ts.l1trend_to_breakpoints(tol=0.5)['N']

    # get the breakpoints times
    breakpoints_times = at.decyear2seconds(breakpoints)

    # get the breakpoints values
    breakpoints_values = l1ts.data[breakpoints,1] * 1E-3 # mm

    # replace the first and last breakpoints with y0 and yn
    breakpoints_values[0] = y0
    breakpoints_values[-1] = yn

    # compute min_error
    min_error = np.sum((y - l1ts.data[:,1]*1E-3)**2)

    # return
    return breakpoints_times, breakpoints_values, min_error
