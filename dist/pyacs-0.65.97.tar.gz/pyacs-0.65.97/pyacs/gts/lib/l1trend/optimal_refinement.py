"""
Optimal piecewise linear function refinement algorithms.
"""

import numpy as np
from itertools import combinations
import pyacs.lib.astrotime as at
from pyacs.gts.Gts import Gts


def optimal_pwlf_refinement(t, y, y0, yn, nbp):
    """
    Find the optimal piecewise linear function with nbp breakpoints fitting y.
    
    The function finds the optimal piecewise linear function (opwlf) fitting y with 
    nbp breakpoints according to the L2 norm. The obtained optimal piecewise linear 
    function verifies opwlf[0]=y0 and opwlf[-1]=yn, that is end and starting point 
    of y are kept fixed.
    
    The problem is applied to small dimension (n<=6), so that a systematic search 
    can be performed and does not require complex optimization approaches.
    
    Parameters
    ----------
    t : numpy.ndarray
        Time array expressed in integer seconds
    y : numpy.ndarray
        Values of the function to fit
    y0 : float
        Value of the function at t[0] (fixed)
    yn : float
        Value of the function at t[-1] (fixed)
    nbp : int
        Number of breakpoints (excluding start and end points)
        
    Returns
    -------
    tuple
        (optimal_breakpoints, optimal_values, min_error)
        - optimal_breakpoints: array of breakpoint times
        - optimal_values: array of function values at breakpoints
        - min_error: minimum L2 error achieved
    """
    
    n = len(t)
    
    if n <= 2:
        # No breakpoints possible, return start and end points
        return np.array([t[0], t[-1]]), np.array([y0, yn]), np.sum((y - np.linspace(y0, yn, n))**2)
    
    if nbp >= n - 1:
        # Too many breakpoints, use all points
        return t, y, 0.0
    
    # Generate all possible combinations of breakpoint positions
    # We need to choose nbp positions from the interior points (excluding first and last)
    interior_indices = list(range(1, n-1))
    
    if len(interior_indices) < nbp:
        # Not enough interior points, use all available
        nbp = len(interior_indices)
    
    min_error = float('inf')
    optimal_breakpoints = None
    optimal_values = None
    
    # Try all combinations of breakpoint positions
    for bp_indices in combinations(interior_indices, nbp):
        # Sort breakpoint indices
        bp_indices = sorted(bp_indices)
        
        # Create breakpoint array including start and end points
        bp_times = np.array([t[0]] + [t[i] for i in bp_indices] + [t[-1]])
        
        # For each combination, we need to find the optimal values at breakpoints
        # that minimize the L2 error while keeping y0 and yn fixed
        
        # The problem can be solved using linear algebra
        # We'll solve for the interior breakpoint values
        
        if nbp == 0:
            # No interior breakpoints, just linear interpolation
            pwlf_values = np.linspace(y0, yn, n)
            error = np.sum((y - pwlf_values)**2)
            
            if error < min_error:
                min_error = error
                optimal_breakpoints = bp_times
                optimal_values = np.array([y0, yn])
                
        else:
            # We need to solve for the interior breakpoint values
            # The system is overdetermined, so we'll use least squares
            
            # Create the system matrix
            # Each segment contributes equations: y = a*t + b
            # where a and b are determined by the breakpoint values
            
            A = np.zeros((n, nbp))
            b = np.zeros(n)
            
            # Fill the matrix and vector
            for i in range(n):
                # Find which segment t[i] belongs to
                segment_idx = 0
                for j in range(len(bp_times) - 1):
                    if bp_times[j] <= t[i] <= bp_times[j + 1]:
                        segment_idx = j
                        break
                
                if segment_idx == 0:
                    # First segment: y = y0 + (bp1 - y0)/(t1 - t0) * (t - t0)
                    if nbp > 0:
                        A[i, 0] = (t[i] - t[0]) / (bp_times[1] - t[0])
                    b[i] = y0 + (t[i] - t[0]) / (bp_times[1] - t[0]) * (0 - y0)
                elif segment_idx == len(bp_times) - 2:
                    # Last segment: y = bp_n + (yn - bp_n)/(tn - t_n) * (t - t_n)
                    if nbp > 0:
                        A[i, -1] = 1 - (t[i] - bp_times[-2]) / (bp_times[-1] - bp_times[-2])
                    b[i] = yn + (t[i] - bp_times[-2]) / (bp_times[-1] - bp_times[-2]) * (0 - yn)
                else:
                    # Middle segment: y = bp_j + (bp_{j+1} - bp_j)/(t_{j+1} - t_j) * (t - t_j)
                    bp_idx = segment_idx - 1  # Index in interior breakpoints
                    if bp_idx < nbp - 1:
                        A[i, bp_idx] = 1 - (t[i] - bp_times[segment_idx]) / (bp_times[segment_idx + 1] - bp_times[segment_idx])
                        A[i, bp_idx + 1] = (t[i] - bp_times[segment_idx]) / (bp_times[segment_idx + 1] - bp_times[segment_idx])
                    else:
                        A[i, bp_idx] = 1 - (t[i] - bp_times[segment_idx]) / (bp_times[segment_idx + 1] - bp_times[segment_idx])
            
            # Solve the least squares problem
            try:
                interior_values = np.linalg.lstsq(A, y - b, rcond=None)[0]
                
                # Reconstruct the full piecewise linear function
                pwlf_values = np.zeros(n)
                for i in range(n):
                    # Find which segment t[i] belongs to
                    segment_idx = 0
                    for j in range(len(bp_times) - 1):
                        if bp_times[j] <= t[i] <= bp_times[j + 1]:
                            segment_idx = j
                            break
                    
                    if segment_idx == 0:
                        # First segment
                        if nbp > 0:
                            pwlf_values[i] = y0 + (interior_values[0] - y0) * (t[i] - t[0]) / (bp_times[1] - t[0])
                        else:
                            pwlf_values[i] = y0 + (yn - y0) * (t[i] - t[0]) / (bp_times[1] - t[0])
                    elif segment_idx == len(bp_times) - 2:
                        # Last segment
                        if nbp > 0:
                            pwlf_values[i] = interior_values[-1] + (yn - interior_values[-1]) * (t[i] - bp_times[-2]) / (bp_times[-1] - bp_times[-2])
                        else:
                            pwlf_values[i] = y0 + (yn - y0) * (t[i] - t[0]) / (bp_times[-1] - t[0])
                    else:
                        # Middle segment
                        bp_idx = segment_idx - 1
                        if bp_idx < nbp - 1:
                            pwlf_values[i] = interior_values[bp_idx] + (interior_values[bp_idx + 1] - interior_values[bp_idx]) * (t[i] - bp_times[segment_idx]) / (bp_times[segment_idx + 1] - bp_times[segment_idx])
                        else:
                            pwlf_values[i] = interior_values[bp_idx] + (yn - interior_values[bp_idx]) * (t[i] - bp_times[segment_idx]) / (bp_times[-1] - bp_times[segment_idx])
                
                # Calculate error
                error = np.sum((y - pwlf_values)**2)
                
                if error < min_error:
                    min_error = error
                    optimal_breakpoints = bp_times
                    optimal_values = np.array([y0] + list(interior_values) + [yn])
                    
            except np.linalg.LinAlgError:
                # Skip this combination if the system is singular
                continue
    
    return optimal_breakpoints, optimal_values, min_error


def optimal_pwlf_refinement_fast(t, y, y0, yn):
    """
    Fast version of optimal_pwlf_refinement using l1trendi with criterion AICc.
    
    Parameters
    ----------
    t : numpy.ndarray
        Time array expressed in integer seconds
    y : numpy.ndarray
        Values of the function to fit
    y0 : float
        Value of the function at t[0] (fixed)
    yn : float
        Value of the function at t[-1] (fixed)
        
    Returns
    -------
    tuple
        (optimal_breakpoints, optimal_values, min_error)
    """

    # create a fake Gts object  
    fake_data = np.ones((len(t), 10)) * 1.E-3 # mm
    fake_data[:,0] = at.datetime2decyear(at.seconds2datetime(t))
    fake_data[:,1] = y * 1E-3 # mm
    fake_code = ("fake [%s-%s] [%.2lf - %.2lf]" % (at.seconds2datetime(t[0]).isoformat()[:19], at.seconds2datetime(t[-1]).isoformat()[:19], y0, yn))
    fake_gts = Gts(code=fake_code, data=fake_data)

    # run l1trendi with criterion AICc
    l1ts = fake_gts.l1trendi(criterion='AICc', lcomponent='N')

    # simplify l1ts
    l1ts = l1ts.simplify_l1trend(tolerance=.5, components='N')

    # run refine_l1trend
    l1ts = l1ts.refine_l1trend(rawts=fake_gts, lcomponent='N')

    # get the breakpoints
    breakpoints = l1ts.l1trend_to_breakpoints(tol=0.5)['N']

    # get the breakpoints times
    breakpoints_times = at.decyear2seconds(breakpoints)

    # get the breakpoints values
    breakpoints_values = l1ts.data[breakpoints,1] * 1E-3 # mm

    # replace the first and last breakpoints with y0 and yn
    breakpoints_values[0] = y0
    breakpoints_values[-1] = yn

    # compute min_error
    min_error = np.sum((y - l1ts.data[:,1]*1E-3)**2)

    # return
    return breakpoints_times, breakpoints_values, min_error
