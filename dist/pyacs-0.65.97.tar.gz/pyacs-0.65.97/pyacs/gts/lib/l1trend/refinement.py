"""
Main refinement function for L1-trend analysis.
"""

import numpy as np
import pyacs.lib.astrotime as at
from pyacs.gts.Gts import Gts
from pyacs.message import VERBOSE
from .check_trend import check_l1_trend
from .optimal_refinement import optimal_pwlf_refinement, optimal_pwlf_refinement_fast


def refine_l1trend(self, rawts, lcomponent='ENU', min_samples_per_segment=10, 
                   threshold_bias_res_detect=10, threshold_vel=8, 
                   min_sample_segment_refinement=1, norm='L2', output='ts'):
    """
    Refine results from l1trend by optimizing the date of breakpoints for suspected periods.
    The algorithm first identifies periods where the l1trend model might be improved.
    For every candidate period, the algorithm checks different metrics to decide if the model should be refined.
    Finally, for the selected periods, it optimizes the date of breakpoints.

    Parameters
    ----------
    rawts : pyacs.gts.Gts.Gts
        Raw time series, originally processed by l1trend
    lcomponent : str
        Component to refine (default: 'ENU')
    min_samples_per_segment : int
        Minimum number of samples for a segment to be considered as a candidate
        for improvement (default: 10)
    threshold_bias_res_detect : float
        Threshold to detect bias residuals (default: 10)
    threshold_vel : float
        Threshold to detect high velocities (default: 8)
    min_sample_segment_refinement : int
        Minimum number of samples for a segment in the refined model (default: 1)
    norm : str
        Norm to be minimized for improvement (default: 'L2')
    output : str
        Output type 'ts' for the refined Gts, 'info' for the periods suspected, 
        'both' for both (default: 'ts')

    Returns
    -------
    pyacs.gts.Gts.Gts or tuple
        Refined Gts object or information about suspected periods
    """

    VERBOSE("----------------------------------------------------------")
    VERBOSE("Refining l1trend results using the new strategy for %s" % (self.code))
    VERBOSE("----------------------------------------------------------")
    VERBOSE("Parameters used for refinement")
    VERBOSE("min_samples_per_segment: %d" % min_samples_per_segment)
    VERBOSE("threshold_bias_res_detect: %d" % threshold_bias_res_detect)
    VERBOSE("threshold_vel: %d" % threshold_vel)
    VERBOSE("min_sample_segment_refinement: %d" % min_sample_segment_refinement)
    VERBOSE("norm: %s" % norm)
    VERBOSE("----------------------------------------------------------")

    # Simplify l1trend first
    VERBOSE("Cleaning l1trend breakpoints for %s" % (self.code))
    l1ts = self.simplify_l1trend(tolerance=.5, components='NEU')

    # Check for suspicious periods
    H_period, H_cp, H_cp_pb = check_l1_trend(rawts, l1ts,
                                            component=lcomponent,
                                            min_samples_per_segment=min_samples_per_segment,
                                            threshold_bias_res_detect=threshold_bias_res_detect,
                                            threshold_vel=threshold_vel)

    # Convert H_period decimal years to seconds
    H_period_seconds = {}
    for component in H_period.keys():
        H_period_seconds[component] = []
        for period in H_period[component]:
            start_seconds = at.decyear2seconds(period[0])
            end_seconds = at.decyear2seconds(period[1])
            H_period_seconds[component].append([start_seconds, end_seconds])

    # Convert H_cp to seconds
    H_cp_seconds = {}
    for component in H_cp.keys():
        H_cp_start_end = l1ts.data[H_cp[component],0]
        
        # Insert l1ts.data[0,0] at the first and l1ts.data[-1,0] at the last element
        H_cp_start_end = np.insert(H_cp_start_end, 0, l1ts.data[0,0])
        H_cp_start_end = np.insert(H_cp_start_end, -1, l1ts.data[-1,0])
        
        H_cp_seconds[component] = at.decyear2seconds(H_cp_start_end)

    # Build H_period_test
    H_period_test = {}
    for component in H_period_seconds.keys():
        H_period_test[component] = []
        for period in H_period_seconds[component]:
            start_seconds = period[0]
            end_seconds = period[1]
            
            # Find the previous and next elements from H_cp_seconds
            cp_seconds = H_cp_seconds[component]
            
            # Find the index of the closest breakpoint before start_seconds
            prev_idx = 0
            for i, cp_time in enumerate(cp_seconds):
                if cp_time < start_seconds:
                    prev_idx = i
                else:
                    break
            
            # Find the index of the closest breakpoint after end_seconds
            next_idx = len(cp_seconds) - 1
            for i, cp_time in enumerate(cp_seconds):
                if cp_time > end_seconds:
                    next_idx = i
                    break
            
            # Replace start and end with previous and next breakpoints
            new_start = cp_seconds[prev_idx]
            new_end = cp_seconds[next_idx]
            
            H_period_test[component].append([new_start, new_end])

    # Merge periods in H_period_test only if corresponding periods in H_period_seconds are contiguous
    H_period_for_test = {}
    for component in H_period_test.keys():
        H_period_for_test[component] = []
        
        if len(H_period_test[component]) == 0:
            continue
            
        # Get corresponding periods from H_period_seconds
        seconds_periods = H_period_seconds[component]
        
        # Sort periods by start time (both H_period_test and seconds periods)
        sorted_test_periods = sorted(H_period_test[component], key=lambda x: x[0])
        sorted_seconds_periods = sorted(seconds_periods, key=lambda x: x[0])
        
        # Initialize with the first period
        merged_periods = [sorted_test_periods[0]]
        merged_seconds_indices = [0]  # Track which seconds periods are merged
        
        # Check each subsequent period for contiguity in H_period_seconds
        for i, current_test_period in enumerate(sorted_test_periods[1:], 1):
            last_merged = merged_periods[-1]
            last_seconds_idx = merged_seconds_indices[-1]
            
            # Check if corresponding periods in H_period_seconds are contiguous
            tolerance = 1e-6  # 1 microsecond tolerance in seconds
            
            current_seconds_period = sorted_seconds_periods[i]
            last_seconds_period = sorted_seconds_periods[last_seconds_idx]
            
            if abs(current_seconds_period[0] - last_seconds_period[1]) <= tolerance:
                # Seconds periods are contiguous, merge the test periods
                merged_periods[-1] = [last_merged[0], current_test_period[1]]
                merged_seconds_indices[-1] = i  # Update to the latest merged index
            else:
                # Seconds periods are not contiguous, add as new period
                merged_periods.append(current_test_period)
                merged_seconds_indices.append(i)
        
        H_period_for_test[component] = merged_periods

    # Copy l1ts to refine_l1ts for refinement
    refine_l1ts = l1ts.copy()
    
    # Convert l1ts.data[:,0] from decimal year to seconds
    t_seconds = at.decyear2seconds(l1ts.data[:,0])
    
    # Process each component
    for component in H_period_for_test.keys():
        if len(H_period_for_test[component]) == 0:
            VERBOSE("No test periods for component %s" % component)
            continue
            
        VERBOSE("Processing component %s with %d test periods" % (component, len(H_period_for_test[component])))
        
        # Get component index
        comp_idx = {'N': 1, 'E': 2, 'U': 3}[component]
        
        for i, period in enumerate(H_period_for_test[component]):
            start_seconds = period[0]
            end_seconds = period[1]
            
            # Convert seconds to datetime for human-readable output
            start_dt = at.seconds2datetime(start_seconds)
            end_dt = at.seconds2datetime(end_seconds)
            VERBOSE("Processing period %d/%d for component %s: [%s, %s]" % 
                   (i+1, len(H_period_for_test[component]), component, 
                    start_dt.isoformat()[:19], end_dt.isoformat()[:19]))
            
            # Extract time window corresponding to the tested period
            mask = (t_seconds >= start_seconds) & (t_seconds <= end_seconds)
            period_indices = np.where(mask)[0]
            
            if len(period_indices) < 3:
                VERBOSE("Period too short, skipping")
                continue
                
            # Extract data for the time window
            t_period = t_seconds[period_indices]
            y_period = rawts.data[period_indices, comp_idx] * 1E3  # Convert to mm
            l1_period = l1ts.data[period_indices, comp_idx] * 1E3  # Convert to mm
            
            # Get start and end values from l1ts
            y0 = l1_period[0]
            yn = l1_period[-1]
            
            VERBOSE("Time window: %d points, start: %.3f mm, end: %.3f mm" % 
                   (len(period_indices), y0, yn))
            
            # Find the indexes in t_seconds corresponding to bp_dates
            bp_dates = H_cp_seconds[component]
            bp_indices = []
            for bp_time in bp_dates:
                # Find the closest index in t_seconds
                closest_idx = np.argmin(np.abs(t_seconds - bp_time))
                bp_indices.append(closest_idx)

            bp_values = l1ts.data[bp_indices, comp_idx]

            # Find breakpoints within the period
            period_bp_indices = []
            for i, bp_idx in enumerate(bp_indices):
                if bp_idx >= period_indices[0] and bp_idx <= period_indices[-1]:
                    period_bp_indices.append(i)
            
            period_bp_dates = bp_dates[period_bp_indices]
            period_bp_values = bp_values[period_bp_indices]
            
            nbp = len(period_bp_dates) - 2  # Exclude start and end points
            VERBOSE("Number of breakpoints in period: %d" % nbp)
            
            if nbp <= 0:
                VERBOSE("No breakpoints to refine, skipping")
                continue
                
            # Limit nbp for performance - exhaustive search becomes too slow for n>=4
            max_nbp = 3  # Limit to 3 breakpoints for reasonable performance
            if nbp > max_nbp:
                VERBOSE("Too many breakpoints (%d), limiting to %d for performance" % (nbp, max_nbp))
                nbp = max_nbp
                
            # Run optimal_pwlf_refinement (use fast version for nbp > 3)
            try:
                if nbp <= 3 and len(period_indices) < 100:
                    VERBOSE("Running optimal_pwlf_refinement (exhaustive search) with %d breakpoints" % nbp)
                    optimal_bp, optimal_vals, min_error = optimal_pwlf_refinement(t_period, y_period, y0, yn, nbp)
                else:
                    VERBOSE("Running optimal_pwlf_refinement_fast because exhaustive search would be too slow with %d breakpoints and %d points" % (nbp, len(period_indices)))
                    optimal_bp, optimal_vals, min_error = optimal_pwlf_refinement_fast(t_period, y_period, y0, yn)
            except Exception as e:
                VERBOSE("Error in optimal_pwlf_refinement: %s" % str(e))
                continue
                
            original_error = np.sum((y_period - l1_period)**2)
            
            VERBOSE("Original error: %.6f, Optimal error: %.6f" % (original_error, min_error))
            
            # Test if optimal_pwlf_refinement significantly improves fit
            improvement_ratio = original_error / min_error if min_error > 0 else float('inf')
            significant_improvement = improvement_ratio > 1.1  # 10% improvement threshold
            
            if significant_improvement:
                VERBOSE("Significant improvement detected (ratio: %.2f), updating refine_l1ts" % improvement_ratio)
                
                # Interpolate optimal solution back to the period indices
                optimal_interp = np.interp(t_period, optimal_bp, optimal_vals)
                
                # Insert optimal solution into refine_l1ts
                refine_l1ts.data[period_indices, comp_idx] = optimal_interp / 1E3  # Convert back to m
                
                VERBOSE("Successfully updated refine_l1ts for period %d" % (i+1))
            else:
                VERBOSE("No significant improvement (ratio: %.2f), keeping original" % improvement_ratio)
    
    VERBOSE("Refinement completed for %s" % (self.code))

    if output == 'ts':
        return refine_l1ts
    if output == 'both':
        return refine_l1ts, H_period, H_cp, H_cp_pb
    if output == 'info':
        return H_period, H_cp, H_cp_pb
