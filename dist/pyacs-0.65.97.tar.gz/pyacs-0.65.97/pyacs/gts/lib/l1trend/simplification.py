"""
Simplification functions for L1-trend filtered time series.
"""

import numpy as np
from pyacs.gts.Gts import Gts
from pyacs.message import VERBOSE


def simplify_l1trend(self, tolerance=.5, components='ENU'):
    """
    Remove unnecessary breakpoints from an L1-trend filtered time series.
    
    This function iteratively removes breakpoints and tests if the simplified model
    still fits the original time series within a specified tolerance.
    
    Parameters
    ----------
    tolerance : float
        Maximum allowed difference (in mm) between original and simplified model.
        Default is 0.5 mm.
    components : str
        Components to process. Default is 'ENU'.
        
    Returns
    -------
    pyacs.gts.Gts.Gts
        Simplified Gts object with unnecessary breakpoints removed.
    """
    VERBOSE("Simplifying l1trend for %s" % (self.code))
    
    # Convert tolerance from mm to m for consistency with PYACS Gts format 
    tolerance_m = tolerance / 1000.0
    
    # Get breakpoints from the current L1-trend
    bp = self.l1trend_to_breakpoints(tol=0.1)
    
    # Initialize new data array
    new_data = np.zeros_like(self.data)
    new_data[:,0] = self.data[:,0]  # Copy dates
    new_data[:,4:8] = self.data[:,4:8]  # Copy uncertainties
    
    # Process each component
    for comp in components:
        if comp not in ['N', 'E', 'U']:
            continue
            
        comp_idx = {'N': 1, 'E': 2, 'U': 3}[comp]
        
        # Get breakpoints for this component
        bp_dates = bp[comp][0]
        bp_values = bp[comp][1]
        
        if len(bp_dates) <= 2:  # Only start and end points
            # No breakpoints to simplify, just interpolate
            new_data[:, comp_idx] = np.interp(new_data[:,0], bp_dates, bp_values)
            continue
        
        # Start with all breakpoints
        current_dates = bp_dates.copy()
        current_values = bp_values.copy()
        
        # Iteratively remove breakpoints (except first and last)
        removed_any = True
        while removed_any and len(current_dates) > 2:
            removed_any = False
            
            # Try removing each breakpoint (except first and last)
            for i in range(1, len(current_dates) - 1):
                # Create test breakpoints without the current breakpoint
                test_dates = np.delete(current_dates, i)
                test_values = np.delete(current_values, i)
                
                # Interpolate test model on original dates
                test_interp = np.interp(self.data[:,0], test_dates, test_values)
                
                # Compare with original L1-trend values
                original_values = self.data[:, comp_idx]
                max_diff = np.max(np.abs(test_interp - original_values))
                
                # If within tolerance, remove this breakpoint
                if max_diff <= tolerance_m:
                    current_dates = test_dates
                    current_values = test_values
                    removed_any = True
                    break  # Start over with the new set of breakpoints
        
        # Interpolate final simplified breakpoints on original dates
        new_data[:, comp_idx] = np.interp(new_data[:,0], current_dates, current_values)
    
    # Create new Gts object
    simplified_gts = Gts(code=self.code, data=new_data)
    
    return simplified_gts
