"""
Statistics and model evaluation functions for L1-trend analysis.
"""

import numpy as np
from scipy.stats import chi2
from pyacs.message import VERBOSE


def get_stats_l1_model(x, y, fy, alpha):
    """
    Calculate statistics for L1-trend model evaluation.

    Parameters
    ----------
    x : numpy.ndarray
        Input time as 1D array
    y : numpy.ndarray
        Input raw data as 1D array
    fy : numpy.ndarray
        Input l1trend filtered data as 1D array
    alpha : float
        Hyperparameter used for l1 filtering

    Returns
    -------
    tuple
        (alpha, cchi2, sigma, cp, cchi2_probability, Cp, AICc, BIC)
    """
    # tolerance to detect velocity change
    #tol = .1 # mm/yr note JMN 10/08/2024: this seems to be too tight
    tol = 2. # mm/yr note JMN 10/08/2024: this seems to be too tight

    n = y.shape[0]
    sigma = 1.5 * np.median(np.fabs(np.diff(y)))
    cchi2 = np.sum( (fy - y)**2 / sigma**2 )

    # avoid division by zero
    #if np.sqrt(cchi2/n) < .5:
    #    c_cchi2 = n / 4
    #    WARNING("median of residuals gets too small. Set manually to .5. %.1lf %.1lf" % (cchi2, c_cchi2))
    #    cchi2 = c_cchi2

    dy = np.diff(fy) / (np.diff(x))
    # number of parameters = number of change points + 2 for start & end
    cp = np.where(np.fabs(np.diff(dy)) > tol )[0].shape[0] + 2
    AIC = n * np.log(cchi2 / n) + 2 * cp
    AICc = n * np.log(cchi2 / n) + 2 * cp + 2 * cp * (cp + 1) / (n - cp - 1)
    BIC = n * np.log(cchi2 / n) + np.log(n) * cp
    cdof = x.shape[0] - cp
    cchi2_probability = chi2.cdf(cchi2, cdof) * 100.
    Cp = cchi2 + cp
    VERBOSE("alpha: %10f log10_alpha: %6.2lf chi2 : %10.2f fit %8.2lf n_param %05d chi2_proba: %5.2lf Cp: %10.2lf AIC: %10.2lf BIC: %8.2lf " % (
     alpha, np.log10(alpha), cchi2, np.sqrt(cchi2 / x.shape[0]), cp, cchi2_probability, Cp, AIC, BIC))
    return alpha, cchi2, np.sqrt(cchi2 / x.shape[0]), cp, cchi2_probability, Cp, AICc, BIC
