#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
Script to check sites in an apr file.
"""

import argparse
import pandas as pd
import numpy as np
import os
from pyacs.lib.utils import run_cmd
import pyacs.message.message as MESSAGE
import pyacs.message.error as ERROR
import pyacs.message.warning as WARNING
import pyacs.message.verbose_message as VERBOSE
import glob

def read_lfile(filepath):
    """
    Reads an apr file and extracts 4-letter site codes with X, Y, Z coordinates.

    Parameters:
        filepath (str): Path to the input file.

    Returns:
        pd.DataFrame: A DataFrame with columns ['site', 'X', 'Y', 'Z']
    """
    # Read only the first 4 columns
    df = pd.read_csv(filepath, delim_whitespace=True, header=None, usecols=[0, 1, 2, 3])
    df.columns = ['site', 'X', 'Y', 'Z']
    
    # Trim the site name to 4 characters
    df['site'] = df['site'].str[:4]

    return df

def create_distance_matrix(df):
    """
    Creates a distance matrix between all sites in the DataFrame.

    Parameters:
        df (pd.DataFrame): DataFrame containing site coordinates

    Returns:
        np.ndarray: Distance matrix
    """
    n_sites = len(df)
    distance_matrix = np.zeros((n_sites, n_sites))
    
    for i in range(n_sites):
        for j in range(i+1, n_sites):
            # Calculate Euclidean distance
            dist = np.sqrt(
                (df.iloc[i]['X'] - df.iloc[j]['X'])**2 +
                (df.iloc[i]['Y'] - df.iloc[j]['Y'])**2 +
                (df.iloc[i]['Z'] - df.iloc[j]['Z'])**2
            )
            distance_matrix[i,j] = dist
            distance_matrix[j,i] = dist
            
    return distance_matrix

def find_rinex_file(site):
    """
    Find RINEX file for a given site in the current directory.
    
    Parameters:
        site (str): 4-letter site code
        
    Returns:
        str or None: Path to RINEX file if found, None otherwise
    """
    # Pattern: site[0-3][0-9][0-9]?.[0,1,2,3,9][0-9]o
    pattern = f"{site}[0-3][0-9][0-9]?.[0,1,2,3,9][0-9]o"
    files = glob.glob(pattern)
    
    if files:
        # Replace character before dot with X
        rinex_file = files[0]
        dot_index = rinex_file.find('.')
        if dot_index > 0:
            rinex_file = rinex_file[:dot_index-1] + 'X' + rinex_file[dot_index:]
        return rinex_file
    return None

def check_apr(lsite, lfile):
    """
    Check sites in an apr file and find their closest neighbors.

    Parameters:
        lsite (list): List of site codes to check
        lfile (str): Path to the apr file
    """
    # Read apr file
    try:
        df_apr = read_lfile(lfile)
    except Exception as e:
        ERROR(f"Failed to read apr file {lfile}: {str(e)}")
        return

    # Convert DataFrame to numpy arrays for efficient computation
    np_sinex_code = df_apr['site'].values
    np_sinex_coord = df_apr[['X', 'Y', 'Z']].values

    # Check each site
    for site in lsite:
        MESSAGE(f"\nChecking site {site}")
        
        # Find site coordinates and reshape for broadcasting
        try:
            site_mask = np_sinex_code == site
            if not np.any(site_mask):
                WARNING(f"Site {site} not found in apr file")
                continue
            # Ensure site_coords has shape (1,3)
            site_coords = np_sinex_coord[site_mask].reshape(1, -1)
        except Exception as e:
            ERROR(f"Error processing site {site}: {str(e)}")
            continue

        # Calculate distances to all other sites
        # Broadcast site_coords (1,3) to match np_sinex_coord (n,3)
        diff = np_sinex_coord - site_coords
        distances = np.sqrt(np.sum(diff**2, axis=1))
        
        # Create list of (site, distance) tuples, excluding the current site
        site_distances = []
        for i, dist in enumerate(distances):
            if np_sinex_code[i] != site:  # Exclude self
                site_distances.append((np_sinex_code[i], dist))
        
        # Sort by distance
        site_distances.sort(key=lambda x: x[1])
        
        # Display results
        MESSAGE(f"Sites ordered by distance from {site}:")
        for other_site, dist in site_distances:
            MESSAGE(f"  {other_site}: {dist/1000.:.2f} km")
        
        # Check for RINEX file
        rinex_file = find_rinex_file(site)
        if rinex_file:
            MESSAGE(f"RINEX file found: {rinex_file}")
        else:
            WARNING(f"No RINEX file found for site {site}")

def main():
    # Create argument parser
    parser = argparse.ArgumentParser(description='Check sites in an apr file')
    
    # Add arguments
    parser.add_argument('-s', '--site', action='append', required=True,
                       help='Site code to check (can be repeated for multiple sites)')
    parser.add_argument('-a', '--apr', required=True,
                       help='Path to the apr file')
    parser.add_argument('-v', '--verbose', action='store_true',
                       help='Enable verbose output')
    
    # Parse arguments
    args = parser.parse_args()
    
    # Check if apr file exists
    if not os.path.exists(args.apr):
        ERROR(f"Apr file not found: {args.apr}")
        return
    
    # Convert sites to uppercase
    sites = [site.upper() for site in args.site]
    
    # Run check_apr
    check_apr(sites, args.apr)

if __name__ == "__main__":
    main() 