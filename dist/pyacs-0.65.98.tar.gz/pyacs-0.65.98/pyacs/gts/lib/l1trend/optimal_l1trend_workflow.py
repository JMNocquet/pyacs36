"""
Optimal L1-trend workflow for GPS time series analysis.

This module provides a complete workflow that combines L1-trend filtering,
simplification, and refinement for optimal results.
"""

import time
import numpy as np
import pyacs.message.verbose_message as VERBOSE
import logging



def l1trend_optimal_workflow(self, criterion='AICc', log_dir=None):
    """
    Optimal workflow for l1 trend analysis.
    
    This workflow combines multiple L1-trend processing steps for optimal results:
    1. Initial L1-trend filtering with AICc criterion
    2. Breakpoint simplification to remove redundant breakpoints
    3. Local refinement using original data for better fit
    4. Final simplification to clean up the refined result
    
    Returns
    -------
    Gts
        Final optimized L1-trend time series
    """

    # import
    import pyacs.lib.astrotime as at
    import pyacs

    start_time = time.time()

    # Setup logging if log_dir is provided
    if log_dir is not None:
        import pyacs
        pyacs.verbose(level='INFO', print_message=False, log_dir=log_dir)
    
    # handle VERBOSE
    def should_verbose():
        """Check if verbose messages should be displayed based on current pyacs verbose level"""
        #import pyacs.message.verbose_message as VERBOSE_MODULE
        # Get current verbose level
        logging_levels={50:'CRITICAL',40:'ERROR',30:'WARNING',20:'INFO',10:'DEBUG',0:'NOTSET'}
        current_level = logging_levels[logging.getLogger("my_logger").level]
        # Only display verbose if level is VERBOSE or INFO
        return current_level in ['VERBOSE', 'INFO']
    
    def safe_verbose(message):
        """Display verbose message only if appropriate level is set"""
        if should_verbose():
            VERBOSE(message)
    
    
    # Calculate time series statistics
    n_points = len(self.data)
    time_span_years = self.data[-1, 0] - self.data[0, 0]
    
    # Convert start and end dates to human readable format
    start_date_decyear = self.data[0, 0]
    end_date_decyear = self.data[-1, 0]
    start_date_readable = at.decyear2datetime(start_date_decyear).strftime('%Y-%m-%d')
    end_date_readable = at.decyear2datetime(end_date_decyear).strftime('%Y-%m-%d')
    
    safe_verbose("Starting optimal L1trend_optimal_workflow for %s %d points, %.2f years span (%s to %s)" % 
            (self.code, n_points, time_span_years, start_date_readable, end_date_readable))
    
    # Step 1: remove large uncertainty points that are likely outliers
    safe_verbose("Step 1: Removing large uncertainty points that are likely outliers")
    pyacs.verbose(level='ERROR', print_message=False)
    ts_no_large_uncertainty = self.find_large_uncertainty().remove_outliers()
    pyacs.verbose(level='INFO', print_message=False)
    safe_verbose("Removed %d outliers" % (self.data.shape[0]-ts_no_large_uncertainty.data.shape[0]))

    # Step 2: detrend the time series
    safe_verbose("Step 2: Detrending the time series")
    try:
        detrended_ts = ts_no_large_uncertainty.detrend_median()
    except:
        detrended_ts = ts_no_large_uncertainty.detrend()

    # Step 3: l1trendi with criterion 
    step3_start_time = time.time()
    safe_verbose("Step 3: Initial L1-trend filtering with criterion %s" % criterion)
    pyacs.verbose(level='ERROR', print_message=False)
    l1_aicc = detrended_ts.l1trendi(criterion=criterion, refine=False)
    pyacs.verbose(level='INFO', print_message=False)
    step3_time = time.time() - step3_start_time
    safe_verbose("Step 3 completed in %.2f seconds" % step3_time)
    
    # Step 3 statistics
    safe_verbose("Step 3 - Initial L1-trend Statistics:")
    
    # Number of breakpoints per component in a single line

    pyacs.verbose(level='ERROR', print_message=False)
    bp_step3 = l1_aicc.l1trend_to_breakpoints(tol='auto')
    pyacs.verbose(level='INFO', print_message=False)

    bp_counts = []
    for component in ['N', 'E', 'U']:
        if component in bp_step3:
            n_bp = len(bp_step3[component][0]) - 2  # Subtract start and end points
            bp_counts.append(f"{component}:{n_bp}")
        else:
            bp_counts.append(f"{component}:0")
    safe_verbose("  Breakpoints: %s" % ", ".join(bp_counts))
    
    # Offset dates
    if hasattr(l1_aicc, 'offsets_dates') and l1_aicc.offsets_dates:
        safe_verbose("  Offset dates: %s" % [f"{date:.3f}" for date in l1_aicc.offsets_dates])
        # Convert to human readable format
        offset_dates_readable = []
        for date in l1_aicc.offsets_dates:
            try:
                date_dt = at.decyear2datetime(date)
                if hasattr(date_dt, '__len__'):
                    date_str = date_dt[0].isoformat()[:10]
                else:
                    date_str = date_dt.isoformat()[:10]
                offset_dates_readable.append(date_str)
            except:
                offset_dates_readable.append(f"{date:.3f}")
        safe_verbose("  Offset dates (readable): %s" % offset_dates_readable)
    else:
        safe_verbose("  No offset dates found")

    

    # Step 4: remove obvious outliers
    safe_verbose("Step 4: Removing obvious outliers using flag_outliers_using_l1trend")
    
    pyacs.verbose(level='ERROR', print_message=False)
    detrended_ts_outliers_flagged = detrended_ts.flag_outliers_using_l1trend(l1_aicc, threshold=20)
    pyacs.verbose(level='INFO', print_message=False)
    
    # Count outliers by component
    if detrended_ts_outliers_flagged.outliers:
        outlier_indices = np.array(detrended_ts_outliers_flagged.outliers)
        outlier_counts = []
        for component in ['N', 'E', 'U']:
            comp_idx = {'N': 1, 'E': 2, 'U': 3}[component]
            # Count outliers where this component exceeds threshold
            component_outliers = np.sum(np.abs(detrended_ts_outliers_flagged.data[outlier_indices, comp_idx]) > 0.020)  # 20mm threshold
            outlier_counts.append(f"{component}:{component_outliers}")
        safe_verbose("  Outliers removed by component: %s" % ", ".join(outlier_counts))
    else:
        safe_verbose("  No outliers found")
    
    pyacs.verbose(level='ERROR', print_message=False)
    dts_no_outliers = detrended_ts_outliers_flagged.remove_outliers()
    l1_aicc_no_outliers = l1_aicc.copy()
    l1_aicc_no_outliers.outliers = detrended_ts_outliers_flagged.outliers
    l1_aicc_no_outliers = l1_aicc_no_outliers.remove_outliers()
    pyacs.verbose(level='INFO', print_message=False)

    
    # Step 5: simplify l1 trend
    safe_verbose("Step 5: Simplifying L1-trend breakpoints")
    pyacs.verbose(level='ERROR', print_message=False)
    l1_simplified = l1_aicc_no_outliers.simplify_l1trend()
    pyacs.verbose(level='INFO', print_message=False)
    
    # Get breakpoints after simplification
    pyacs.verbose(level='ERROR', print_message=False)
    bp_step5 = l1_simplified.l1trend_to_breakpoints(tol='auto')
    pyacs.verbose(level='INFO', print_message=False)
    
    # Count simplified breakpoints by component
    bp_counts_step5 = []
    for component in ['N', 'E', 'U']:
        if component in bp_step5:
            n_bp = len(bp_step5[component][0]) - 2  # Subtract start and end points
            bp_counts_step5.append(f"{component}:{n_bp}")
        else:
            bp_counts_step5.append(f"{component}:0")
    
    safe_verbose("  Simplified breakpoints: %s" % ", ".join(bp_counts_step5))



    # Step 6: refine l1 trend with the original data
    step6_start_time = time.time()
    safe_verbose("Step 6: Refining L1-trend using original data")
    
    # Instead of splitting into segments, process the entire time series
    # but ensure the refine_l1trend function handles offsets properly
    safe_verbose("Step 6.1: Refining entire time series with offset awareness")
    
    # Refine the entire simplified L1-trend using the full detrended time series
    pyacs.verbose(level='ERROR', print_message=False)
    l1_refined = l1_simplified.refine_l1trend(dts_no_outliers, min_samples_per_segment=4)
    pyacs.verbose(level='INFO', print_message=False)
    
    # Get refinement information to display refined periods
    pyacs.verbose(level='ERROR', print_message=False)
    H_period, H_cp, H_cp_pb = l1_simplified.refine_l1trend(dts_no_outliers, min_samples_per_segment=4, output='info')
    pyacs.verbose(level='INFO', print_message=False)
    
    # Display refined periods in human-readable format
    if H_period:
        safe_verbose("Refined periods:")
        for component in ['N', 'E', 'U']:
            if component in H_period and H_period[component]:
                safe_verbose("  %s component:" % component)
                for i, period in enumerate(H_period[component]):
                    start_date = period[0]
                    end_date = period[1]
                    try:
                        start_dt = at.decyear2datetime(start_date)
                        end_dt = at.decyear2datetime(end_date)
                        if hasattr(start_dt, '__len__'):
                            start_str = start_dt[0].isoformat()[:10]
                        else:
                            start_str = start_dt.isoformat()[:10]
                        if hasattr(end_dt, '__len__'):
                            end_str = end_dt[0].isoformat()[:10]
                        else:
                            end_str = end_dt.isoformat()[:10]
                        safe_verbose("    Period %d: %s to %s" % (i+1, start_str, end_str))
                    except:
                        safe_verbose("    Period %d: %.3f to %.3f" % (i+1, start_date, end_date))
            else:
                safe_verbose("  %s component: No periods refined" % component)
    else:
        safe_verbose("No periods were refined")
    
    safe_verbose("Refinement completed on entire time series")

    step6_time = time.time() - step6_start_time
    
    # Step 7: simplify again
    safe_verbose("Step 7: Final simplification of refined L1-trend")
    
    # Get breakpoints before simplification
    pyacs.verbose(level='ERROR', print_message=False)
    bp_before = l1_refined.l1trend_to_breakpoints(tol='auto')
    pyacs.verbose(level='INFO', print_message=False)
    
    pyacs.verbose(level='ERROR', print_message=False)
    l1_final_detrended = l1_refined.simplify_l1trend()
    pyacs.verbose(level='INFO', print_message=False)
    
    # Get breakpoints after simplification
    pyacs.verbose(level='ERROR', print_message=False)
    bp_after = l1_final_detrended.l1trend_to_breakpoints(tol='auto')
    pyacs.verbose(level='INFO', print_message=False)
    
    # Count breakpoints removed by component
    bp_removed = []
    for component in ['N', 'E', 'U']:
        if component in bp_before and component in bp_after:
            n_before = len(bp_before[component][0]) - 2  # Subtract start and end points
            n_after = len(bp_after[component][0]) - 2
            n_removed = n_before - n_after
            bp_removed.append(f"{component}:{n_removed}")
        elif component in bp_before:
            n_before = len(bp_before[component][0]) - 2
            bp_removed.append(f"{component}:{n_before}")
        else:
            bp_removed.append(f"{component}:0")
    
    safe_verbose("  Breakpoints removed by component: %s" % ", ".join(bp_removed))
    
    


    # Step 8: apply back the velocity removed at step #0
    safe_verbose("Step 8: Applying back the velocity removed at step #0")
    velocity = detrended_ts.velocity

    pyacs.verbose(level='ERROR', print_message=False)
    l1_final = l1_final_detrended.remove_velocity(velocity)
    pyacs.verbose(level='INFO', print_message=False)

    # compute a median bias with respect to the original data and remove it
    pyacs.verbose(level='ERROR', print_message=False)
    median_bias = np.median(l1_final.substract_ts_daily(self).data[:, 1:4],axis=0)
    pyacs.verbose(level='INFO', print_message=False)
    l1_final.data[:, 1:4] -= median_bias

    # Step 9 interpolate the final l1 trend to the original time series
    safe_verbose("Step 9: Interpolating the final L1-trend to the original time series")
    from pyacs.gts.Gts import Gts
    l1_final_interpolated = Gts(code=self.code)
    l1_final_interpolated.data = np.zeros((self.data.shape[0], 10))
    l1_final_interpolated.data[:,4:7] = 0.001
    l1_final_interpolated.data[:, 0] = self.data[:, 0]
    l1_final_interpolated.data[:, 1] = np.interp(self.data[:, 0], l1_final.data[:, 0], l1_final.data[:, 1])
    l1_final_interpolated.data[:, 2] = np.interp(self.data[:, 0], l1_final.data[:, 0], l1_final.data[:, 2])
    l1_final_interpolated.data[:, 3] = np.interp(self.data[:, 0], l1_final.data[:, 0], l1_final.data[:, 3])
    
    # Calculate and display final statistics
    safe_verbose("----------------------------------------------------------")
    safe_verbose("FINAL STATISTICS")
    safe_verbose("----------------------------------------------------------")
    
    # Number of breakpoints per component (from the L1-trend, not the velocity-adjusted version)
    pyacs.verbose(level='ERROR', print_message=False)
    bp_final = l1_final_detrended.l1trend_to_breakpoints(tol='auto')
    pyacs.verbose(level='INFO', print_message=False)
    for component in ['N', 'E', 'U']:
        if component in bp_final:
            n_bp = len(bp_final[component][0]) - 2  # Subtract start and end points
            safe_verbose("Number of breakpoints for %s component: %d" % (component, n_bp))
        else:
            safe_verbose("Number of breakpoints for %s component: 0" % component)
    
    # Offset dates (from the L1-trend, not the velocity-adjusted version)
    if hasattr(l1_final_detrended, 'offsets_dates') and l1_final_detrended.offsets_dates:
        safe_verbose("Offset dates: %s" % [f"{date:.3f}" for date in l1_final_detrended.offsets_dates])
        # Convert to human readable format
        offset_dates_readable = []
        for date in l1_final_detrended.offsets_dates:
            try:
                date_dt = at.decyear2datetime(date)
                if hasattr(date_dt, '__len__'):
                    date_str = date_dt[0].isoformat()[:10]
                else:
                    date_str = date_dt.isoformat()[:10]
                offset_dates_readable.append(date_str)
            except:
                offset_dates_readable.append(f"{date:.3f}")
        safe_verbose("Offset dates (readable): %s" % offset_dates_readable)
    else:
        safe_verbose("No offset dates found")
    
    # Median of fit (residuals between final L1-trend and original data)
    pyacs.verbose(level='ERROR', print_message=False)
    residuals = l1_final_interpolated.substract_ts_daily(self).data[:, 1:4] * 1000  # Convert to mm
    pyacs.verbose(level='INFO', print_message=False)
    median_residuals = np.median(residuals, axis=0)
    mad_residuals = np.median(np.abs(residuals - median_residuals), axis=0)
    
    safe_verbose("Median residuals (N, E, U): [%.3f, %.3f, %.3f] mm" % tuple(median_residuals))
    safe_verbose("MAD residuals (N, E, U): [%.3f, %.3f, %.3f] mm" % tuple(mad_residuals))
    
    # RMS of fit
    rms_residuals = np.sqrt(np.mean(residuals**2, axis=0))
    safe_verbose("RMS residuals (N, E, U): [%.3f, %.3f, %.3f] mm" % tuple(rms_residuals))
    
    total_time = time.time() - start_time
    safe_verbose("Optimal L1-trend workflow completed")
    safe_verbose("Total workflow time: %.2f seconds" % total_time)
    #VERBOSE("Step 6 (refinement) completed in %.2f seconds" % step6_time)
    
    return l1_final_interpolated
