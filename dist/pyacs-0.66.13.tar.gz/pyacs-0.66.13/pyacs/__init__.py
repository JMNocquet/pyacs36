__version__ = '0.66.13'
import pyacs.verbose
pyacs.verbose = pyacs.verbose.verbose
import pyacs.debug
pyacs.debug = pyacs.debug.debug
