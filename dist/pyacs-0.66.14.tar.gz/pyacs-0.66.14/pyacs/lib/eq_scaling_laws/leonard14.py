
import numpy as np
from .constants import LEONARD14_COEFFICIENTS, BETA
from .utils import Mw_to_M0

def compute_all(Mw, regime="crustal-strike"):
    Cw = LEONARD14_COEFFICIENTS[regime]["Cw"]
    Cd = LEONARD14_COEFFICIENTS[regime]["Cd"]
    mu = LEONARD14_COEFFICIENTS[regime]["mu"]

    M0 = Mw_to_M0(Mw)

    # Solve L from M0 = mu * Cd * sqrt(Cw) * L^(1 + BETA + 0.5)
    expo = 1 + BETA + 0.5
    L = (M0 / (mu * Cd * np.sqrt(Cw))) ** (1/expo) / 1000  # km

    W = Cw * L**BETA
    A = L * W  # km2
    D = Cd * np.sqrt(A * 1e6)  # m (convert km2 -> m2)

    return L, W, A, D
