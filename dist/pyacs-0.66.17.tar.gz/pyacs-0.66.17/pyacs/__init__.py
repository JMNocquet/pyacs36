__version__ = '0.66.17'
import pyacs.verbose
pyacs.verbose = pyacs.verbose.verbose
import pyacs.debug
pyacs.debug = pyacs.debug.debug
