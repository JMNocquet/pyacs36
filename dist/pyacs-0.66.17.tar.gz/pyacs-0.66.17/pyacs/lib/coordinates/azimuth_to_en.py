import numpy as np


###############################################################################
def azimuth_to_en(azimuth):
###############################################################################
    """
    converts an azimuth (clockwise from north) to east and north unit vector

    :param azimuth: azimuth in decimal degrees
    :return east,north: unit vector  
    :note: calculation is made using the sphere
    """

    r_az = np.radians(azimuth)
    return (np.sin(r_az), np.cos(r_az))


