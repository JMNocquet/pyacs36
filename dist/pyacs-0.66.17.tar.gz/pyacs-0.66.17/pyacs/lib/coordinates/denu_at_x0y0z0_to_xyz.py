import numpy as np
from .xyz2geo import xyz2geo
from .mat_rot_local_to_general import mat_rot_local_to_general


###################################################################
def denu_at_x0y0z0_to_xyz(de, dn, du, x0, y0, z0):
###################################################################
    """
    Converts a local vector [dn,de,du] at [x0,y0,z0] in geocentric cartesian coordinates
    into X,Y,Z geocentric cartesian coordinates
    
    :param de,dn,du: east,north, up components of the local vector in meters
    :param x0,x0,z0: reference point for the local vector in geocentric cartesian coordinates
    
    :returns: x,y,z in geocentric cartesian coordinates
    
    """
    
    (lam, phi, _) = xyz2geo(x0, y0, z0)
    R = mat_rot_local_to_general(lam, phi)
    
    DL = np.array([de, dn, du])
    X0 = np.array([x0, y0, z0])
    XYZ = np.dot(R, DL) + X0
    return (XYZ[0], XYZ[1], XYZ[2])


