import numpy as np
from pyproj import Transformer


###################################################################
def flat_earth2geo(x, y):
##################################################################
    """
    Converts web Mercator coordinates (units km) to geographical coordinates
    uses pyproj and web Mercator projection.

    :param longitude,latitude: geographical (ellipsoid) coordinates in decimal degrees. Also works with 1D numpy arrays

    :returns x,y: in km
    """

    x = np.array(x)
    y = np.array(y)

    TRAN_3857_TO_4326 = Transformer.from_crs("EPSG:3857", "EPSG:4326", always_xy=True)
    return TRAN_3857_TO_4326.transform(x * 1.0e3, y * 1.0e3)


