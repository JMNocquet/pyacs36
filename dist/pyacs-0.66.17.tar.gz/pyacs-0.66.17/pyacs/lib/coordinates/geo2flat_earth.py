from pyproj import Transformer
import numpy as np


###################################################################
def geo2flat_earth(longitude, latitude):
##################################################################
    """
    Converts geographical coordinates to flat earth approximation
    uses pyproj and web Mercator projection.
    
    :param longitude,latitude: geographical (ellipsoid) coordinates in decimal degrees. Also works with 1D numpy arrays
    
    :returns x,y: in km
    """

    longitude = np.array(longitude)
    latitude = np.array(latitude)

    TRAN_4326_TO_3857 = Transformer.from_crs("EPSG:4326", "EPSG:3857", always_xy=True)
    (x, y) = TRAN_4326_TO_3857.transform(longitude, latitude)
    return x * 1.0e-3, y * 1.0e-3


