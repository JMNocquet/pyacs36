from pyacs.lib.errors import OptionError
import numpy as np
from .wnorm import wnorm


###################################################################
def geo2xyz(llambda, phi, he, unit="radians", A=6378137.0, E2=0.006694380022903):
###################################################################
    """
    Converts geodetic coordinates (long,lat,he) to geocentric cartesian coordinates (XYZ)

    :param llambda,phi: longitude, latitude
    :param he: ellipsoidal height in meters
    :param unit: 'radians' or 'dec_deg' for llambda and phi (default is 'radians')

    :returns: x,y,z in meters
    
    :note: Default ellipsoid is GRS80 used for WGS84 with
    
    A  = 6378137.         # semi major axis = equatorial radius
    
    E2 = 0.00669438003    # eccentricity and then
    
    F = 1.0 - sqrt(1-E2)  # flattening

    """

    if unit not in ["radians", "dec_deg"]:
        raise OptionError("unit option must be in [radians,dec_deg];unit=", unit)

    if unit == "dec_deg":
        llambda = np.radians(llambda)
        phi = np.radians(phi)

    a = A
    e2 = E2

    wn = wnorm(phi, A=a, E2=e2)
   
    xx = (wn + he) * np.cos(phi) * np.cos(llambda)
    yy = (wn + he) * np.cos(phi) * np.sin(llambda)
    zz = (wn * (1.0 - e2) + he) * np.sin(phi)
   
    return (xx, yy, zz)


