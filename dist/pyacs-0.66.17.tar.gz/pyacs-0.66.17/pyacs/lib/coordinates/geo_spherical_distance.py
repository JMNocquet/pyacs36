from pyacs.lib.errors import OptionError
from .geo2xyz import geo2xyz
from .xyz_spherical_distance import xyz_spherical_distance


###################################################################
def geo_spherical_distance(lon1, lat1, h1, lon2, lat2, h2, unit="radians", Rt=6.371E6):
###################################################################
    """
    Returns the spherical distance between two points of geodetic coordinates lon1,lat1,lon2,lat2
     
    :param lon1,lat1,h1,lon2,lat2,h2: longitude, latitude, radius
    :param unit: 'radians' or 'dec_deg' for lon & lat (default is 'radians')
    :param Rt: mean Earth's radius in meters (default 6 371 000.0 m)
 
    :returns: distance in meters
     
    """
    if unit not in ["radians", "dec_deg"]:
       raise OptionError("unit option must be in [radians,dec_deg];unit=", unit)

    (x1, y1, z1) = geo2xyz(lon1, lat1, 0.0, unit=unit)
    (x2, y2, z2) = geo2xyz(lon2, lat2, 0.0, unit=unit)
 
 
    return xyz_spherical_distance(x1, y1, z1, x2, y2, z2)


