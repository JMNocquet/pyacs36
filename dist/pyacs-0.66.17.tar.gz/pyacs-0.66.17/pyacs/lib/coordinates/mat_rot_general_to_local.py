from pyacs.lib.errors import OptionError
import numpy as np


###################################################################
def mat_rot_general_to_local(lam, phi, unit="radians"):
###################################################################

    """ 
    Generates the conversion matrix R from general geocentric cartesian coordinates (XYZ) to local cartesian coordinates (ENU):
    
    :param lam,phi: longitude
    :param unit: 'radians' or 'dec_deg' (default is 'radians')
    
    :returns: R as a 2D numpy array
    
    
    :note: R = [[-sin(lambda)            cos(lambda)         0       ],
    
    [-sin(phi)*cos(lambda) , -sin(phi)*sin(lamda) , cos(phi)],
    
    [ cos(phi)*cos(lambda) , cos(phi)*sin(lamda) , sin(phi)]]
    """

    if unit not in ["radians", "dec_deg"]:
        raise OptionError("unit option must be in [radians,dec_deg];unit=", unit)

    if unit == "dec_deg":
        lam = np.radians(lam)
        phi = np.radians(phi)
    
    R = np.zeros([3, 3], float)
    R[0, 0] = -np.sin(lam)
    R[0, 1] = np.cos(lam)

    R[1, 0] = -np.sin(phi) * np.cos(lam)
    R[1, 1] = -np.sin(phi) * np.sin(lam)
    R[1, 2] = np.cos(phi)
    
    R[2, 0] = np.cos(phi) * np.cos(lam)
    R[2, 1] = np.cos(phi) * np.sin(lam)
    R[2, 2] = np.sin(phi)

    return R


