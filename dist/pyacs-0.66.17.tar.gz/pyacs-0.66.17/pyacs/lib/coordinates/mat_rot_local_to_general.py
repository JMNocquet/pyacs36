from pyacs.lib.errors import OptionError
from .mat_rot_general_to_local import mat_rot_general_to_local


###################################################################
def mat_rot_local_to_general(lam, phi, unit="radians"):
###################################################################
    """
    Generates the conversion matrix R from local cartesian coordinates (ENU) to general geocentric cartesian coordinates (XYZ):

    :param lam,phi: longitude in radians
    :param unit: 'radians' or 'dec_deg' (default is 'radians')

    :returns: R as a 2D numpy array
    
    :note: Since R is orthogonal, it is the inverse and also the transpose of the conversion matrix from general geocentric cartesian coordinates (XYZ) to local cartesian coordinates (ENU)
    """
    if unit not in ["radians", "dec_deg"]:
        raise OptionError("unit option must be in [radians,dec_deg];unit=", unit)
    
    return mat_rot_general_to_local(lam, phi, unit=unit).T


