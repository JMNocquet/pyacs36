import numpy as np


###################################################################
def wnorm(phi, A=6378137.0, E2=0.006694380022903):
###################################################################
    """
    Calculates the geodetic radius normal to the ellipsoid
    """

    a = A
    e2 = E2
  
    wd = np.sqrt(1.0 - e2 * np.sin(phi) ** 2) 
    result = a / wd
    
    return result


