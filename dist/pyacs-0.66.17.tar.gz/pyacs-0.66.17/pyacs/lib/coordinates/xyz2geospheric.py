from pyacs.lib.errors import OptionError
import numpy as np


###################################################################
def xyz2geospheric(x, y, z, unit="radians"):
###################################################################
    """
    Converts geocentric cartesian coordinates (XYZ) to geo-spherical coordinates (longitude,latitude,radius).
    
    :param x,y,z: geocentric cartesian coordinates in meters
    :param unit: 'radians' or 'dec_deg' (default is 'radians')
    
    :returns: longitude,latitude (in radians), radius from the Earth's center in meters
    
    :note: Be aware that the obtained coordinates are not what is usually taken as spherical coordinates, which uses co-latitude
    """

    if unit not in ["radians", "dec_deg"]:
        raise OptionError("unit option must be in [radians,dec_deg];unit=", unit)
    
    R = np.sqrt(x ** 2 + y ** 2 + z ** 2)
    RLBDA = np.arctan2(y, x)
    
    Req = np.sqrt(x ** 2 + y ** 2)
    if Req != 0.0:
        RPHI = np.arctan(z / Req)
    else:
        RPHI = np.pi / 2.0 * z / np.sqrt(z ** 2)

    if unit == "dec_deg":
        RLBDA = np.degrees(RLBDA)
        RPHI = np.degrees(RPHI)
    
    return (RLBDA, RPHI, R)


