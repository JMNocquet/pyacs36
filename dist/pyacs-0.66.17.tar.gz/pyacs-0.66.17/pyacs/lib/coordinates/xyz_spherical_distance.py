import numpy as np
import pyacs.lib.vectors


###################################################################
def xyz_spherical_distance(x1, y1, z1, x2, y2, z2, Rt=6.371E6):
###################################################################
    """
    Returns the spherical distance between two points of XYZ coordinates x1,y1,z1 and x2,y2,z2
     
    :param x1,y1,z1,x2,y2,z2: in meters
    :param Rt: mean Earth's radius in meters (default 6 371 000.0 m)
 
    :returns: distance in meters
     
    """
 
    sp = pyacs.lib.vectors.scal_prod(pyacs.lib.vectors.normalize([x1, y1, z1]), pyacs.lib.vectors.normalize([x2, y2, z2]))
    sp = np.around(sp, decimals=13)
    return np.fabs(np.arccos(sp) * Rt)


