"""
The offsets subpackage contains the offsets functions for the Gts class.
"""