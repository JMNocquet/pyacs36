import numpy as np
import pyacs.lib.vectors


###################################################################
def xyz_spherical_distance(x1, y1, z1, x2, y2, z2, Rt=6.371E6):
###################################################################
    """Spherical distance between two points in geocentric XYZ.

    Parameters
    ----------
    x1, y1, z1 : float
        First point in geocentric cartesian coordinates, meters.
    x2, y2, z2 : float
        Second point in geocentric cartesian coordinates, meters.
    Rt : float, optional
        Mean Earth radius in meters. Default 6.371e6.

    Returns
    -------
    float
        Distance in meters.
    """
 
    sp = pyacs.lib.vectors.scal_prod(pyacs.lib.vectors.normalize([x1, y1, z1]), pyacs.lib.vectors.normalize([x2, y2, z2]))
    sp = np.around(sp, decimals=13)
    return np.fabs(np.arccos(sp) * Rt)


