"""Euler pole utilities: rotation vectors, velocities, and design matrices."""

###############################################################################
def rot2euler(Wx,Wy,Wz):
###############################################################################
    """Convert a rotation rate vector to an Euler pole in geographical coordinates.

    Converts Wx, Wy, Wz (radians/yr) into longitude, latitude (degrees) and
    angular velocity (deg/Myr).

    Parameters
    ----------
    Wx : float
        X component of rotation rate vector (geocentric cartesian), radians/yr.
    Wy : float
        Y component of rotation rate vector (geocentric cartesian), radians/yr.
    Wz : float
        Z component of rotation rate vector (geocentric cartesian), radians/yr.

    Returns
    -------
    W_long : float
        Longitude of the Euler pole in decimal degrees.
    W_lat : float
        Latitude of the Euler pole in decimal degrees.
    W_omega : float
        Angular velocity in decimal degrees per Myr.

    Notes
    -----
    Longitude and latitude are relative to the sphere, not the ellipsoid.
    Euler pole and rigid rotations only have sense on a sphere.
    """  

    import numpy as np
    
    W = np.sqrt(Wx**2+Wy**2+Wz**2)
    W_lat = 90.0-np.arccos(Wz/W)*180.0/np.pi

    if (Wx>0):
        W_long = np.arctan(Wy/Wx)*180.0/np.pi
    elif (Wx<0):
        if (Wy>0): 
            W_long = np.arctan(Wy/Wx)*180.0/np.pi+180.0
        else:
            W_long = np.arctan(Wy/Wx)*180.0/np.pi-180.0
    else:
        # Wx = 0
        if (Wy>0): 
            W_long = 90.
        else:
            W_long = -90.
        
    
    W_omega=W/np.pi*180*1.0E6

    return(W_long,W_lat,W_omega)

###############################################################################
def euler2rot(lon, lat, omega):
###############################################################################
    """Convert an Euler pole to a cartesian rotation rate vector.

    Converts longitude, latitude (degrees) and angular velocity (deg/Myr)
    into Wx, Wy, Wz in radians/yr.

    Parameters
    ----------
    lon : float
        Longitude of the Euler pole in decimal degrees.
    lat : float
        Latitude of the Euler pole in decimal degrees.
    omega : float
        Angular velocity in decimal degrees per Myr.

    Returns
    -------
    wx : float
        X component of rotation rate, radians/yr.
    wy : float
        Y component of rotation rate, radians/yr.
    wz : float
        Z component of rotation rate, radians/yr.

    Notes
    -----
    Longitude and latitude are relative to the sphere, not the ellipsoid.
    """

    import numpy as np

    wx=np.cos(np.radians(lat))*np.cos(np.radians(lon))*np.radians(omega)*1.0E-6
    wy=np.cos(np.radians(lat))*np.sin(np.radians(lon))*np.radians(omega)*1.0E-6
    wz=np.sin(np.radians(lat))*np.radians(omega)*1.0E-6

    return (wx,wy,wz)

###############################################################################
def euler_uncertainty( w, vcv ):
###############################################################################
    """Calculate Euler pole parameter uncertainties from rotation vector covariance.

    Propagates the covariance of the rotation vector (radians/yr) into
    uncertainties of the Euler pole (semi-major, semi-minor, azimuth, omega).

    Parameters
    ----------
    w : array_like, shape (3,)
        Rotation vector in XYZ (geocentric) coordinates, radians/yr.
    vcv : array_like, shape (3, 3)
        Covariance matrix of `w`.

    Returns
    -------
    max_sigma : float
        Semi-major axis of error ellipse, degrees.
    min_sigma : float
        Semi-minor axis of error ellipse, degrees.
    azimuth : float
        Azimuth of the error ellipse, degrees.
    s_omega : float
        Uncertainty of angular velocity, deg/Myr.
    """

    import pyacs.lib.coordinates as Coordinates
    import numpy as np

    nw = np.sqrt( w[0]**2 + w[1]**2 + w[2]**2 )
        
    (llambda,phi,omega) = rot2euler( w[0],w[1],w[2] )

    # Propagates vcv into the local frame to get the Euler pole uncertainties
    
    R=Coordinates.mat_rot_general_to_local(np.radians(llambda),np.radians(phi))

    VCV_POLE_ENU=np.dot(np.dot(R, vcv),R.T)

    vcv11=VCV_POLE_ENU[0,0]
    vcv12=VCV_POLE_ENU[0,1]
    vcv22=VCV_POLE_ENU[1,1]
    vcv33=VCV_POLE_ENU[2,2]

    # Error ellipse parameters
    
    max_sigma=0.5*(vcv11+vcv22+np.sqrt((vcv11-vcv22)**2+4*vcv12**2))
    max_sigma=np.degrees(np.arctan(np.sqrt(max_sigma)/ nw ))
    min_sigma=0.5*(vcv11+vcv22-np.sqrt((vcv11-vcv22)**2+4*vcv12**2))
    min_sigma=np.degrees(np.arctan(np.sqrt(min_sigma)/ nw ))
    azimuth=np.degrees(2*np.arctan(2*vcv12/(vcv11-vcv22)))
    s_omega=np.degrees(np.sqrt(vcv33))*1.E06

    return( max_sigma, min_sigma, azimuth, s_omega )


###############################################################################
def vel_from_euler(lonp,latp,lon_euler,lat_euler,omega_euler):
###############################################################################
    """Return horizontal velocity predicted at a point from an Euler pole.

    Parameters
    ----------
    lonp : float
        Longitude of the point where velocity is predicted, decimal degrees.
    latp : float
        Latitude of the point where velocity is predicted, decimal degrees.
    lon_euler : float
        Longitude of the Euler pole, decimal degrees.
    lat_euler : float
        Latitude of the Euler pole, decimal degrees.
    omega_euler : float
        Angular velocity of the Euler pole, decimal degrees per Myr.

    Returns
    -------
    ve : float
        East velocity at (lonp, latp), mm/yr.
    vn : float
        North velocity at (lonp, latp), mm/yr.
    """

    import numpy as np
    import pyacs.lib.coordinates
    
    # convert to rotation rate vector
    (wx,wy,wz) = euler2rot(lon_euler, lat_euler, omega_euler)
    
    # W
    W=np.zeros((3,1))
    W[0,0]=wx
    W[1,0]=wy
    W[2,0]=wz


    # get spherical coordinates

    he = 0.
    (x,y,z)=pyacs.lib.coordinates.geo2xyz( lonp , latp , he , unit='dec_deg')
    (l,p,_)=pyacs.lib.coordinates.xyz2geospheric(x,y,z,unit='radians')
    R=pyacs.lib.coordinates.mat_rot_general_to_local(l,p)

    # Observation equation in local frame
            
    Ai=np.zeros([3,3],float)
    
    Ai[0,1]= z
    Ai[0,2]=-y
    Ai[1,0]=-z
    Ai[1,2]= x
    Ai[2,0]= y
    Ai[2,1]=-x
            
    RAi=np.dot(R,Ai)
        
    # Predicted velocity
            
    V = np.dot(RAi,W) * 1.E3 # to get mm/yr
    
    return( V[0,0] , V[1,0])
    
###############################################################################
def pole_matrix( coor ):
###############################################################################
    """Design matrix relating horizontal velocity to a rotation rate vector.

    For n sites with coordinates [lon, lat] (decimal degrees), returns matrix W
    such that ``np.dot(W, w)`` is the flattened [ve1, vn1, ve2, vn2, ...] in m/yr
    for rotation rate vector `w` in rad/yr.

    Parameters
    ----------
    coor : array_like, shape (n, 2)
        Site coordinates as [longitude, latitude] in decimal degrees.

    Returns
    -------
    ndarray, shape (2*n, 3)
        Pole matrix such that (W @ w) gives [ve1, vn1, ve2, vn2, ...] in m/yr.
    """
    
    # import 
    import numpy as np
    import pyacs.lib.coordinates

    # ensures dimension
    
    coor = coor.reshape(-1,2)

    # pole_matrix

    pole_matrix = None

    # loop if points
    
    for i in np.arange( coor.shape[0] ):
        
        # get spherical coordinates
    
        he = 0.
        (x,y,z) = pyacs.lib.coordinates.geo2xyz( coor[i,0] , coor[i,1] , he , unit='dec_deg')
        (l,p,_) = pyacs.lib.coordinates.xyz2geospheric(x,y,z,unit='radians')
        R       = pyacs.lib.coordinates.mat_rot_general_to_local(l,p)
    
        # Observation equation in local frame
                
        Ai=np.zeros([3,3],float)
        
        Ai[0,1]= z
        Ai[0,2]=-y
        Ai[1,0]=-z
        Ai[1,2]= x
        Ai[2,0]= y
        Ai[2,1]=-x
                
        RAi=np.dot(R,Ai)[:2,:]
        
        # Predicted velocity
                
        if pole_matrix is None:
            pole_matrix = RAi
        else:
            pole_matrix = np.vstack(( pole_matrix , RAi ))
        

    return pole_matrix

###############################################################################
def pole_matrix_fault( coor , strike , order=None ):
###############################################################################
    """Design matrix relating fault slip components to a rotation rate vector.

    For n sites with [lon, lat] (decimal degrees) and strike (counter-clockwise
    from north), returns matrix W such that ``np.dot(W, w)`` is the flattened
    [ss1, ns1, ss2, ns2, ...] in m/yr for rotation rate vector `w` in rad/yr.

    Parameters
    ----------
    coor : array_like, shape (n, 2)
        Site coordinates as [longitude, latitude] in decimal degrees.
    strike : array_like, shape (n,) or (n, 1)
        Fault strike at each site, counter-clockwise from north, decimal degrees.
    order : {None, 'SS_DS'}, optional
        If provided, return matrix ordered as strike-slip then dip-slip rows.

    Returns
    -------
    ndarray, shape (2*n, 3)
        Pole matrix. ``np.dot(W, w).reshape(-1, 2)`` gives [along-strike, normal]
        components in two columns, in m/yr. Values refer to the hanging-wall
        block (right-hand rule polygon).
    """
    
    # import 
    import numpy as np
    import pyacs.lib.coordinates

    # ensures dimension
    
    coor = coor.reshape(-1,2)

    # strike in radians
    
    #strike = strike.reshape(-1,1) 
    rstrike = np.radians( strike )

    if order is not None:
        pmf_SS = np.zeros( ( strike.shape[0] , 3  ))
        pmf_DS = np.zeros( ( strike.shape[0] , 3  ))

    # pole_matrix

    pole_matrix = None

    # loop if points
    
    for i in np.arange( coor.shape[0] ):
        
        # get spherical coordinates
    
        he = 0.
        (x,y,z)=pyacs.lib.coordinates.geo2xyz( coor[i,0] , coor[i,1] , he , unit='dec_deg')
        (l,p,_)=pyacs.lib.coordinates.xyz2geospheric(x,y,z,unit='radians')
        R=pyacs.lib.coordinates.mat_rot_general_to_local(l,p)
    
        # Observation equation in local frame
                
        Ai=np.zeros([3,3],float)
        
        Ai[0,1]= z
        Ai[0,2]=-y
        Ai[1,0]=-z
        Ai[1,2]= x
        Ai[2,0]= y
        Ai[2,1]=-x
                
        RAi=np.dot(R,Ai)[:2,:]
        
        # rotates into the fault coordinates

        RF = np.array( [ [  np.sin( rstrike[i] )  ,  np.cos( rstrike[i] ) ] , \
                         [ -np.cos( rstrike[i] )  ,  np.sin( rstrike[i] ) ] ] )

        # RW
        RW = np.dot( RF , RAi  )
        
        # Predicted velocity

        if order is not None:
            pmf_SS[i] = RW[0,:]
            pmf_DS[i] = RW[1,:]

                
        if pole_matrix is None:
            pole_matrix = RW
        else:
            pole_matrix = np.vstack(( pole_matrix , RW ))
    
    if order is not None:
        return np.vstack( (pmf_SS,pmf_DS) )
    else:
        return pole_matrix


