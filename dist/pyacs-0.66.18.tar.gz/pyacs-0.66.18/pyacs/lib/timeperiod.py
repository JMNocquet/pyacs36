from datetime import datetime,timedelta

class TimePeriodUndefinedError(Exception): pass
    

"""Time period representation and manipulation."""
class TimePeriod:
    """A time period with start and end datetime.

    Attributes
    ----------
    __start_time : datetime, optional
        Start of the period.
    __end_time : datetime, optional
        End of the period.
    """
    __start_time = None
    __end_time = None 
    

    def __init__ (self,start_time=None,end_time=None):
        self.__start_time = start_time
        self.__end_time = end_time

    def isdefined(self):
        """Return True if both start and end times are set."""
        return self.__start_time != None and self.__end_time != None

    def begin(self):
        """Return the start datetime of this period.

        Returns
        -------
        datetime
            Start time.

        Raises
        ------
        TimePeriodUndefinedError
            If the period is not defined.
        """
        if not self.isdefined():
            raise TimePeriodUndefinedError("This time period is undefined")
        return self.__start_time

    def epoch_begin(self):
        """Return the start time as Unix timestamp (epoch seconds).

        Returns
        -------
        int
            Start time in epoch seconds.

        Raises
        ------
        TimePeriodUndefinedError
            If the period is not defined.
        """
        if not self.isdefined():
            raise TimePeriodUndefinedError("This time period is undefined")
        return int(self.begin().strftime("%s"))

    def end(self):
        """Return the end datetime of this period.

        Returns
        -------
        datetime
            End time.

        Raises
        ------
        TimePeriodUndefinedError
            If the period is not defined.
        """
        if not self.isdefined():
            raise TimePeriodUndefinedError("This time period is undefined")
        return self.__end_time

    def epoch_end(self):
        """Return the end time as Unix timestamp (epoch seconds).

        Returns
        -------
        int
            End time in epoch seconds.

        Raises
        ------
        TimePeriodUndefinedError
            If the period is not defined.
        """
        if not self.isdefined():
            raise TimePeriodUndefinedError("This time period is undefined")
        return int(self.end().strftime("%s"))

    def intersection(self, period):
        """Return the intersection of this period with another.

        Parameters
        ----------
        period : TimePeriod
            The other time period.

        Returns
        -------
        TimePeriod
            Intersection period, or undefined if no overlap.
        """
        # If one period is not defined
        if not self.isdefined() or not period.isdefined():
            return TimePeriod()

        # If period don't intersect
        if  self.__end_time < period.begin() or period.end() < self.__start_time:
            return TimePeriod()
    
        # For simplicity self must begin first 
        if self.__start_time > period.begin():
            # self must begin first
            return period.intersection(self)
    
        if self.__end_time < period.end():
            return TimePeriod(period.begin(),self.__end_time)
        else:
            return TimePeriod(period.begin(),period.end())

    def has_in(self, date):
        """Return whether a date falls within this period.

        Parameters
        ----------
        date : datetime
            Date to test.

        Returns
        -------
        bool
            True if date is in [start, end], False otherwise.
        """
        if not self.isdefined():
            return TimePeriod()
    
        if self.__start_time <= date and self.__end_time >= date:
            return True
        else:
            return False

    def display(self):
        str1=datetime.isoformat(self.__start_time)
        str2=datetime.isoformat(self.__end_time)
        return("%s -> %s" % (str1,str2)) 
        
    def get_info(self):
        str1=datetime.isoformat(self.__start_time)
        str2=datetime.isoformat(self.__end_time)
        str= ("%s -> %s" % (str1,str2)) 
        return(str)



