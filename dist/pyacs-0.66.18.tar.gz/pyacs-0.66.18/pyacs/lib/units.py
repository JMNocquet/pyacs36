"""
Various routines dealing with units conversion.
"""


###################################################################
def mas2rad(mas):
###################################################################
    """Convert milliarcseconds to radians.

    Parameters
    ----------
    mas : float or array_like
        Angle(s) in milliarcseconds.

    Returns
    -------
    float or numpy.ndarray
        Angle(s) in radians.

    Examples
    --------
    >>> import pyacs
    >>> pyacs.mas2rad(1.)
    4.84813681109536e-09
    >>> pyacs.mas2rad(np.array([1.0, 2.0]))
    array([  4.84813681e-09,   9.69627362e-09])
    """
    import numpy as np
    
    if not isinstance(mas, np.ndarray):
        np_mas = np.array( mas )
    else:
        np_mas = mas
    
    return( np_mas*2.*np.pi/360./60./60./1000.)

###################################################################
def rad2mas(rad):
###################################################################
    """Convert radians to milliarcseconds.

    Parameters
    ----------
    rad : float or array_like
        Angle(s) in radians.

    Returns
    -------
    float or numpy.ndarray
        Angle(s) in milliarcseconds.
    """

    import numpy as np

    return(rad/2./np.pi*360.*60.*60.*1000.)

###################################################################
def radians2deg_mn_sec(rad,angle_range='-180-180'):
###################################################################
    """Convert an angle from radians to degrees, minutes, seconds.

    Parameters
    ----------
    rad : float
        Angle in radians.
    angle_range : str, optional
        '0-360' or '-180-180'. Default is '-180-180'.

    Returns
    -------
    deg : int
        Degrees (signed if angle_range is '-180-180').
    minutes : int
        Minutes.
    seconds : float
        Seconds.
    """

    import numpy as np

    
    # to degrees
    decimal_degrees=np.degrees(rad)
    # within 0-360
    decimal_degrees=np.remainder(decimal_degrees,360.)
    # -180 - 180 if asked
    if angle_range=='-180-180':
        if decimal_degrees>180.:
            decimal_degrees = decimal_degrees - 360.
    
    angle_sign=np.sign(decimal_degrees)

    # we work only with positive angles
    decimal_degrees=decimal_degrees * angle_sign
    
            
    deg=int(decimal_degrees)
    
    deg_frac=decimal_degrees-float(deg)
    
    minutes=int(deg_frac*60.)
    
    minutes_frac=deg_frac-float(minutes)/60.
    
    seconds=minutes_frac*3600.
    
    return(angle_sign*deg,minutes,seconds)

###################################################################
def moment_to_magnitude(moment):
###################################################################
    """Convert seismic moment (N.m) to moment magnitude Mw.

    Parameters
    ----------
    moment : float or array_like
        Seismic moment in N.m.

    Returns
    -------
    float or numpy.ndarray
        Moment magnitude Mw (2/3 * (log10(M0) - 9.05)).
    """
    
    import numpy as np
    magnitude=2./3.*(np.log10(moment)-9.05)
    return( magnitude )

###################################################################
def magnitude_to_moment(magnitude):
###################################################################
    """Convert moment magnitude Mw to seismic moment in N.m.

    Parameters
    ----------
    magnitude : float or array_like
        Moment magnitude Mw.

    Returns
    -------
    float or numpy.ndarray
        Seismic moment in N.m (10^(1.5*Mw + 9.05)).
    """
    
    import numpy as np
    moment = np.power(10,(1.5*magnitude+9.05))
    return( moment )

