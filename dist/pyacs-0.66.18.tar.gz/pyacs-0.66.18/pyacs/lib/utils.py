"""
Various useful routines
"""

###############################################################################
def __ensure_list_of_list(ll):
###############################################################################
    """Ensure argument is a list of lists.

    [a, b] becomes [[a, b]]; [[a, b]] is returned unchanged.

    Parameters
    ----------
    ll : list
        List or list of lists.

    Returns
    -------
    list
        List of lists.

    Raises
    ------
    TypeError
        If ll is not a list.
    """

    # check this is a list
    
    if not isinstance(ll,list):
        raise TypeError('!!! __ensure_list_of_list requires a list or a list of list as argument: ',ll)
    
    # case simple list
    if not isinstance(ll[0],list):
        return([ll])
    # case list of list
    else:
        return(ll)

###############################################################################
def numpy_array_2_numpy_recarray(A,names):
###############################################################################
    """Convert a numpy array to a numpy recarray.

    Parameters
    ----------
    A : numpy.ndarray
        2D array.
    names : list of str
        Field names for each column.

    Returns
    -------
    numpy.recarray
        Record array with the given names.
    """
    import numpy as np

    return(np.rec.array(np.core.records.array(list(tuple(A[:,:].T)),dtype={'names':names,'formats':list(map(np.dtype,A[0,:]))})))

###############################################################################
def numpy_recarray_2_numpy_array(A):
###############################################################################
    """Convert a structured array (homogeneous dtype) to a numpy array.

    Parameters
    ----------
    A : numpy structured array
        Input array.

    Returns
    -------
    numpy.ndarray
        Plain array.
    """
    import numpy as np
    return(np.array(A.view(A.dtype[0]).reshape(A.shape + (-1,))))


###################################################################
def save_np_array_with_string(A,S,fmt,outfile,comment=''):
###################################################################
    """Save a numpy array as a text file with a string column per row.

    Equivalent to np.savetxt but S is a 1D string array appended to each row.

    Parameters
    ----------
    A : numpy.ndarray
        2D array to save.
    S : array_like
        1D string array; len(S) must equal A.shape[0].
    fmt : str
        Format string for each row (e.g. "%03d %03d %s").
    outfile : str
        Output file path.
    comment : str, optional
        Comment line written at top. Default is ''.

    Examples
    --------
    >>> A = np.arange(4).reshape(-1, 2)
    >>> S = np.array(['lima', 'quito'])
    >>> save_np_array_with_string(A, S, "%03d %03d %s", 'test.dat')
    """

    # import
    import numpy as np
    
    # check
    
    if S.size != A.shape[0]:
        raise TypeError
    # open file
    out=open(outfile,'w+')
    
    # comment
    if comment.strip() =='':
        comment = '# '
    
    if comment[0] != '#':
        comment = '# ' + comment
    
    out.write("%s\n" % comment)
    
    # loop
    
    for i in np.arange( A.shape[0] ):
        fmtstr=(fmt % tuple( list(A[i,:])+[S[i]] ))
        out.write("%s\n" %  fmtstr )
    
    # close file
    out.close()

###################################################################
def make_grid(min_lon,max_lon,min_lat,max_lat, \
              nx=None, ny=None, step_x=None, step_y=None, outfile=None, format='psvelo' , comment=''):
###################################################################
    """Generate a regular grid and optionally write it to a text file.

    Parameters
    ----------
    min_lon : float
        Minimum longitude (decimal degrees).
    max_lon : float
        Maximum longitude (decimal degrees).
    min_lat : float
        Minimum latitude (decimal degrees).
    max_lat : float
        Maximum latitude (decimal degrees).
    nx : int, optional
        Number of points along longitude. If provided, ny defaults to nx.
    ny : int, optional
        Number of points along latitude.
    step_x : float, optional
        Longitude step (alternative to nx).
    step_y : float, optional
        Latitude step; defaults to step_x if not provided.
    outfile : str, optional
        Output file path. If None, no file is written.
    format : str, optional
        None for lon,lat only; 'psvelo' for psvelo-style rows. Default is 'psvelo'.
    comment : str, optional
        Comment for the output file. Default is ''.

    Returns
    -------
    numpy.ndarray
        2D array of shape (n_points, 2) with lon, lat columns.
    """
    
    # import
    
    import numpy as np
    from colors import red

    # check arguments
    
    if [nx,step_x] == [None,None]:
        error_str = red( "[PYACS ERROR] please provide a value for argument nx or step_x"  ) 
        print( error_str )
        raise TypeError
    
    if ( nx is not None ) and ( step_x is not None ):
        error_str = red( "[PYACS ERROR] nx or step_x argument need to be specified, not both"  ) 
        print( error_str )
        raise TypeError
    
    
    # start
    if nx is not None:
        if ny is None:
            ny = nx 
        x = np.linspace(min_lon,max_lon, nx)
        y = np.linspace(min_lat,max_lat, ny)

    if step_x is not None:
        if step_y is None:
            step_y= step_x
        x = np.arange(min_lon,max_lon, step_x)
        y = np.arange(min_lat,max_lat, step_y)

    mesh_grid = np.meshgrid(x,y)
    grid = np.vstack((mesh_grid[0].T.flatten(),mesh_grid[1].T.flatten())).T
    
    # write results
    
    if format == 'psvelo':
        output_np = np.zeros(( grid.shape[0] , 8 ) )
        output_np[:,:2] = grid
        output_np[:,7]  = np.arange( grid.shape[0] ) 

        if outfile is not None:
            np.savetxt(outfile, output_np, "%10.6lf %10.6lf %4.1lf %4.1lf %4.1lf %4.1lf %4.1lf %04d", header=comment)
        
    else:
        if outfile is not None:
            np.savetxt(outfile, grid, "%10.6lf %10.6lf", header=comment)
        
    return( grid )
    
###################################################################
def str2list_float(my_str):
###################################################################
    """Convert a string representation of a list to a list of floats.

    Parameters
    ----------
    my_str : str
        String like '[0, 2.5, 1E9]'.

    Returns
    -------
    list of float
        Parsed values, e.g. [0, 2.5, 1e9].
    """
    
    return list( map( float,  my_str.replace('[','').replace(']','').split(',') ) )   

def run_cmd(cmd, shell=True, check=True, capture_output=True, text=True):
    """
    Run a command using subprocess and check for errors.
    
    Parameters
    ----------
    cmd : str or list
        Command to run. If str, will be run with shell=True
    shell : bool, optional
        Whether to use shell. Default is True
    check : bool, optional
        Whether to raise CalledProcessError if return code is non-zero. Default is True
    capture_output : bool, optional
        Whether to capture stdout and stderr. Default is True
    text : bool, optional
        Whether to return output as string. Default is True
        
    Returns
    -------
    subprocess.CompletedProcess
        Object containing returncode, stdout, stderr
        
    Raises
    ------
    subprocess.CalledProcessError
        If check=True and command returns non-zero exit code
        
    Examples
    --------
    >>> result = run_cmd('ls -l')
    >>> if result.returncode == 0:
    ...     print("Command succeeded")
    ...     print(result.stdout)
    """
    import subprocess
    
    try:
        result = subprocess.run(cmd, shell=shell, check=check, 
                              capture_output=capture_output, text=text)
        return result
    except subprocess.CalledProcessError as e:
        print(f"Command failed with return code {e.returncode}")
        print(f"Command: {e.cmd}")
        print(f"Output: {e.output}")
        print(f"Error: {e.stderr}")
        raise

    
