"""
Useful operations on vectors (1-D numpy array)
"""

###################################################################
def np_array(X):
###################################################################

    """Convert input to a 1D numpy array.

    Parameters
    ----------
    X : list, tuple or array_like
        Input to convert.

    Returns
    -------
    numpy.ndarray
        1D array.
    """
    
    import numpy as np
    
    return np.array(X) 

###################################################################
def norm(X):
###################################################################

    """Return the Euclidean norm of a vector.

    Parameters
    ----------
    X : list, tuple or array_like
        1D array or sequence.

    Returns
    -------
    float
        Euclidean norm.
    """

    import numpy as np
    
    return np.sqrt(np.sum(np_array(X)**2))


###################################################################
def normalize(X):
###################################################################

    """Normalize a vector to unit length.

    Parameters
    ----------
    X : list, tuple or array_like
        1D array or sequence.

    Returns
    -------
    numpy.ndarray
        Unit vector (same shape as input, 1D).
    """

    return np_array(X) / norm(X)

###################################################################
def scal_prod(X,Y):
###################################################################

    """Return the scalar (dot) product of two vectors.

    Parameters
    ----------
    X : list, tuple or array_like
        First vector.
    Y : list, tuple or array_like
        Second vector (same length as X).

    Returns
    -------
    float
        Dot product X.Y.
    """
   
    import numpy as np
    
    return np.sum( np_array(X) * np_array(Y) )

###################################################################
def vector_product(A,B):
###################################################################
    """Return the cross product of two 3D vectors.

    Components: (A[1]*B[2]-B[1]*A[2], A[2]*B[0]-B[2]*A[0], A[0]*B[1]-B[0]*A[1]).

    Parameters
    ----------
    A : array_like
        First 3D vector.
    B : array_like
        Second 3D vector.

    Returns
    -------
    numpy.ndarray
        3D vector A x B.
    """
    
    import numpy as np
    
    C=np.zeros([3])
    C[0]=A[1]*B[2]-B[1]*A[2]
    C[1]=A[2]*B[0]-B[2]*A[0]
    C[2]=A[0]*B[1]-B[0]*A[1]
    
    return(C)



    