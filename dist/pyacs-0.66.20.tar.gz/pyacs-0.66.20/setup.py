from setuptools import setup

###############################################################################
# TODO
# 04/10/2018 : detrend_median_seasonal: periods option to be implemented 
#        think how seasonal terms are then removed for the part not used in parametric seasonal signal

###############################################################################

#from sphinx.setup_command import BuildDoc
#cmdclass = {'build_sphinx': BuildDoc}

name = 'pyacs'
version = '0.66'
# do not forget to change pyacs/__init__py which controls release name
release = '0.66.20'

setup(name=name,
      version=release,
      description='PYACS: Geodetic analysis and modeling tools for Tectonics',
      long_description='Geodetic analysis and modeling tools for Tectonics.',
#      cmdclass=cmdclass,
#      include_package_data=True,
      classifiers=[
          'Development Status :: 3 - Alpha',
          'License :: OSI Approved :: MIT License',
          'Programming Language :: Python :: 3.6',
          'Topic :: Geodesy :: Geophysics',
      ],
      keywords='geodesy GPS earthquake elastic dislocation tectonics time series',
      url='',
      author='Jean-Mathieu Nocquet (Geoazur, IRD, CNRS, OCA, Cote d Azur University, France)',
      author_email='nocquet@geoazur.unice.fr',
      license='NA',
      package_dir={
          'trendfilter': 'pyacs/external_pkg/trendfilter',
      },
      packages=['pyacs',
                'pyacs.message',
                'pyacs.vel_field',
                'pyacs.lib',
                'pyacs.lib.astrotime',
                'pyacs.lib.coordinates',
                'pyacs.lib.euler',
                'pyacs.lib.faultslip',
                'pyacs.lib.glinalg',
                'pyacs.lib.gmtpoint',
                'pyacs.lib.icosahedron',
                'pyacs.lib.robustestimators',
                'pyacs.lib.shapefile',
                'pyacs.lib.timeperiod',
                'pyacs.lib.units',
                'pyacs.lib.utils',
                'pyacs.lib.eq_scaling_laws',
                # gts
                'pyacs.gts',
                'pyacs.gts.lib',
#                'pyacs.gts.lib.non_linear_model',
                'pyacs.gts.lib.filters',
                'pyacs.gts.lib.format',
                'pyacs.gts.lib.primitive',
                'pyacs.gts.lib.plot',
                'pyacs.gts.lib.outliers',
                'pyacs.gts.lib.noise',
                'pyacs.gts.lib.offset',
                'pyacs.gts.lib.model',
                'pyacs.gts.lib.tensor_ts',
                'pyacs.gts.lib.l1trend',
                # sol & sinex
                'pyacs.sol',
                'pyacs.sinex',
                # Sgts
                'pyacs.gts.Sgts_methods',
                # refactoring 0.63.8
                'pyacs.glinalg',
                'pyacs.glinalg.solve',
                # bundled external (importable as top-level "trendfilter")
                'trendfilter',
                ],


      scripts=[
          # IPYACS
          'pyacs/scripts/ipyacs.py',
          # PYACS MAKE TIME SERIES
          'pyacs/scripts/pyacs_make_time_series.py',
          #                # QGIS TRANSLATERS
          'pyacs/scripts/pyacs_qgis_psvelo_2_shapefile.py',
          #                # PYACS GAMIT
          #                # PYACS GVEL POLE & STRAIN
          'pyacs/scripts/pyacs_gvel_pole.py',
          'pyacs/scripts/pyacs_gvel_estimate_pole.py',
          'pyacs/scripts/pyacs_gvel_prep_comb.py',
          'pyacs/scripts/pyacs_gvel_comb.py',
          'pyacs/scripts/pyacs_gvel_strain.py',
          #
      ],

# relax import version
# see pyacs36/environment_pyacs_066.yml to see package that need to be installed using mamba beforehand
      install_requires=['art',
                        'ansicolors',
                        'hectorp'
                        ],
      package_data={'trendfilter': ['*.yaml']},


      zip_safe=False,

      tests_require=['pytest'],
      extras_require={'test': ['pytest']},

      )